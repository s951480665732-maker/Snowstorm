package com.personal.snowdrift;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

/**
 * Мастерская снеговика: катаешь комья по снегу (они растут), ставишь их друг на друга
 * и украшаешь игрушками из коробки. Снег в мастерской тоже падает туда, куда наклонён телефон.
 */
public class WorkshopView extends View {
    private static final int MAX_LOOSE = 5, MAX_TRAIL = 200, FLAKES = 90, TOY_COLS = 5;
    private static final float LOOSE_START = 13f, LOOSE_MAX = Snowman.R_MAX;
    private static final float TRAIL_LIFE = 6f;

    /** Ком, который катают (x, y — пиксели, r — dp). */
    private static final class Loose {
        float x, y, r, rot;
    }

    private final float d;
    private final Random rnd = new Random();
    private final SnowmanArt art = new SnowmanArt();

    private Snowman sm = new Snowman();
    private boolean dirty, running = true;

    private final ArrayList<Loose> loose = new ArrayList<>();
    private Loose held;
    private float offX, offY;

    // игрушка в руке
    private Snowman.Toy heldToy;
    private boolean heldFromSnowman, toyMoved;
    private float hx, hy, downX, downY;

    private boolean trayOpen;

    // следы от катания
    private final float[] trX = new float[MAX_TRAIL], trY = new float[MAX_TRAIL], trR = new float[MAX_TRAIL], trT = new float[MAX_TRAIL];
    private int trN;
    private float lastTrX = -1e9f, lastTrY = -1e9f;

    // падающий снег
    private final float[] fx = new float[FLAKES], fy = new float[FLAKES], fz = new float[FLAKES];
    private final float[] fr = new float[FLAKES], fph = new float[FLAKES];
    private float dirx, diry = 1f, tdx, tdy = 1f;
    private final float[] tmp = new float[2];

    private int w, h;
    private float fieldTop, baseY, stackX;
    private long lastNanos;
    private float time;

    private String hintRoll = "", hintStack = "", hintToys = "", hintDone = "";

    private final Paint skyPaint = new Paint();
    private final Paint groundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flakePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cellPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path ground = new Path();
    private final RectF rf = new RectF();

    public WorkshopView(Context c) {
        super(c);
        d = getResources().getDisplayMetrics().density;
        Snowman s = Snowman.load(c);
        if (s != null) sm = s;

        trailPaint.setColor(0xFF9DB4CE);
        ghostPaint.setStyle(Paint.Style.STROKE);
        ghostPaint.setStrokeWidth(2f * d);
        ghostPaint.setColor(0xAAD6ECFF);
        ghostPaint.setPathEffect(new DashPathEffect(new float[]{10f * d, 8f * d}, 0f));
        trayPaint.setColor(0xEE0A1424);
        cellPaint.setColor(0x26FFFFFF);
        textPaint.setColor(0xCCFFFFFF);
        textPaint.setTextSize(14f * getResources().getDisplayMetrics().scaledDensity);
    }

    // ---------------------------------------------------------------- управление из Activity

    void setHints(String roll, String stack, String toys, String done) {
        hintRoll = roll;
        hintStack = stack;
        hintToys = toys;
        hintDone = done;
    }

    void setRunning(boolean r) {
        running = r;
        if (r) {
            lastNanos = 0;
            invalidate();
        }
    }

    /** Куда тянет вниз, в координатах экрана (м/с²). */
    void setGravity(float gx, float gy) {
        Tilt.direction(gx, gy, tmp);
        tdx = tmp[0];
        tdy = tmp[1];
    }

    void toggleTray() {
        trayOpen = !trayOpen;
        invalidate();
    }

    /** Убрать последнюю игрушку, а если игрушек нет — верхний шар. */
    void undo() {
        if (!sm.toys.isEmpty()) sm.toys.remove(sm.toys.size() - 1);
        else sm.removeTopBall();
        dirty = true;
        invalidate();
    }

    void reset() {
        sm = new Snowman();
        loose.clear();
        held = null;
        heldToy = null;
        trN = 0;
        dirty = true;
        invalidate();
    }

    /** Сохраняет снеговика на диск (если он менялся) и сообщает слою со снегом, что пора перерисовать. */
    void save() {
        cancelTouch();
        if (!dirty) return;
        dirty = false;
        Snowman.save(getContext(), sm);
        SharedPreferences p = Prefs.get(getContext());
        p.edit().putInt(Prefs.SNOWMAN_REV, Prefs.snowmanRev(p) + 1).apply();
    }

    // ---------------------------------------------------------------- размеры

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw;
        h = nh;
        fieldTop = h * 0.50f;
        baseY = fieldTop + (h - fieldTop) * 0.78f;
        stackX = w * 0.5f;
        skyPaint.setShader(new LinearGradient(0, 0, 0, fieldTop + 20f * d, 0xFF10233D, 0xFF35618F, Shader.TileMode.CLAMP));
        groundPaint.setShader(new LinearGradient(0, fieldTop, 0, h, 0xFFFFFFFF, 0xFFD3E2F3, Shader.TileMode.CLAMP));
        ground.rewind();
        ground.moveTo(0, fieldTop + 14f * d);
        ground.quadTo(w * 0.5f, fieldTop - 16f * d, w, fieldTop + 10f * d);
        ground.lineTo(w, h);
        ground.lineTo(0, h);
        ground.close();
        for (int i = 0; i < FLAKES; i++) spawnFlake(i, true);
    }

    // ---------------------------------------------------------------- падающий снег

    private void spawnFlake(int i, boolean anywhere) {
        fz[i] = rnd.nextFloat();
        fr[i] = (0.9f + 2.2f * fz[i]) * d;
        fph[i] = rnd.nextFloat() * 6.283f;
        float px = rnd.nextFloat() * w, py = rnd.nextFloat() * h;
        if (anywhere) {
            fx[i] = px;
            fy[i] = py;
            return;
        }
        // Идём от случайной точки экрана против потока, пока не выйдем за край: так снег всегда
        // приходит со стороны, противоположной наклону.
        float mg = fr[i] + 6f * d;
        float tx = Float.MAX_VALUE, ty = Float.MAX_VALUE;
        if (dirx > 1e-4f) tx = (px + mg) / dirx;
        else if (dirx < -1e-4f) tx = (w + mg - px) / -dirx;
        if (diry > 1e-4f) ty = (py + mg) / diry;
        else if (diry < -1e-4f) ty = (h + mg - py) / -diry;
        float t = Math.min(tx, ty) + 1f;
        fx[i] = px - dirx * t;
        fy[i] = py - diry * t;
    }

    private void stepFlakes(float dt) {
        float k = Math.min(1f, dt * 4f);
        dirx += (tdx - dirx) * k;
        diry += (tdy - diry) * k;
        float dl = (float) Math.hypot(dirx, diry);
        if (dl < 0.2f) {
            dirx = 0f;
            diry = 1f;
        } else {
            dirx /= dl;
            diry /= dl;
        }
        for (int i = 0; i < FLAKES; i++) {
            fph[i] += (0.8f + fz[i]) * dt;
            float sp = 55f * d * (0.5f + 0.7f * fz[i]);
            float sw = (float) Math.cos(fph[i]) * 10f * d * (0.4f + fz[i]);
            float vx = dirx * sp - diry * sw, vy = diry * sp + dirx * sw;
            fx[i] += vx * dt;
            fy[i] += vy * dt;
            float m = fr[i] + 4f * d;
            if ((fx[i] < -m && vx <= 0) || (fx[i] > w + m && vx >= 0)
                    || (fy[i] < -m && vy <= 0) || (fy[i] > h + m && vy >= 0)) {
                spawnFlake(i, false);
            }
        }
    }

    // ---------------------------------------------------------------- вспомогательное

    private float stackTopPx() {
        return baseY + sm.topY() * d;
    }

    private float trayCell() {
        return (w - 16f * d) / TOY_COLS;
    }

    private float trayHeight() {
        return 2f * trayCell() + 16f * d;
    }

    private float trayTop() {
        return h - trayHeight();
    }

    /** Номер игрушки в коробке под пальцем или -1. */
    private int trayHit(float x, float y) {
        float cw = trayCell(), pad = 8f * d;
        int col = (int) ((x - pad) / cw), row = (int) ((y - trayTop() - pad) / cw);
        if (col < 0 || col >= TOY_COLS || row < 0 || row > 1) return -1;
        int idx = row * TOY_COLS + col;
        return idx < Snowman.TOY_COUNT ? idx : -1;
    }

    private float toyPx(Snowman.Toy t) {
        return stackX + t.x * d;
    }

    private float toyPy(Snowman.Toy t) {
        return baseY + t.y * d;
    }

    /** Верхняя по порядку отрисовки игрушка под пальцем. */
    private Snowman.Toy toyAt(float x, float y) {
        for (int l = 3; l >= -1; l--) {
            for (int i = sm.toys.size() - 1; i >= 0; i--) {
                Snowman.Toy t = sm.toys.get(i);
                if (Snowman.layer(t.type) != l) continue;
                float rr = (26f * t.scale + 6f) * d;
                if (Math.hypot(x - toyPx(t), y - toyPy(t)) <= rr) return t;
            }
        }
        return null;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ---------------------------------------------------------------- касания

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDown(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                touchMove(x, y);
                return true;
            case MotionEvent.ACTION_UP:
                touchUp(x, y);
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelTouch();
                return true;
            default:
                return true;
        }
    }

    private void touchDown(float x, float y) {
        downX = x;
        downY = y;
        toyMoved = false;
        if (trayOpen && y >= trayTop()) {
            int t = trayHit(x, y);
            if (t >= 0) {
                heldToy = new Snowman.Toy(t, 0f, 0f, 1f, false, 0);
                heldFromSnowman = false;
                hx = x;
                hy = y;
            }
            return;
        }
        Snowman.Toy hit = toyAt(x, y);
        if (hit != null) {
            sm.toys.remove(hit);
            heldToy = hit;
            heldFromSnowman = true;
            hx = x;
            hy = y;
            return;
        }
        for (int i = loose.size() - 1; i >= 0; i--) {
            Loose b = loose.get(i);
            if (Math.hypot(x - b.x, y - b.y) <= b.r * d + 10f * d) {
                held = b;
                offX = b.x - x;
                offY = b.y - y;
                loose.remove(i);
                loose.add(b);
                lastTrX = lastTrY = -1e9f;
                return;
            }
        }
        if (y > fieldTop) {
            if (loose.size() >= MAX_LOOSE) loose.remove(0);
            Loose b = new Loose();
            b.x = x;
            b.y = y;
            b.r = LOOSE_START;
            loose.add(b);
            held = b;
            offX = offY = 0f;
            lastTrX = lastTrY = -1e9f;
        }
    }

    private void touchMove(float x, float y) {
        if (held != null) {
            Loose b = held;
            float r = b.r * d;
            float nx = clamp(x + offX, r, w - r), ny = clamp(y + offY, r, h - r * 0.6f);
            float dx = nx - b.x, dy = ny - b.y;
            float dist = (float) Math.hypot(dx, dy);
            b.x = nx;
            b.y = ny;
            // Растёт и оставляет след, только пока катится по снегу; поднятый вверх ком просто несут.
            if (ny > fieldTop && dist > 0f) {
                float sign = dx != 0f ? Math.signum(dx) : Math.signum(dy);
                b.rot += sign * dist / r * 57.2958f;
                if (b.r < LOOSE_MAX) {
                    b.r = Math.min(LOOSE_MAX, b.r + dist / d * 0.05f * (1f - 0.55f * b.r / LOOSE_MAX));
                }
                addTrail(nx, ny + b.r * d * 0.35f, b.r * d * 0.75f);
            }
        } else if (heldToy != null) {
            hx = x;
            hy = y;
            if (Math.hypot(x - downX, y - downY) > 8f * d) toyMoved = true;
        }
    }

    private void touchUp(float x, float y) {
        if (held != null) {
            Loose b = held;
            held = null;
            boolean inZone = Math.abs(b.x - stackX) < 85f * d
                    && b.y > stackTopPx() - 100f * d && b.y < baseY + 60f * d;
            if (inZone && sm.addBall(b.r)) {
                loose.remove(b);
                dirty = true;
            }
        } else if (heldToy != null) {
            Snowman.Toy t = heldToy;
            heldToy = null;
            if (heldFromSnowman && !toyMoved) {
                sm.toys.add(t); // просто тап — игрушка остаётся на месте
                return;
            }
            float mx = (x - stackX) / d, my = (y - baseY) / d;
            if (sm.n > 0 && !(trayOpen && y >= trayTop()) && sm.accepts(mx, my)) {
                placeToy(t, mx, my, !heldFromSnowman);
                sm.toys.add(t);
                dirty = true;
            } else if (heldFromSnowman) {
                dirty = true; // утащили в сторону — игрушка убрана
            }
        }
        invalidate();
    }

    /** Если палец оторвали «не по-настоящему» (уход из приложения): игрушка возвращается на место. */
    private void cancelTouch() {
        if (heldToy != null && heldFromSnowman) sm.toys.add(heldToy);
        heldToy = null;
        held = null;
    }

    /** Ставит игрушку: считает размер, зеркало и «прилипание» шапки к голове, а шарфа — к шее. */
    private void placeToy(Snowman.Toy t, float mx, float my, boolean isNew) {
        int bi = sm.nearestBall(mx, my);
        float rb = sm.r[bi];
        t.ball = bi;
        if (isNew) t.scale = clamp(rb / 36f, 0.6f, 1.4f);
        t.x = mx;
        t.y = my;
        t.flip = mx < -2f;
        if (Snowman.isHat(t.type)) {
            int head = sm.n - 1;
            if (bi == head) {
                float hr = sm.r[head];
                t.ball = head;
                t.scale = clamp(hr / 36f, 0.6f, 1.4f);
                t.x = clamp(mx, -hr * 0.3f, hr * 0.3f);
                t.y = sm.cy(head) - hr * 0.82f - Snowman.hatBottom(t.type) * t.scale;
            }
        } else if (t.type == Snowman.SCARF) {
            int best = -1;
            float bd = 28f, ny = 0f;
            for (int i = 1; i < sm.n; i++) {
                float neck = (sm.cy(i) + sm.r[i] + sm.cy(i - 1) - sm.r[i - 1]) / 2f;
                if (Math.abs(my - neck) < bd) {
                    bd = Math.abs(my - neck);
                    best = i;
                    ny = neck;
                }
            }
            if (best > 0) {
                t.ball = best;
                t.y = ny;
                t.x = clamp(mx, -sm.r[best] * 0.25f, sm.r[best] * 0.25f);
                t.scale = clamp(sm.r[best] / 30f, 0.6f, 1.5f);
            }
        }
    }

    private void addTrail(float x, float y, float r) {
        if (Math.hypot(x - lastTrX, y - lastTrY) < r * 0.6f) return;
        lastTrX = x;
        lastTrY = y;
        if (trN == MAX_TRAIL) {
            System.arraycopy(trX, 1, trX, 0, MAX_TRAIL - 1);
            System.arraycopy(trY, 1, trY, 0, MAX_TRAIL - 1);
            System.arraycopy(trR, 1, trR, 0, MAX_TRAIL - 1);
            System.arraycopy(trT, 1, trT, 0, MAX_TRAIL - 1);
            trN--;
        }
        trX[trN] = x;
        trY[trN] = y;
        trR[trN] = r;
        trT[trN] = time;
        trN++;
    }

    // ---------------------------------------------------------------- отрисовка

    @Override
    protected void onDraw(Canvas c) {
        if (w == 0) return;
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 1f / 60f : Math.min(0.05f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        time += dt;
        stepFlakes(dt);

        c.drawRect(0, 0, w, h, skyPaint);
        c.drawPath(ground, groundPaint);
        drawTrail(c);

        if (sm.n > 0) art.drawSnowman(c, sm, stackX, baseY, d);
        if (held != null && sm.n < Snowman.MAX_BALLS) drawGhost(c);

        for (Loose b : loose) {
            if (b == held) continue;
            drawLoose(c, b);
        }
        if (held != null) drawLoose(c, held);

        for (int i = 0; i < FLAKES; i++) {
            flakePaint.setColor(((int) (255 * (0.45f + 0.55f * fz[i])) << 24) | 0xFFFFFF);
            c.drawCircle(fx[i], fy[i], fr[i], flakePaint);
        }

        drawHint(c);
        if (trayOpen) drawTray(c);
        if (heldToy != null) {
            float s = heldFromSnowman ? d * heldToy.scale : d * 1.1f;
            art.drawToy(c, heldToy.type, hx, hy - 14f * d, s, heldFromSnowman && heldToy.flip);
        }
        if (running) postInvalidateOnAnimation();
    }

    private void drawLoose(Canvas c, Loose b) {
        float r = b.r * d;
        fillShadow(c, b.x, b.y + r * 0.92f, r);
        art.drawBall(c, b.x, b.y, r, b.rot);
    }

    private void fillShadow(Canvas c, float x, float y, float r) {
        trailPaint.setAlpha(60);
        rf.set(x - r * 0.9f, y - r * 0.12f, x + r * 0.9f, y + r * 0.22f);
        c.drawOval(rf, trailPaint);
        trailPaint.setAlpha(255);
    }

    /** Пунктирный круг на месте, куда встанет следующий шар. */
    private void drawGhost(Canvas c) {
        float gr = Math.max(14f, Math.min(40f, sm.maxRadiusForNext() * 0.8f));
        float cy;
        if (sm.n == 0) cy = baseY - gr * d;
        else cy = baseY + (sm.cy(sm.n - 1) - (sm.r[sm.n - 1] + gr) * Snowman.OVERLAP) * d;
        c.drawCircle(stackX, cy, gr * d, ghostPaint);
    }

    /** Утоптанный снег там, где прокатили ком; со временем снегопад его заметает. */
    private void drawTrail(Canvas c) {
        while (trN > 0 && time - trT[0] > TRAIL_LIFE) {
            System.arraycopy(trX, 1, trX, 0, trN - 1);
            System.arraycopy(trY, 1, trY, 0, trN - 1);
            System.arraycopy(trR, 1, trR, 0, trN - 1);
            System.arraycopy(trT, 1, trT, 0, trN - 1);
            trN--;
        }
        if (trN == 0) return;
        c.save();
        c.clipPath(ground);
        for (int bucket = 0; bucket < 3; bucket++) {
            trailPaint.setAlpha(bucket == 0 ? 70 : bucket == 1 ? 130 : 200);
            for (int i = 0; i < trN; i++) {
                float age = (time - trT[i]) / TRAIL_LIFE;
                int bk = age > 0.66f ? 0 : age > 0.33f ? 1 : 2;
                if (bk == bucket) c.drawCircle(trX[i], trY[i], trR[i], trailPaint);
            }
        }
        trailPaint.setAlpha(255);
        c.restore();
    }

    private void drawTray(Canvas c) {
        float top = trayTop(), cw = trayCell(), pad = 8f * d;
        rf.set(0, top - 6f * d, w, h + 20f * d);
        c.drawRoundRect(rf, 18f * d, 18f * d, trayPaint);
        for (int i = 0; i < Snowman.TOY_COUNT; i++) {
            float x = pad + (i % TOY_COLS) * cw, y = top + pad + (i / TOY_COLS) * cw;
            rf.set(x + 3f * d, y + 3f * d, x + cw - 3f * d, y + cw - 3f * d);
            c.drawRoundRect(rf, 12f * d, 12f * d, cellPaint);
            art.drawToy(c, i, x + cw / 2f, y + cw / 2f, cw / 78f, false);
        }
    }

    private void drawHint(Canvas c) {
        String hint = sm.n == 0 ? hintRoll : sm.n < Snowman.MAX_BALLS ? hintStack
                : sm.toys.isEmpty() ? hintToys : hintDone;
        if (hint == null || hint.isEmpty()) return;
        float x = 16f * d, y = 84f * d, maxW = w - 32f * d;
        int start = 0, lines = 0;
        while (start < hint.length() && lines < 3) {
            int cnt = textPaint.breakText(hint, start, hint.length(), true, maxW, null);
            int end = start + Math.max(1, cnt);
            if (end < hint.length()) {
                int sp = hint.lastIndexOf(' ', end);
                if (sp > start) end = sp;
            }
            c.drawText(hint, start, end, x, y, textPaint);
            y += textPaint.getTextSize() * 1.25f;
            start = end;
            while (start < hint.length() && hint.charAt(start) == ' ') start++;
            lines++;
        }
    }
}
