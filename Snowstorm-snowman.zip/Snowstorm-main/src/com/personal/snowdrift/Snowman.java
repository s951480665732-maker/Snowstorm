package com.personal.snowdrift;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Снеговик: до трёх шаров друг на друге и игрушки. Все размеры — в «единицах модели» (1 единица = 1 dp),
 * начало координат — точка на земле под центром нижнего шара, ось y направлена вниз (вверх — минус).
 */
final class Snowman {
    static final int MAX_BALLS = 3;
    static final float R_MAX = 58f, R_MIN = 12f;
    /** Шары заходят друг в друга: расстояние между центрами = (r1 + r2) * OVERLAP. */
    static final float OVERLAP = 0.82f;

    // виды игрушек
    static final int CARROT = 0, COAL = 1, BUTTON = 2, SCARF = 3, TOP_HAT = 4, BUCKET = 5,
            SANTA_HAT = 6, STICK = 7, BROOM = 8, ORNAMENT = 9;
    static final int TOY_COUNT = 10;

    private static final String FILE = "snowman.bin";
    private static final int VERSION = 1;

    static final class Toy {
        int type, ball;
        float x, y, scale;
        boolean flip;

        Toy(int type, float x, float y, float scale, boolean flip, int ball) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.scale = scale;
            this.flip = flip;
            this.ball = ball;
        }

        Toy copy() {
            return new Toy(type, x, y, scale, flip, ball);
        }
    }

    final float[] r = new float[MAX_BALLS];
    int n;
    final ArrayList<Toy> toys = new ArrayList<>();

    /** Порядок отрисовки: палки и метла — за шарами, шарф — на шарах, лицо, потом шапки. */
    static int layer(int type) {
        switch (type) {
            case STICK:
            case BROOM:
                return -1;
            case SCARF:
                return 1;
            case TOP_HAT:
            case BUCKET:
            case SANTA_HAT:
                return 3;
            default:
                return 2;
        }
    }

    static boolean isHat(int type) {
        return type == TOP_HAT || type == BUCKET || type == SANTA_HAT;
    }

    /** Расстояние от центра шапки до её нижнего края (единицы игрушки). */
    static float hatBottom(int type) {
        return type == TOP_HAT ? 20f : type == BUCKET ? 18f : 16f;
    }

    /** Центр шара i по вертикали (вверх — отрицательное). */
    float cy(int i) {
        float y = -r[0];
        for (int k = 1; k <= i; k++) y -= (r[k - 1] + r[k]) * OVERLAP;
        return y;
    }

    float topY() {
        return n == 0 ? 0f : cy(n - 1) - r[n - 1];
    }

    /** Самый большой шар, который можно поставить следующим. */
    float maxRadiusForNext() {
        return n == 0 ? R_MAX : r[n - 1] * 0.88f;
    }

    boolean addBall(float radius) {
        if (n >= MAX_BALLS) return false;
        float rr = Math.min(Math.max(R_MIN, radius), maxRadiusForNext()); // до n++: лимит считается от шара под ним
        r[n++] = rr;
        return true;
    }

    void removeTopBall() {
        if (n == 0) return;
        n--;
        for (int i = toys.size() - 1; i >= 0; i--) {
            if (toys.get(i).ball >= n) toys.remove(i);
        }
    }

    int nearestBall(float x, float y) {
        int best = -1;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            float dx = x, dy = y - cy(i);
            float dd = dx * dx + dy * dy;
            if (dd < bd) {
                bd = dd;
                best = i;
            }
        }
        return best;
    }

    /** Игрушку можно повесить, если она рядом с каким-нибудь шаром. */
    boolean accepts(float x, float y) {
        for (int i = 0; i < n; i++) {
            float dy = y - cy(i);
            if (Math.sqrt(x * x + dy * dy) < r[i] + 40f) return true;
        }
        return false;
    }

    /** {minX, minY, maxX, maxY} в единицах модели, с запасом под игрушки. */
    float[] bounds() {
        float minX = 0, maxX = 0, minY = 0, maxY = 0;
        for (int i = 0; i < n; i++) {
            minX = Math.min(minX, -r[i]);
            maxX = Math.max(maxX, r[i]);
            minY = Math.min(minY, cy(i) - r[i]);
        }
        for (Toy t : toys) {
            float e = 36f * t.scale;
            minX = Math.min(minX, t.x - e);
            maxX = Math.max(maxX, t.x + e);
            minY = Math.min(minY, t.y - e);
            maxY = Math.max(maxY, t.y + e);
        }
        return new float[]{minX - 6f, minY - 6f, maxX + 6f, maxY + 8f};
    }

    // ---------------------------------------------------------------- хранение

    static Snowman load(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return null;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f)))) {
            if (in.readInt() != VERSION) return null;
            Snowman s = new Snowman();
            int nb = in.readInt();
            if (nb < 0 || nb > MAX_BALLS) return null;
            for (int i = 0; i < nb; i++) s.r[s.n++] = in.readFloat();
            int nt = in.readInt();
            if (nt < 0 || nt > 64) return null;
            for (int i = 0; i < nt; i++) {
                int type = in.readInt();
                float x = in.readFloat(), y = in.readFloat(), sc = in.readFloat();
                boolean flip = in.readBoolean();
                int ball = in.readInt();
                if (type >= 0 && type < TOY_COUNT) s.toys.add(new Toy(type, x, y, sc, flip, ball));
            }
            return s.n == 0 ? null : s;
        } catch (Exception e) {
            return null;
        }
    }

    /** Пустого снеговика не храним — файл удаляется. */
    static void save(Context c, Snowman s) {
        File f = new File(c.getFilesDir(), FILE);
        if (s == null || s.n == 0) {
            f.delete();
            return;
        }
        File tmp = new File(f.getPath() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
            out.writeInt(VERSION);
            out.writeInt(s.n);
            for (int i = 0; i < s.n; i++) out.writeFloat(s.r[i]);
            out.writeInt(s.toys.size());
            for (Toy t : s.toys) {
                out.writeInt(t.type);
                out.writeFloat(t.x);
                out.writeFloat(t.y);
                out.writeFloat(t.scale);
                out.writeBoolean(t.flip);
                out.writeInt(t.ball);
            }
        } catch (Exception e) {
            return;
        }
        tmp.renameTo(f);
    }
}
