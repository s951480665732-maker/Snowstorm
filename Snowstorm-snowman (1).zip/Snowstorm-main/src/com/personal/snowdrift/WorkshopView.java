package com.personal.snowdrift;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

/**
 * Мастерская: катаешь комья по снегу и лепишь до двух снеговиков, украшаешь ёлку (звёзды, гирлянда,
 * игрушки), а на празднике LEGO строишь из кубиков. Игрушки лежат в ящике, который прокручивается.
 * Снег в мастерской тоже падает туда, куда наклонён телефон.
 */
public class WorkshopView extends View {
    private static final int MAX_LOOSE = 5, MAX_TRAIL = 200, FLAKES = 90;
    private static final float LOOSE_START = 13f, LOOSE_MAX = Snowman.R_MAX, TRAIL_LIFE = 6f;
    static final int M_SNOW = 0, M_TREE = 1, M_LEGO = 2;

    /** Ком, который катают (x, y — пиксели, r — dp). */
    private static final class Loose {
        float x, y, r, rot;
    }

    private final float d;
    private final Random rnd = new Random();
    private final SnowmanArt art = new SnowmanArt();
    private final TreeArt treeArt = new TreeArt();
    private final LegoArt legoArt = new LegoArt();

    private final ArrayList<Snowman> snowmen;
    private Snowman sm;
    private int cur;
    private Tree tree;
    private Lego lego;
    private int modeIdx;                 // 0 снеговик 1, 1 снеговик 2, 2 ёлка, 3 LEGO
    private boolean legoAllowed, takeSnow;
    private boolean dirtySnow, dirtyTree, dirtyLego, running = true;
    private float noSnowT;

    private final ArrayList<Loose> loose = new ArrayList<>();
    private Loose held;
    private float offX, offY;

    // что сейчас в руке
    private Snowman.Toy heldToy;
    private boolean heldFromSnowman;
    private int treeItem = -1;
    private Tree.Orn treeOrn;
    private boolean treeFromTree;
    private boolean legoHeld, legoFromLego;
    private int legoW, legoColor;
    private float hx, hy, downX, downY;
    private boolean moved;

    // ящик
    private boolean trayOpen, trayTouch, trayDecided;
    private float trayScroll, trayScroll0;
    private int trayItem;

    // следы от катания
    private final float[] trX = new float[MAX_TRAIL], trY = new float[MAX_TRAIL], trR = new float[MAX_TRAIL], trT = new float[MAX_TRAIL];
    private int trN;
    private float lastTrX = -1e9f, lastTrY = -1e9f;

    // падающий снег
    private final float[] fx = new float[FLAKES], fy = new float[FLAKES], fz = new float[FLAKES];
    private final float[] fr = new float[FLAKES], fph = new float[FLAKES];
    private float dirx, diry = 1f, tdx, tdy = 1f;
    private final float[] tmp = new float[2];

    private int w, h;
    private float fieldTop, baseY, stackX;
    private long lastNanos;
    private float time;

    private String[] hints = new String[8];

    private final Paint skyPaint = new Paint();
    private final Paint groundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flakePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cellPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path ground = new Path();
    private final RectF rf = new RectF();

    public WorkshopView(Context c) {
        super(c);
        d = getResources().getDisplayMetrics().density;
        snowmen = Snowman.loadAll(c);
        sm = snowmen.get(0);
        tree = Tree.load(c);
        lego = Lego.load(c);
        for (int i = 0; i < hints.length; i++) hints[i] = "";

        trailPaint.setColor(0xFF9DB4CE);
        ghostPaint.setStyle(Paint.Style.STROKE);
        ghostPaint.setStrokeWidth(2f * d);
        ghostPaint.setColor(0xAAD6ECFF);
        ghostPaint.setPathEffect(new DashPathEffect(new float[]{10f * d, 8f * d}, 0f));
        trayPaint.setColor(0xEE0A1424);
        cellPaint.setColor(0x26FFFFFF);
        textPaint.setColor(0xCCFFFFFF);
        textPaint.setTextSize(14f * getResources().getDisplayMetrics().scaledDensity);
    }

    // ---------------------------------------------------------------- управление из Activity

    /** Подсказки: 0 катать, 1 поставить шар, 2 игрушки, 3 готово, 4 ёлка пуста, 5 ёлка, 6 LEGO, 7 нет снега. */
    void setHints(String[] hs) {
        hints = hs;
    }

    void setLegoAllowed(boolean allowed) {
        legoAllowed = allowed;
    }

    void setTakeSnow(boolean on) {
        takeSnow = on;
    }

    int modeIndex() {
        return modeIdx;
    }

    /** Следующий режим: снеговик 1 → снеговик 2 → ёлка → (LEGO в праздник). */
    int nextMode() {
        cancelTouch();
        modeIdx = (modeIdx + 1) % (legoAllowed ? 4 : 3);
        cur = modeIdx == 1 ? 1 : 0;
        sm = snowmen.get(cur);
        trayScroll = 0f;
        invalidate();
        return modeIdx;
    }

    private int mode() {
        return modeIdx < 2 ? M_SNOW : modeIdx == 2 ? M_TREE : M_LEGO;
    }

    void setRunning(boolean r) {
        running = r;
        if (r) {
            lastNanos = 0;
            invalidate();
        }
    }

    /** Куда тянет вниз, в координатах экрана (м/с²). */
    void setGravity(float gx, float gy) {
        Tilt.direction(gx, gy, tmp);
        tdx = tmp[0];
        tdy = tmp[1];
    }

    void toggleTray() {
        trayOpen = !trayOpen;
        invalidate();
    }

    /** Убрать последнее: игрушку, а когда их нет — шар / звезду и гирлянду / верхний кубик. */
    void undo() {
        switch (mode()) {
            case M_SNOW:
                if (!sm.toys.isEmpty()) sm.toys.remove(sm.toys.size() - 1);
                else sm.removeTopBall();
                dirtySnow = true;
                break;
            case M_TREE:
                if (!tree.orns.isEmpty()) tree.orns.remove(tree.orns.size() - 1);
                else if (tree.star != Tree.STAR_NONE) tree.star = Tree.STAR_NONE;
                else tree.garland = false;
                dirtyTree = true;
                break;
            default:
                if (!lego.bricks.isEmpty()) lego.bricks.remove(lego.bricks.size() - 1);
                dirtyLego = true;
        }
        invalidate();
    }

    /** Начать заново то, что открыто сейчас (текущего снеговика, ёлку или постройку). */
    void reset() {
        cancelTouch();
        switch (mode()) {
            case M_SNOW:
                sm = new Snowman();
                snowmen.set(cur, sm);
                loose.clear();
                held = null;
                trN = 0;
                dirtySnow = true;
                break;
            case M_TREE:
                tree = new Tree();
                dirtyTree = true;
                break;
            default:
                lego = new Lego();
                dirtyLego = true;
        }
        invalidate();
    }

    /** Сохраняет всё изменённое и сообщает слою со снегом, что пора перерисовать. */
    void save() {
        cancelTouch();
        SharedPreferences p = Prefs.get(getContext());
        SharedPreferences.Editor ed = p.edit();
        boolean any = false;
        if (dirtySnow) {
            dirtySnow = false;
            Snowman.saveAll(getContext(), snowmen);
            ed.putInt(Prefs.SNOWMAN_REV, Prefs.snowmanRev(p) + 1);
            any = true;
        }
        if (dirtyTree) {
            dirtyTree = false;
            Tree.save(getContext(), tree);
            ed.putInt(Prefs.TREE_REV, Prefs.treeRev(p) + 1);
            any = true;
        }
        if (dirtyLego) {
            dirtyLego = false;
            Lego.save(getContext(), lego);
            ed.putInt(Prefs.LEGO_REV, Prefs.legoRev(p) + 1);
            any = true;
        }
        if (any) ed.apply();
    }

    // ---------------------------------------------------------------- размеры

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw;
        h = nh;
        fieldTop = h * 0.50f;
        baseY = fieldTop + (h - fieldTop) * 0.78f;
        stackX = w * 0.5f;
        skyPaint.setShader(new LinearGradient(0, 0, 0, fieldTop + 20f * d, 0xFF10233D, 0xFF35618F, Shader.TileMode.CLAMP));
        groundPaint.setShader(new LinearGradient(0, fieldTop, 0, h, 0xFFFFFFFF, 0xFFD3E2F3, Shader.TileMode.CLAMP));
        ground.rewind();
        ground.moveTo(0, fieldTop + 14f * d);
        ground.quadTo(w * 0.5f, fieldTop - 16f * d, w, fieldTop + 10f * d);
        ground.lineTo(w, h);
        ground.lineTo(0, h);
        ground.close();
        for (int i = 0; i < FLAKES; i++) spawnFlake(i, true);
    }

    // ---------------------------------------------------------------- падающий снег

    private void spawnFlake(int i, boolean anywhere) {
        fz[i] = rnd.nextFloat();
        fr[i] = (0.9f + 2.2f * fz[i]) * d;
        fph[i] = rnd.nextFloat() * 6.283f;
        float px = rnd.nextFloat() * w, py = rnd.nextFloat() * h;
        if (anywhere) {
            fx[i] = px;
            fy[i] = py;
            return;
        }
        float mg = fr[i] + 6f * d;
        float tx = Float.MAX_VALUE, ty = Float.MAX_VALUE;
        if (dirx > 1e-4f) tx = (px + mg) / dirx;
        else if (dirx < -1e-4f) tx = (w + mg - px) / -dirx;
        if (diry > 1e-4f) ty = (py + mg) / diry;
        else if (diry < -1e-4f) ty = (h + mg - py) / -diry;
        float t = Math.min(tx, ty) + 1f;
        fx[i] = px - dirx * t;
        fy[i] = py - diry * t;
    }

    private void stepFlakes(float dt) {
        float k = Math.min(1f, dt * 4f);
        dirx += (tdx - dirx) * k;
        diry += (tdy - diry) * k;
        float dl = (float) Math.hypot(dirx, diry);
        if (dl < 0.2f) {
            dirx = 0f;
            diry = 1f;
        } else {
            dirx /= dl;
            diry /= dl;
        }
        for (int i = 0; i < FLAKES; i++) {
            fph[i] += (0.8f + fz[i]) * dt;
            float sp = 55f * d * (0.5f + 0.7f * fz[i]);
            float sw = (float) Math.cos(fph[i]) * 10f * d * (0.4f + fz[i]);
            float vx = dirx * sp - diry * sw, vy = diry * sp + dirx * sw;
            fx[i] += vx * dt;
            fy[i] += vy * dt;
            float m = fr[i] + 4f * d;
            if ((fx[i] < -m && vx <= 0) || (fx[i] > w + m && vx >= 0)
                    || (fy[i] < -m && vy <= 0) || (fy[i] > h + m && vy >= 0)) {
                spawnFlake(i, false);
            }
        }
    }

    // ---------------------------------------------------------------- ящик

    private float trayCell() {
        return 64f * d;
    }

    private float trayHeight() {
        return 2f * trayCell() + 16f * d;
    }

    private float trayTop() {
        return h - trayHeight();
    }

    private int trayCount() {
        switch (mode()) {
            case M_SNOW: return Snowman.TOY_COUNT;
            case M_TREE: return Tree.ITEM_COUNT;
            default: return Lego.TRAY_COUNT;
        }
    }

    private int trayCols() {
        return (trayCount() + 1) / 2;
    }

    private float trayMaxScroll() {
        return Math.max(0f, trayCols() * trayCell() + 16f * d - w);
    }

    /** Номер предмета в ящике под пальцем или -1 (предметы идут по два в столбце). */
    private int trayHit(float x, float y) {
        float cw = trayCell(), pad = 8f * d;
        int col = (int) Math.floor((x + trayScroll - pad) / cw), row = (int) Math.floor((y - trayTop() - pad) / cw);
        if (col < 0 || col >= trayCols() || row < 0 || row > 1) return -1;
        int idx = col * 2 + row;
        return idx < trayCount() ? idx : -1;
    }

    private void drawTrayItem(Canvas c, int i, float cx, float cy, float cw) {
        switch (mode()) {
            case M_SNOW:
                art.drawToy(c, i, cx, cy, cw / 78f, false);
                break;
            case M_TREE:
                treeArt.icon(c, i, cx, cy, cw / 72f, time);
                break;
            default: {
                int bw = Lego.TRAY_WIDTHS[i];
                float s = cw * 0.84f / (Math.max(bw, 4) * Lego.UNIT);
                legoArt.brick(c, cx - bw * Lego.UNIT * s / 2f, cy - Lego.BRICK_H * s / 2f, bw, Lego.trayColor(i), s);
            }
        }
    }

    private void drawTray(Canvas c) {
        float top = trayTop(), cw = trayCell(), pad = 8f * d;
        rf.set(0, top - 6f * d, w, h + 20f * d);
        c.drawRoundRect(rf, 18f * d, 18f * d, trayPaint);
        c.save();
        c.clipRect(0, top, w, h);
        for (int i = 0; i < trayCount(); i++) {
            float x = pad + (i / 2) * cw - trayScroll, y = top + pad + (i % 2) * cw;
            if (x + cw < 0 || x > w) continue;
            rf.set(x + 3f * d, y + 3f * d, x + cw - 3f * d, y + cw - 3f * d);
            c.drawRoundRect(rf, 12f * d, 12f * d, cellPaint);
            drawTrayItem(c, i, x + cw / 2f, y + cw / 2f, cw);
        }
        c.restore();
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ---------------------------------------------------------------- касания

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDown(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                touchMove(x, y);
                return true;
            case MotionEvent.ACTION_UP:
                touchUp(x, y);
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelTouch();
                return true;
            default:
                return true;
        }
    }

    private void touchDown(float x, float y) {
        downX = x;
        downY = y;
        moved = false;
        if (trayOpen && y >= trayTop()) {
            trayTouch = true;
            trayDecided = false;
            trayItem = trayHit(x, y);
            trayScroll0 = trayScroll;
            return;
        }
        switch (mode()) {
            case M_SNOW: snowDown(x, y); break;
            case M_TREE: treeDown(x, y); break;
            default: legoDown(x, y);
        }
    }

    private void touchMove(float x, float y) {
        if (trayTouch) {
            trayMove(x, y);
            return;
        }
        if (Math.hypot(x - downX, y - downY) > 8f * d) moved = true;
        switch (mode()) {
            case M_SNOW: snowMove(x, y); break;
            case M_TREE:
            case M_LEGO:
                hx = x;
                hy = y;
                break;
            default:
                break;
        }
    }

    private void touchUp(float x, float y) {
        if (trayTouch) {
            trayTouch = false;
            return;
        }
        switch (mode()) {
            case M_SNOW: snowUp(x, y); break;
            case M_TREE: treeUp(x, y); break;
            default: legoUp(x, y);
        }
        invalidate();
    }

    /** Ящик: движение вбок прокручивает, движение вверх — вытаскивает предмет. */
    private void trayMove(float x, float y) {
        float dx = x - downX, dy = y - downY;
        if (!trayDecided && Math.hypot(dx, dy) > 10f * d) {
            trayDecided = true;
            if (trayItem >= 0 && Math.abs(dy) > Math.abs(dx) * 0.7f) {
                beginTrayDrag(trayItem, x, y);
                trayTouch = false;
                return;
            }
        }
        if (trayDecided) trayScroll = clamp(trayScroll0 - dx, 0f, trayMaxScroll());
    }

    private void beginTrayDrag(int item, float x, float y) {
        hx = x;
        hy = y;
        moved = true;
        switch (mode()) {
            case M_SNOW:
                heldToy = new Snowman.Toy(item, 0f, 0f, 1f, false, 0);
                heldFromSnowman = false;
                break;
            case M_TREE:
                treeItem = item;
                treeOrn = null;
                treeFromTree = false;
                break;
            default:
                legoHeld = true;
                legoFromLego = false;
                legoW = Lego.TRAY_WIDTHS[item];
                legoColor = Lego.trayColor(item);
        }
    }

    /** Палец «оторвали не по-настоящему» (уход из приложения): взятое возвращается на место. */
    private void cancelTouch() {
        if (heldToy != null && heldFromSnowman) sm.toys.add(heldToy);
        if (treeOrn != null && treeFromTree) tree.orns.add(treeOrn);
        heldToy = null;
        held = null;
        treeItem = -1;
        treeOrn = null;
        legoHeld = false;
        trayTouch = false;
    }

    // ---------------------------------------------------------------- снеговик

    private float stackTopPx() {
        return baseY + sm.topY() * d;
    }

    private float toyPx(Snowman.Toy t) {
        return stackX + t.x * d;
    }

    private float toyPy(Snowman.Toy t) {
        return baseY + t.y * d;
    }

    private Snowman.Toy toyAt(float x, float y) {
        for (int l = 3; l >= -1; l--) {
            for (int i = sm.toys.size() - 1; i >= 0; i--) {
                Snowman.Toy t = sm.toys.get(i);
                if (Snowman.layer(t.type) != l) continue;
                float rr = (26f * t.scale + 6f) * d;
                if (Math.hypot(x - toyPx(t), y - toyPy(t)) <= rr) return t;
            }
        }
        return null;
    }

    private void snowDown(float x, float y) {
        Snowman.Toy hit = toyAt(x, y);
        if (hit != null) {
            sm.toys.remove(hit);
            heldToy = hit;
            heldFromSnowman = true;
            hx = x;
            hy = y;
            return;
        }
        for (int i = loose.size() - 1; i >= 0; i--) {
            Loose b = loose.get(i);
            if (Math.hypot(x - b.x, y - b.y) <= b.r * d + 10f * d) {
                held = b;
                offX = b.x - x;
                offY = b.y - y;
                loose.remove(i);
                loose.add(b);
                lastTrX = lastTrY = -1e9f;
                return;
            }
        }
        if (y > fieldTop) {
            if (loose.size() >= MAX_LOOSE) loose.remove(0);
            Loose b = new Loose();
            b.x = x;
            b.y = y;
            b.r = LOOSE_START;
            loose.add(b);
            held = b;
            offX = offY = 0f;
            lastTrX = lastTrY = -1e9f;
        }
    }

    private void snowMove(float x, float y) {
        if (held != null) {
            Loose b = held;
            float r = b.r * d;
            float nx = clamp(x + offX, r, w - r), ny = clamp(y + offY, r, h - r * 0.6f);
            float dx = nx - b.x, dy = ny - b.y;
            float dist = (float) Math.hypot(dx, dy);
            b.x = nx;
            b.y = ny;
            if (ny > fieldTop && dist > 0f) {
                float sign = dx != 0f ? Math.signum(dx) : Math.signum(dy);
                b.rot += sign * dist / r * 57.2958f;
                if (b.r < LOOSE_MAX) {
                    float grow = dist / d * 0.05f * (1f - 0.55f * b.r / LOOSE_MAX);
                    if (takeSnow) grow *= takeFromDrift(b.r, grow);
                    b.r = Math.min(LOOSE_MAX, b.r + grow);
                }
                addTrail(nx, ny + b.r * d * 0.35f, b.r * d * 0.75f);
            }
        } else if (heldToy != null) {
            hx = x;
            hy = y;
        }
    }

    /**
     * «Брать снег»: ком растёт за счёт настоящего сугроба — площадь прироста вычитается из него.
     * Возвращает долю (0..1) прироста, на которую снега хватило.
     */
    private float takeFromDrift(float r, float growDp) {
        float colWdp = w / d / (DriftStore.COLS - 1);
        float cols = (float) (2.0 * Math.PI * r * growDp) / colWdp;
        float got = SnowService.takeSnow(cols);
        float ratio = cols <= 1e-6f ? 1f : Math.min(1f, got / cols);
        if (ratio < 0.5f) noSnowT = 2.5f;
        return ratio;
    }

    private void snowUp(float x, float y) {
        if (held != null) {
            Loose b = held;
            held = null;
            boolean inZone = Math.abs(b.x - stackX) < 85f * d
                    && b.y > stackTopPx() - 100f * d && b.y < baseY + 60f * d;
            if (inZone && sm.addBall(b.r)) {
                loose.remove(b);
                dirtySnow = true;
            }
        } else if (heldToy != null) {
            Snowman.Toy t = heldToy;
            heldToy = null;
            if (heldFromSnowman && !moved) {
                sm.toys.add(t);
                return;
            }
            float mx = (x - stackX) / d, my = (y - baseY) / d;
            if (sm.n > 0 && !(trayOpen && y >= trayTop()) && sm.accepts(mx, my)) {
                placeToy(t, mx, my, !heldFromSnowman);
                sm.toys.add(t);
                dirtySnow = true;
            } else if (heldFromSnowman) {
                dirtySnow = true; // утащили в сторону — игрушка убрана
            }
        }
    }

    /** Ставит игрушку: считает размер, зеркало и «прилипание» шапки к голове, а шарфа — к шее. */
    private void placeToy(Snowman.Toy t, float mx, float my, boolean isNew) {
        int bi = sm.nearestBall(mx, my);
        float rb = sm.r[bi];
        t.ball = bi;
        if (isNew) t.scale = clamp(rb / 36f, 0.6f, 1.4f);
        t.x = mx;
        t.y = my;
        t.flip = mx < -2f;
        if (Snowman.isHat(t.type)) {
            int head = sm.n - 1;
            if (bi == head) {
                float hr = sm.r[head];
                t.ball = head;
                t.scale = clamp(hr / 36f, 0.6f, 1.4f);
                t.x = clamp(mx, -hr * 0.3f, hr * 0.3f);
                t.y = sm.cy(head) - hr * 0.82f - Snowman.hatBottom(t.type) * t.scale;
            }
        } else if (t.type == Snowman.SCARF) {
            int best = -1;
            float bd = 28f, ny = 0f;
            for (int i = 1; i < sm.n; i++) {
                float neck = (sm.cy(i) + sm.r[i] + sm.cy(i - 1) - sm.r[i - 1]) / 2f;
                if (Math.abs(my - neck) < bd) {
                    bd = Math.abs(my - neck);
                    best = i;
                    ny = neck;
                }
            }
            if (best > 0) {
                t.ball = best;
                t.y = ny;
                t.x = clamp(mx, -sm.r[best] * 0.25f, sm.r[best] * 0.25f);
                t.scale = clamp(sm.r[best] / 30f, 0.6f, 1.5f);
            }
        }
    }

    private void addTrail(float x, float y, float r) {
        if (Math.hypot(x - lastTrX, y - lastTrY) < r * 0.6f) return;
        lastTrX = x;
        lastTrY = y;
        if (trN == MAX_TRAIL) {
            System.arraycopy(trX, 1, trX, 0, MAX_TRAIL - 1);
            System.arraycopy(trY, 1, trY, 0, MAX_TRAIL - 1);
            System.arraycopy(trR, 1, trR, 0, MAX_TRAIL - 1);
            System.arraycopy(trT, 1, trT, 0, MAX_TRAIL - 1);
            trN--;
        }
        trX[trN] = x;
        trY[trN] = y;
        trR[trN] = r;
        trT[trN] = time;
        trN++;
    }

    // ---------------------------------------------------------------- ёлка

    private float treeScale() {
        return 1.5f * d;
    }

    private float treeBaseY() {
        return baseY;
    }

    private void treeDown(float x, float y) {
        float ts = treeScale(), mx = (x - stackX) / ts, my = (y - treeBaseY()) / ts;
        if (tree.star != Tree.STAR_NONE && Math.hypot(mx, my + 148f) < 16f) {
            treeItem = tree.star == Tree.STAR_GLOW ? Tree.ITEM_STAR_GLOW : Tree.ITEM_STAR_PLAIN;
            tree.star = Tree.STAR_NONE;
            treeOrn = null;
            treeFromTree = true;
            hx = x;
            hy = y;
            return;
        }
        for (int i = tree.orns.size() - 1; i >= 0; i--) {
            Tree.Orn o = tree.orns.get(i);
            if (Math.hypot(mx - o.x, my - o.y) <= 9f * o.scale + 3f) {
                tree.orns.remove(i);
                treeOrn = o;
                treeItem = o.type;
                treeFromTree = true;
                hx = x;
                hy = y;
                return;
            }
        }
    }

    private void treeUp(float x, float y) {
        if (treeItem < 0) return;
        int item = treeItem;
        Tree.Orn o = treeOrn;
        boolean fromTree = treeFromTree;
        treeItem = -1;
        treeOrn = null;
        if (fromTree && !moved) { // просто тап — вернуть на место
            if (o != null) tree.orns.add(o);
            else tree.star = item == Tree.ITEM_STAR_GLOW ? Tree.STAR_GLOW : Tree.STAR_PLAIN;
            return;
        }
        if (trayOpen && y >= trayTop()) { // уронили в ящик — убрано
            dirtyTree = true;
            return;
        }
        float ts = treeScale(), mx = (x - stackX) / ts, my = (y - treeBaseY()) / ts;
        if (item < Tree.ORN_COUNT) {
            if (Tree.contains(mx, my)) {
                tree.orns.add(o != null ? new Tree.Orn(item, mx, my, o.scale) : new Tree.Orn(item, mx, my, 1.25f));
            }
        } else if (item == Tree.ITEM_GARLAND) {
            if (Tree.contains(mx, my)) tree.garland = !tree.garland;
        } else if (my < -105f && Math.abs(mx) < 45f) { // звезда — на верхушку
            tree.star = item == Tree.ITEM_STAR_GLOW ? Tree.STAR_GLOW : Tree.STAR_PLAIN;
        }
        dirtyTree = true;
    }

    // ---------------------------------------------------------------- LEGO

    private float legoS() {
        return Math.min(2.2f * d, w * 0.88f / (Lego.COLS * Lego.UNIT));
    }

    private float legoLeft() {
        return (w - Lego.COLS * Lego.UNIT * legoS()) / 2f;
    }

    private void legoDown(float x, float y) {
        float s = legoS();
        float mx = (x - legoLeft()) / s, my = (baseY - Lego.PLATE_H * s - y) / s;
        Lego.Brick b = lego.brickAt(mx, my);
        if (b == null) return;
        lego.bricks.remove(b);
        lego.settle();
        legoHeld = true;
        legoFromLego = true;
        legoW = b.w;
        legoColor = b.color;
        hx = x;
        hy = y;
        dirtyLego = true;
    }

    private void legoUp(float x, float y) {
        if (!legoHeld) return;
        legoHeld = false;
        if (trayOpen && y >= trayTop()) return;
        float s = legoS(), left = legoLeft(), pw = Lego.COLS * Lego.UNIT * s;
        if (x < left - 24f * d || x > left + pw + 24f * d || y > baseY + 30f * d) return;
        int col = Math.round((x - left) / (Lego.UNIT * s) - legoW / 2f);
        if (lego.rowFor(Math.max(0, Math.min(Lego.COLS - legoW, col)), legoW, null) >= 26) return;
        lego.place(col, legoW, legoColor);
        dirtyLego = true;
    }

    // ---------------------------------------------------------------- отрисовка

    @Override
    protected void onDraw(Canvas c) {
        if (w == 0) return;
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 1f / 60f : Math.min(0.05f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        time += dt;
        noSnowT = Math.max(0f, noSnowT - dt);
        stepFlakes(dt);

        c.drawRect(0, 0, w, h, skyPaint);
        c.drawPath(ground, groundPaint);

        switch (mode()) {
            case M_SNOW:
                drawTrail(c);
                if (sm.n > 0) art.drawSnowman(c, sm, stackX, baseY, d);
                if (held != null && sm.n < Snowman.MAX_BALLS) drawGhost(c);
                for (Loose b : loose) {
                    if (b != held) drawLoose(c, b);
                }
                if (held != null) drawLoose(c, held);
                break;
            case M_TREE:
                treeArt.draw(c, tree, stackX, treeBaseY(), treeScale(), time, true);
                break;
            default:
                legoArt.draw(c, lego, legoLeft(), baseY, legoS());
        }

        for (int i = 0; i < FLAKES; i++) {
            flakePaint.setColor(((int) (255 * (0.45f + 0.55f * fz[i])) << 24) | 0xFFFFFF);
            c.drawCircle(fx[i], fy[i], fr[i], flakePaint);
        }

        drawHint(c);
        if (trayOpen) drawTray(c);
        drawHeld(c);
        if (running) postInvalidateOnAnimation();
    }

    private void drawHeld(Canvas c) {
        float y = hy - 14f * d;
        if (heldToy != null) {
            float s = heldFromSnowman ? d * heldToy.scale : d * 1.1f;
            art.drawToy(c, heldToy.type, hx, y, s, heldFromSnowman && heldToy.flip);
        } else if (treeItem >= 0) {
            float s = treeScale();
            if (treeItem < Tree.ORN_COUNT) treeArt.ornament(c, treeItem, hx, y, s * (treeOrn != null ? treeOrn.scale : 1.25f), time, true);
            else treeArt.icon(c, treeItem, hx, y, d * 1.1f, time);
        } else if (legoHeld) {
            float s = legoS();
            legoArt.brick(c, hx - legoW * Lego.UNIT * s / 2f, y - Lego.BRICK_H * s / 2f, legoW, legoColor, s);
        }
    }

    private void drawLoose(Canvas c, Loose b) {
        float r = b.r * d;
        trailPaint.setAlpha(60);
        rf.set(b.x - r * 0.9f, b.y + r * 0.8f, b.x + r * 0.9f, b.y + r * 1.14f);
        c.drawOval(rf, trailPaint);
        trailPaint.setAlpha(255);
        art.drawBall(c, b.x, b.y, r, b.rot);
    }

    /** Пунктирный круг на месте, куда встанет следующий шар. */
    private void drawGhost(Canvas c) {
        float gr = Math.max(14f, Math.min(40f, sm.maxRadiusForNext() * 0.8f));
        float cy;
        if (sm.n == 0) cy = baseY - gr * d;
        else cy = baseY + (sm.cy(sm.n - 1) - (sm.r[sm.n - 1] + gr) * Snowman.OVERLAP) * d;
        c.drawCircle(stackX, cy, gr * d, ghostPaint);
    }

    /** Утоптанный снег там, где прокатили ком; со временем снегопад его заметает. */
    private void drawTrail(Canvas c) {
        while (trN > 0 && time - trT[0] > TRAIL_LIFE) {
            System.arraycopy(trX, 1, trX, 0, trN - 1);
            System.arraycopy(trY, 1, trY, 0, trN - 1);
            System.arraycopy(trR, 1, trR, 0, trN - 1);
            System.arraycopy(trT, 1, trT, 0, trN - 1);
            trN--;
        }
        if (trN == 0) return;
        c.save();
        c.clipPath(ground);
        for (int bucket = 0; bucket < 3; bucket++) {
            trailPaint.setAlpha(bucket == 0 ? 70 : bucket == 1 ? 130 : 200);
            for (int i = 0; i < trN; i++) {
                float age = (time - trT[i]) / TRAIL_LIFE;
                int bk = age > 0.66f ? 0 : age > 0.33f ? 1 : 2;
                if (bk == bucket) c.drawCircle(trX[i], trY[i], trR[i], trailPaint);
            }
        }
        trailPaint.setAlpha(255);
        c.restore();
    }

    private String hintText() {
        if (noSnowT > 0f) return hints[7];
        switch (mode()) {
            case M_SNOW:
                return sm.n == 0 ? hints[0] : sm.n < Snowman.MAX_BALLS ? hints[1] : sm.toys.isEmpty() ? hints[2] : hints[3];
            case M_TREE:
                return tree.isEmpty() ? hints[4] : hints[5];
            default:
                return hints[6];
        }
    }

    private void drawHint(Canvas c) {
        String hint = hintText();
        if (hint == null || hint.isEmpty()) return;
        float x = 16f * d, y = 130f * d, maxW = w - 32f * d;
        int start = 0, lines = 0;
        while (start < hint.length() && lines < 3) {
            int cnt = textPaint.breakText(hint, start, hint.length(), true, maxW, null);
            int end = start + Math.max(1, cnt);
            if (end < hint.length()) {
                int sp = hint.lastIndexOf(' ', end);
                if (sp > start) end = sp;
            }
            c.drawText(hint, start, end, x, y, textPaint);
            y += textPaint.getTextSize() * 1.25f;
            start = end;
            while (start < hint.length() && hint.charAt(start) == ' ') start++;
            lines++;
        }
    }
}
