package com.personal.snowdrift;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Экран настроек: запуск/остановка, мастерская, скорость, количество, высота сугробов, питомцы, ёлка,
 * гирлянда, снегоход. Оформление меняется со временем года; сезон сам выбрать нельзя
 * (кроме скрытого режима разработчика: 7 нажатий на название).
 */
public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final String ORIGINAL_POST = "https://t.me/istratii_tech1/220";
    private static final int[] SEASON_NAMES = {R.string.season_winter, R.string.season_spring, R.string.season_summer, R.string.season_autumn};
    private static final int[] CAT_SKINS = {R.string.cat_skin_0, R.string.cat_skin_1, R.string.cat_skin_2, R.string.cat_skin_3, R.string.cat_skin_4};
    private static final int[] DOG_SKINS = {R.string.dog_skin_0, R.string.dog_skin_1, R.string.dog_skin_2, R.string.dog_skin_3, R.string.dog_skin_4};
    /** Праздничные «падающие» для подмены в режиме разработчика (номера Season.P_*). */
    private static final int[] HOLIDAYS = {Season.P_HEART, Season.P_LEGO, Season.P_TULIP, Season.P_PUMPKIN, Season.P_STAR, Season.P_EGG, Season.P_CONFETTI};
    private static final int[] HOLIDAY_NAMES = {R.string.hol_heart, R.string.hol_lego, R.string.hol_tulip, R.string.hol_pumpkin, R.string.hol_star, R.string.hol_egg, R.string.hol_confetti};

    private int accent, card, textDim;
    private Season now;
    private Season.Palette pal;

    private SharedPreferences prefs;
    private float dp;
    private int titleTaps;
    private TextView serviceText;
    private Button serviceBtn, restrictedBtn, toggleBtn, catSkinBtn, dogSkinBtn, seasonBtn, holidayBtn;
    private Switch stormSwitch, ecoSwitch, tiltSwitch, takeSwitch, shakeSwitch, snowmanSwitch, treeSwitch,
            garlandSwitch, lampSwitch, plowSwitch, catSwitch, dogSwitch;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Prefs.get(this);
        dp = getResources().getDisplayMetrics().density;
        now = Season.now(Prefs.debugSeason(prefs), Prefs.debugParticle(prefs));
        pal = now.palette();
        accent = pal.accent;
        card = pal.card;
        textDim = pal.textDim;
        getWindow().setStatusBarColor(pal.status);
        getWindow().setNavigationBarColor(pal.nav);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = px(20);
        col.setPadding(pad, px(28), pad, px(40));

        TextView title = text(getString(R.string.title), 30, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);
        TextView sub = text(getString(R.string.subtitle), 14, textDim);
        sub.setPadding(0, px(6), 0, px(4));
        col.addView(sub);
        TextView seasonLine = text(seasonLineText(), 14, accent);
        seasonLine.setPadding(0, 0, 0, px(8));
        col.addView(seasonLine);

        // --- предупреждение: это форк
        LinearLayout fork = card(col);
        TextView ft = text(getString(R.string.fork_title), 16, 0xFFFFFFFF);
        ft.setTypeface(Typeface.DEFAULT_BOLD);
        fork.addView(ft);
        TextView fx = text(getString(R.string.fork_text), 13, textDim);
        fx.setPadding(0, px(4), 0, 0);
        fork.addView(fx);
        Button forkBtn = button(getString(R.string.fork_open), 0x22FFFFFF);
        forkBtn.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ORIGINAL_POST))));
        fork.addView(forkBtn, lpTop(10));

        // --- служба спец. возможностей
        LinearLayout svc = card(col);
        serviceText = text("", 15, 0xFFFFFFFF);
        svc.addView(serviceText);
        serviceBtn = button(getString(R.string.open_accessibility), 0x337CC4FF);
        serviceBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        svc.addView(serviceBtn, lpTop(12));
        restrictedBtn = button(getString(R.string.restricted_hint), 0x22FFFFFF);
        restrictedBtn.setTextSize(13);
        restrictedBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        svc.addView(restrictedBtn, lpTop(8));

        // --- запуск/остановка
        toggleBtn = button("", accent);
        toggleBtn.setTextSize(18);
        toggleBtn.setTypeface(Typeface.DEFAULT_BOLD);
        toggleBtn.setTextColor(pal.onAccent);
        toggleBtn.setOnClickListener(v -> prefs.edit().putBoolean(Prefs.ENABLED, !Prefs.enabled(prefs)).apply());
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, px(60));
        tlp.topMargin = px(14);
        col.addView(toggleBtn, tlp);

        // --- мастерская
        Button workshop = button(getString(R.string.workshop_open), 0x33FFFFFF);
        workshop.setTextSize(17);
        workshop.setTypeface(Typeface.DEFAULT_BOLD);
        workshop.setOnClickListener(v -> startActivity(new Intent(this, WorkshopActivity.class)));
        col.addView(workshop, lpTop(14));

        // --- ползунки
        LinearLayout sl = card(col);
        slider(sl, getString(R.string.speed), Prefs.SPEED, Prefs.DEF_SPEED,
                v -> String.format(java.util.Locale.US, "×%.1f", Prefs.speedFactor(v)));
        slider(sl, getString(R.string.count), Prefs.INTENSITY, Prefs.DEF_INTENSITY,
                v -> String.valueOf(Prefs.flakeCount(v)));
        slider(sl, getString(R.string.drift_height), Prefs.DRIFT, Prefs.DEF_DRIFT,
                v -> v >= 100 ? "∞" : Math.round(Prefs.driftMaxDp(v)) + " dp");

        // --- переключатели
        stormSwitch = switchCard(col, R.string.storm_mode, R.string.storm_desc, Prefs.STORM);
        ecoSwitch = switchCard(col, R.string.eco_mode, R.string.eco_desc, Prefs.ECO);
        tiltSwitch = switchCard(col, R.string.tilt_mode, R.string.tilt_desc, Prefs.TILT);
        shakeSwitch = switchCard(col, R.string.shake_mode, R.string.shake_desc, Prefs.SHAKE);
        takeSwitch = switchCard(col, R.string.take_snow, R.string.take_snow_desc, Prefs.TAKE_SNOW);
        snowmanSwitch = switchCard(col, R.string.show_snowman, R.string.show_snowman_desc, Prefs.SHOW_SNOWMAN);
        treeSwitch = switchCard(col, R.string.tree_on, R.string.tree_on_desc, Prefs.TREE);
        garlandSwitch = switchCard(col, R.string.garland_on, R.string.garland_on_desc, Prefs.GARLAND);
        lampSwitch = switchCard(col, R.string.lamp_on, R.string.lamp_on_desc, Prefs.LAMP);
        plowSwitch = switchCard(col, R.string.plow_on, R.string.plow_on_desc, Prefs.PLOW);

        // --- питомцы и скины
        catSwitch = switchCard(col, R.string.cat_on, R.string.cat_on_desc, Prefs.CAT);
        catSkinBtn = button("", 0x22FFFFFF);
        catSkinBtn.setOnClickListener(v -> prefs.edit().putInt(Prefs.CAT_SKIN, (Prefs.catSkin(prefs) + 1) % PetArt.SKINS).apply());
        col.addView(catSkinBtn, lpTop(8));
        dogSwitch = switchCard(col, R.string.dog_on, R.string.dog_on_desc, Prefs.DOG);
        dogSkinBtn = button("", 0x22FFFFFF);
        dogSkinBtn.setOnClickListener(v -> prefs.edit().putInt(Prefs.DOG_SKIN, (Prefs.dogSkin(prefs) + 1) % PetArt.SKINS).apply());
        col.addView(dogSkinBtn, lpTop(8));

        // --- действия: поднять ёлку, вызвать снегоход
        Button raise = button(getString(R.string.raise_tree), 0x22FFFFFF);
        raise.setOnClickListener(v -> {
            prefs.edit().putInt(Prefs.TREE_RAISE, prefs.getInt(Prefs.TREE_RAISE, 0) + 1).apply();
            if (SnowService.instance == null) Toast.makeText(this, R.string.need_service, Toast.LENGTH_SHORT).show();
        });
        col.addView(raise, lpTop(14));
        Button plow = button(getString(R.string.call_plow), 0x22FFFFFF);
        plow.setOnClickListener(v -> {
            prefs.edit().putInt(Prefs.PLOW_CALL, prefs.getInt(Prefs.PLOW_CALL, 0) + 1).apply();
            if (SnowService.instance == null) Toast.makeText(this, R.string.need_service, Toast.LENGTH_SHORT).show();
        });
        col.addView(plow, lpTop(8));

        // --- как убрать
        LinearLayout how = card(col);
        TextView hh = text(getString(R.string.how_title), 16, 0xFFFFFFFF);
        hh.setTypeface(Typeface.DEFAULT_BOLD);
        how.addView(hh);
        TextView ht = text(getString(R.string.how_text), 14, textDim);
        ht.setPadding(0, px(6), 0, 0);
        ht.setLineSpacing(0, 1.15f);
        how.addView(ht);

        Button melt = button(getString(R.string.melt_all), 0x22FFFFFF);
        melt.setOnClickListener(v -> {
            if (SnowService.instance != null) SnowService.instance.clearAllDrifts();
            else deleteFile("drifts.bin");
            Toast.makeText(this, R.string.melted, Toast.LENGTH_SHORT).show();
        });
        col.addView(melt, lpTop(14));

        // --- скрытый режим разработчика (7 нажатий на название)
        LinearLayout dev = card(col);
        dev.setVisibility(View.GONE);
        TextView dt = text(getString(R.string.dev_title), 16, 0xFFFFFFFF);
        dt.setTypeface(Typeface.DEFAULT_BOLD);
        dev.addView(dt);
        seasonBtn = button("", 0x22FFFFFF);
        seasonBtn.setOnClickListener(v -> {
            int s = Prefs.debugSeason(prefs);
            prefs.edit().putInt(Prefs.DEBUG_SEASON, s >= 3 ? -1 : s + 1).putInt(Prefs.DEBUG_PARTICLE, -1).apply();
            recreate();
        });
        dev.addView(seasonBtn, lpTop(8));
        holidayBtn = button("", 0x22FFFFFF);
        holidayBtn.setOnClickListener(v -> {
            int p = Prefs.debugParticle(prefs), idx = -1;
            for (int i = 0; i < HOLIDAYS.length; i++) if (HOLIDAYS[i] == p) idx = i;
            int next = idx + 1 >= HOLIDAYS.length ? -1 : HOLIDAYS[idx + 1];
            prefs.edit().putInt(Prefs.DEBUG_PARTICLE, next).apply();
            recreate();
        });
        dev.addView(holidayBtn, lpTop(8));
        Button ny = button(getString(R.string.dev_newyear), 0x22FFFFFF);
        ny.setOnClickListener(v -> {
            prefs.edit().putInt(Prefs.NY_TEST, prefs.getInt(Prefs.NY_TEST, 0) + 1).apply();
            if (SnowService.instance == null) Toast.makeText(this, R.string.need_service, Toast.LENGTH_SHORT).show();
        });
        dev.addView(ny, lpTop(8));
        title.setOnClickListener(v -> {
            if (++titleTaps >= 7) {
                titleTaps = 0;
                dev.setVisibility(dev.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });

        Button exit = button(getString(R.string.exit_app), 0x33FF7C7C);
        exit.setOnClickListener(v -> new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.exit_title)
                .setMessage(R.string.exit_text)
                .setPositiveButton(R.string.exit_app, (d, w) -> {
                    if (SnowService.instance != null) SnowService.instance.exitApp();
                    else SnowService.killApp(this);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show());
        col.addView(exit, lpTop(14));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{pal.bgTop, pal.bgBottom}));
        sv.addView(col);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (SnowService.instance != null) SnowService.instance.postNotification();
    }

    @Override
    protected void onResume() {
        super.onResume();
        prefs.registerOnSharedPreferenceChangeListener(this);
        refresh();
    }

    @Override
    protected void onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        refresh();
    }

    private String seasonLineText() {
        String s = getString(SEASON_NAMES[now.season]);
        String hol = null;
        for (int i = 0; i < HOLIDAYS.length; i++) if (HOLIDAYS[i] == now.particle) hol = getString(HOLIDAY_NAMES[i]);
        return hol == null ? getString(R.string.season_line, s) : getString(R.string.season_line_hol, s, hol);
    }

    private void refresh() {
        boolean svc = SnowService.instance != null;
        serviceText.setText(svc ? R.string.service_on : R.string.service_off);
        serviceBtn.setVisibility(svc ? View.GONE : View.VISIBLE);
        restrictedBtn.setVisibility(svc ? View.GONE : View.VISIBLE);
        boolean on = Prefs.enabled(prefs);
        toggleBtn.setText(on ? R.string.stop_snow : R.string.start_snow);
        stormSwitch.setChecked(Prefs.storm(prefs));
        ecoSwitch.setChecked(Prefs.eco(prefs));
        tiltSwitch.setChecked(Prefs.tilt(prefs));
        shakeSwitch.setChecked(Prefs.shake(prefs));
        takeSwitch.setChecked(Prefs.takeSnow(prefs));
        snowmanSwitch.setChecked(Prefs.showSnowman(prefs));
        treeSwitch.setChecked(Prefs.tree(prefs));
        garlandSwitch.setChecked(Prefs.garland(prefs));
        lampSwitch.setChecked(Prefs.lamp(prefs));
        plowSwitch.setChecked(Prefs.plow(prefs));
        catSwitch.setChecked(Prefs.cat(prefs));
        dogSwitch.setChecked(Prefs.dog(prefs));
        catSkinBtn.setText(getString(R.string.cat_skin_label, getString(CAT_SKINS[Prefs.catSkin(prefs) % PetArt.SKINS])));
        dogSkinBtn.setText(getString(R.string.dog_skin_label, getString(DOG_SKINS[Prefs.dogSkin(prefs) % PetArt.SKINS])));
        int ds = Prefs.debugSeason(prefs), dpart = Prefs.debugParticle(prefs);
        seasonBtn.setText(getString(R.string.dev_season, ds < 0 ? getString(R.string.dev_auto) : getString(SEASON_NAMES[ds])));
        String hn = getString(R.string.dev_auto);
        for (int i = 0; i < HOLIDAYS.length; i++) if (HOLIDAYS[i] == dpart) hn = getString(HOLIDAY_NAMES[i]);
        holidayBtn.setText(getString(R.string.dev_holiday, hn));
    }

    // ---------------------------------------------------------------- построение экрана

    private interface Fmt { String f(int v); }

    private void slider(LinearLayout parent, String label, String key, int def, Fmt fmt) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView l = text(label, 16, 0xFFFFFFFF);
        row.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
        TextView val = text("", 15, accent);
        val.setGravity(Gravity.END);
        row.addView(val);
        parent.addView(row, lpTop(parent.getChildCount() == 0 ? 0 : 14));

        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        int cur = prefs.getInt(key, def);
        sb.setProgress(cur);
        val.setText(fmt.f(cur));
        sb.setProgressTintList(ColorStateList.valueOf(accent));
        sb.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                val.setText(fmt.f(v));
                if (user) prefs.edit().putInt(key, v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(sb, lpTop(4));
    }

    private Switch switchCard(LinearLayout parent, int title, int desc, String key) {
        LinearLayout c = card(parent);
        Switch sw = new Switch(this);
        sw.setText(title);
        sw.setTextSize(17);
        sw.setTextColor(0xFFFFFFFF);
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{accent, 0xFFCFD8E3}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{(accent & 0xFFFFFF) | 0x88000000, 0x55FFFFFF}));
        sw.setOnCheckedChangeListener((v, on) -> prefs.edit().putBoolean(key, on).apply());
        c.addView(sw);
        TextView d = text(getString(desc), 13, textDim);
        d.setPadding(0, px(4), 0, 0);
        c.addView(d);
        return sw;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(px(16), px(14), px(16), px(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(card);
        bg.setCornerRadius(px(18));
        c.setBackground(bg);
        parent.addView(c, lpTop(14));
        return c;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(15);
        b.setStateListAnimator(null);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(px(14));
        b.setBackground(bg);
        b.setPadding(px(14), px(12), px(14), px(12));
        return b;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams lpTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = px(top);
        return lp;
    }

    private int px(float v) { return Math.round(v * dp); }
}
