package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Рисование ёлки, украшений, звёзд и гирлянды. Один экземпляр — один поток (UI). */
final class TreeArt {
    private final Glow glow = new Glow();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    TreeArt() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
    }

    // ---------------------------------------------------------------- ёлка целиком

    /**
     * Ёлка с основанием в (ox, oy); s — пикселей на единицу модели; time — секунды (мерцание);
     * lit — горят ли гирлянда и лампочки (светящаяся звезда горит всегда).
     */
    void draw(Canvas c, Tree t, float ox, float oy, float s, float time, boolean lit) {
        c.save();
        c.translate(ox, oy);
        c.scale(s, s);
        // ствол
        rect(c, -7f, -16f, 7f, 0f, 1.5f, 0xFF6B4423);
        // ярусы
        tier(c, 0f, -72f, 46f, -12f, 0xFF1B6636, 0xFF14502A);
        tier(c, 0f, -112f, 38f, -48f, 0xFF217A40, 0xFF18602F);
        tier(c, 0f, -146f, 28f, -92f, 0xFF2A9250, 0xFF1D7440);
        if (t.garland) garland(c, time, lit);
        for (Tree.Orn o : t.orns) ornament(c, o.type, o.x, o.y, o.scale, time, lit);
        if (t.star != Tree.STAR_NONE) star(c, 0f, -148f, 1f, t.star == Tree.STAR_GLOW, time);
        c.restore();
    }

    private void tier(Canvas c, float apexX, float apexY, float half, float baseY, int light, int dark) {
        path.rewind();
        path.moveTo(apexX, apexY);
        path.lineTo(apexX + half, baseY);
        path.quadTo(apexX, baseY + 9f, apexX - half, baseY); // низ слегка провисает
        path.close();
        fill.setColor(light);
        c.drawPath(path, fill);
        path.rewind(); // тень справа
        path.moveTo(apexX, apexY);
        path.lineTo(apexX + half, baseY);
        path.quadTo(apexX + half * 0.3f, baseY + 6f, apexX, baseY + 2f);
        path.close();
        fill.setColor(dark);
        c.drawPath(path, fill);
        // снежок на ветках
        fill.setColor(0xCCFFFFFF);
        rf.set(apexX - half * 0.55f, baseY - 3f, apexX - half * 0.25f, baseY + 1.5f);
        c.drawOval(rf, fill);
        rf.set(apexX + half * 0.2f, baseY - 2.5f, apexX + half * 0.5f, baseY + 2f);
        c.drawOval(rf, fill);
    }

    private void garland(Canvas c, float time, boolean lit) {
        float[][] arcs = {{-40f, -32f, 40f, -32f, 14f}, {-33f, -70f, 33f, -70f, 11f}, {-24f, -106f, 24f, -106f, 9f}};
        int idx = 0;
        line.setColor(0xFF2D5A34);
        line.setStrokeWidth(1.1f);
        for (float[] a : arcs) {
            path.rewind();
            path.moveTo(a[0], a[1]);
            path.quadTo(0f, a[1] + a[4] * 2f, a[2], a[3]);
            c.drawPath(path, line);
            for (int j = 0; j < 5; j++, idx++) {
                float u = (j + 0.5f) / 5f;
                float x = a[0] + (a[2] - a[0]) * u, y = a[1] + 4f * a[4] * u * (1f - u);
                float it = lit ? Lights.intensity(idx, time) : 0.25f;
                int col = Lights.COLORS[idx % Lights.COLORS.length];
                glow.draw(c, x, y + 2f, 9f, col, 0.8f * it);
                fill.setColor(col);
                fill.setAlpha((int) (255 * (0.4f + 0.6f * it)));
                c.drawCircle(x, y + 1.5f, 2.3f, fill);
                fill.setAlpha(255);
            }
        }
    }

    // ---------------------------------------------------------------- звезда

    /** Звезда с центром (x, y); glowing — светится и мерцает, иначе обычная золотая. */
    void star(Canvas c, float x, float y, float k, boolean glowing, float time) {
        float R = 9.5f * k;
        if (glowing) {
            float pulse = 0.8f + 0.2f * (float) Math.sin(time * 3f);
            glow.draw(c, x, y, 30f * k, 0xFFFFE066, 0.5f * pulse);
            glow.draw(c, x, y, 15f * k, 0xFFFFF4B0, 0.8f * pulse);
        }
        starPath(path, x, y, R, R * 0.45f);
        fill.setColor(glowing ? 0xFFFFF176 : 0xFFE0A91E);
        c.drawPath(path, fill);
        line.setColor(glowing ? 0xFFFFFFFF : 0xFFB07A10);
        line.setStrokeWidth(1f * k);
        c.drawPath(path, line);
        if (glowing) {
            line.setColor(0xCCFFFFFF);
            line.setStrokeWidth(1.2f * k);
            float r = R * (1.8f + 0.3f * (float) Math.sin(time * 5f));
            c.drawLine(x - r, y, x + r, y, line);
            c.drawLine(x, y - r, x, y + r, line);
        }
    }

    private static void starPath(Path p, float cx, float cy, float outer, float inner) {
        p.rewind();
        for (int i = 0; i < 10; i++) {
            double a = Math.toRadians(-90 + 36 * i);
            float r = (i & 1) == 0 ? outer : inner;
            float px = cx + (float) Math.cos(a) * r, py = cy + (float) Math.sin(a) * r;
            if (i == 0) p.moveTo(px, py);
            else p.lineTo(px, py);
        }
        p.close();
    }

    // ---------------------------------------------------------------- украшения

    private void rect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        fill.setColor(color);
        rf.set(l, t, r, b);
        c.drawRoundRect(rf, rad, rad, fill);
    }

    private void ball(Canvas c, float x, float y, float r, int color) {
        rect(c, x - r * 0.3f, y - r - 2.6f, x + r * 0.3f, y - r + 0.6f, 0.6f, 0xFFF9A825);
        fill.setColor(color);
        c.drawCircle(x, y, r, fill);
        fill.setColor(0x66FFFFFF);
        c.drawCircle(x - r * 0.35f, y - r * 0.35f, r * 0.32f, fill);
    }

    /** Украшение вида type с центром (x, y) в координатах модели; k — множитель размера. */
    void ornament(Canvas c, int type, float x, float y, float k, float time, boolean lit) {
        c.save();
        c.translate(x, y);
        c.scale(k, k);
        switch (type) {
            case Tree.BALL_RED: ball(c, 0f, 0f, 5.5f, 0xFFE53935); break;
            case Tree.BALL_BLUE: ball(c, 0f, 0f, 5.5f, 0xFF1E88E5); break;
            case Tree.BALL_GOLD: ball(c, 0f, 0f, 5.5f, 0xFFFFC107); break;
            case Tree.BALL_PURPLE: ball(c, 0f, 0f, 5.5f, 0xFFAB47BC); break;
            case Tree.CANDY:
                line.setStrokeWidth(3.2f);
                line.setColor(0xFFFFFFFF);
                path.rewind();
                path.moveTo(0f, 8f);
                path.lineTo(0f, -3f);
                path.quadTo(0f, -8f, -4f, -8f);
                path.quadTo(-7f, -8f, -7f, -4.5f);
                c.drawPath(path, line);
                line.setStrokeWidth(1.6f);
                line.setColor(0xFFE53935);
                c.drawLine(-1.8f, 6f, 1.8f, 4.2f, line);
                c.drawLine(-1.8f, 1.5f, 1.8f, -0.3f, line);
                c.drawLine(-4.5f, -9.4f, -3.2f, -6.4f, line);
                break;
            case Tree.BELL:
                path.rewind();
                path.moveTo(-5f, 4f);
                path.quadTo(-5f, -6f, 0f, -6f);
                path.quadTo(5f, -6f, 5f, 4f);
                path.close();
                fill.setColor(0xFFFFB300);
                c.drawPath(path, fill);
                rect(c, -6f, 3f, 6f, 5.2f, 1f, 0xFFFFA000);
                fill.setColor(0xFF8D5A00);
                c.drawCircle(0f, 6.4f, 1.6f, fill);
                break;
            case Tree.FLAKE:
                line.setColor(0xFFFFFFFF);
                line.setStrokeWidth(1.3f);
                for (int i = 0; i < 3; i++) {
                    double a = Math.toRadians(i * 60);
                    float dx = (float) Math.cos(a) * 6f, dy = (float) Math.sin(a) * 6f;
                    c.drawLine(-dx, -dy, dx, dy, line);
                }
                break;
            case Tree.HEART:
                path.rewind();
                path.moveTo(0f, 5.5f);
                path.cubicTo(-9f, -1f, -4.5f, -7f, 0f, -2.2f);
                path.cubicTo(4.5f, -7f, 9f, -1f, 0f, 5.5f);
                path.close();
                fill.setColor(0xFFE53956);
                c.drawPath(path, fill);
                break;
            case Tree.STAR_SMALL:
                starPath(path, 0f, 0f, 6f, 2.8f);
                fill.setColor(0xFFFFC107);
                c.drawPath(path, fill);
                break;
            case Tree.ICICLE:
                path.rewind();
                path.moveTo(-2.5f, -6f);
                path.lineTo(2.5f, -6f);
                path.lineTo(0f, 8f);
                path.close();
                fill.setColor(0xCCBFE6FF);
                c.drawPath(path, fill);
                fill.setColor(0x99FFFFFF);
                c.drawRect(-1.2f, -5f, -0.4f, 2f, fill);
                break;
            case Tree.GIFT:
                rect(c, -5f, -4f, 5f, 5f, 0.8f, 0xFFD32F2F);
                rect(c, -5f, -4f, 5f, -2f, 0.4f, 0xFFB71C1C);
                rect(c, -0.9f, -4f, 0.9f, 5f, 0f, 0xFFFFD54F);
                rect(c, -5f, 0.2f, 5f, 1.8f, 0f, 0xFFFFD54F);
                line.setColor(0xFFFFD54F);
                line.setStrokeWidth(1.2f);
                c.drawLine(0f, -4f, -2.5f, -6.5f, line);
                c.drawLine(0f, -4f, 2.5f, -6.5f, line);
                break;
            case Tree.BULB: {
                float it = lit ? 0.7f + 0.3f * (float) Math.sin(time * 4f + x) : 0.2f;
                glow.draw(c, 0f, 1f, 10f, 0xFFFFD27A, 0.8f * it);
                rect(c, -2f, -6f, 2f, -3f, 0.5f, 0xFF8A9099);
                fill.setColor(lit ? 0xFFFFF3C4 : 0xFFCFC8A8);
                c.drawCircle(0f, 0.5f, 4f, fill);
                break;
            }
            default:
                break;
        }
        c.restore();
    }

    /** Предмет из ящика (украшение, звезда, гирлянда) в иконку для лотка. */
    void icon(Canvas c, int item, float cx, float cy, float s, float time) {
        c.save();
        c.translate(cx, cy);
        c.scale(s, s);
        if (item < Tree.ORN_COUNT) {
            ornament(c, item, 0f, 0f, 2.3f, time, true);
        } else if (item == Tree.ITEM_STAR_PLAIN) {
            star(c, 0f, 0f, 1.7f, false, time);
        } else if (item == Tree.ITEM_STAR_GLOW) {
            star(c, 0f, 0f, 1.7f, true, time);
        } else {
            line.setColor(0xFF2D5A34);
            line.setStrokeWidth(1.4f);
            path.rewind();
            path.moveTo(-17f, -6f);
            path.quadTo(0f, 14f, 17f, -6f);
            c.drawPath(path, line);
            for (int j = 0; j < 4; j++) {
                float u = (j + 0.5f) / 4f;
                float x = -17f + 34f * u, y = -6f + 4f * 10f * u * (1f - u);
                int col = Lights.COLORS[j % Lights.COLORS.length];
                glow.draw(c, x, y + 3f, 9f, col, 0.7f);
                fill.setColor(col);
                c.drawCircle(x, y + 2.5f, 3f, fill);
            }
        }
        c.restore();
    }
}
