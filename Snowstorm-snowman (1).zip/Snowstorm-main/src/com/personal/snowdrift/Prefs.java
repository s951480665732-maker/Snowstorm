package com.personal.snowdrift;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки и перевод значений ползунков (0..100) в физику. */
final class Prefs {
    static final String ENABLED = "enabled";
    static final String SPEED = "speed";
    static final String INTENSITY = "intensity";
    static final String STORM = "storm";
    static final String ECO = "eco";
    static final String TILT = "tilt";
    static final String DRIFT = "drift_max";
    static final String SHAKE = "shake_clear";
    static final String TAKE_SNOW = "take_snow";
    static final String SHOW_SNOWMAN = "show_snowman";
    static final String CAT = "pet_cat", DOG = "pet_dog", CAT_SKIN = "cat_skin", DOG_SKIN = "dog_skin";
    static final String TREE = "tree_on", GARLAND = "garland_on", LAMP = "lamp_on", PLOW = "plow_on";
    /** Растут каждый раз, когда мастерская сохраняет снеговиков / ёлку / LEGO: слой со снегом перечитывает их. */
    static final String SNOWMAN_REV = "snowman_rev", TREE_REV = "tree_rev", LEGO_REV = "lego_rev";
    /** Счётчики-«кнопки»: приложение увеличивает, служба замечает и делает действие. */
    static final String TREE_RAISE = "tree_raise_req", PLOW_CALL = "plow_call_req", NY_TEST = "ny_test_req";
    static final String NY_ACK_YEAR = "ny_ack_year";
    /** Скрытый режим разработчика: подмена сезона и падающего (−1 — по дате). */
    static final String DEBUG_SEASON = "debug_season", DEBUG_PARTICLE = "debug_particle";

    static final int DEF_SPEED = 50;
    static final int DEF_INTENSITY = 35;
    /** Ползунок высоты сугроба: 100 — без ограничения. */
    static final int DEF_DRIFT = 100;

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("snow", Context.MODE_PRIVATE);
    }

    static boolean enabled(SharedPreferences p) { return p.getBoolean(ENABLED, true); }
    static boolean storm(SharedPreferences p) { return p.getBoolean(STORM, false); }
    static boolean eco(SharedPreferences p) { return p.getBoolean(ECO, false); }
    static boolean tilt(SharedPreferences p) { return p.getBoolean(TILT, true); }
    static boolean showSnowman(SharedPreferences p) { return p.getBoolean(SHOW_SNOWMAN, true); }
    static int snowmanRev(SharedPreferences p) { return p.getInt(SNOWMAN_REV, 0); }
    static boolean shake(SharedPreferences p) { return p.getBoolean(SHAKE, false); }
    static boolean takeSnow(SharedPreferences p) { return p.getBoolean(TAKE_SNOW, false); }
    static boolean cat(SharedPreferences p) { return p.getBoolean(CAT, true); }
    static boolean dog(SharedPreferences p) { return p.getBoolean(DOG, true); }
    static int catSkin(SharedPreferences p) { return p.getInt(CAT_SKIN, 0); }
    static int dogSkin(SharedPreferences p) { return p.getInt(DOG_SKIN, 0); }
    static boolean tree(SharedPreferences p) { return p.getBoolean(TREE, true); }
    static boolean garland(SharedPreferences p) { return p.getBoolean(GARLAND, true); }
    static boolean lamp(SharedPreferences p) { return p.getBoolean(LAMP, false); }
    static boolean plow(SharedPreferences p) { return p.getBoolean(PLOW, true); }
    static int treeRev(SharedPreferences p) { return p.getInt(TREE_REV, 0); }
    static int legoRev(SharedPreferences p) { return p.getInt(LEGO_REV, 0); }
    static int drift(SharedPreferences p) { return p.getInt(DRIFT, DEF_DRIFT); }
    static int debugSeason(SharedPreferences p) { return p.getInt(DEBUG_SEASON, -1); }
    static int debugParticle(SharedPreferences p) { return p.getInt(DEBUG_PARTICLE, -1); }
    static int speed(SharedPreferences p) { return p.getInt(SPEED, DEF_SPEED); }
    static int intensity(SharedPreferences p) { return p.getInt(INTENSITY, DEF_INTENSITY); }

    /** 0..100 -> множитель скорости 0.3..3 (50 ≈ 0.95). */
    static float speedFactor(int v) { return (float) (0.3 * Math.pow(10, v / 100.0)); }

    /** 0..100 -> максимальная высота сугроба 20..140 dp; 100 — без ограничения. */
    static float driftMaxDp(int v) { return v >= 100 ? Float.POSITIVE_INFINITY : 20 + v * 1.2f; }

    /** 0..100 -> число снежинок 10..350. */
    static int flakeCount(int v) { return 10 + Math.round(v * 3.4f); }
}
