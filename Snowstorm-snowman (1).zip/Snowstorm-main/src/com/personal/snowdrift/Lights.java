package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Светящиеся украшения поверх экрана: гирлянда по верхнему краю и подвесная лампочка (видны лучше на тёмном фоне). */
final class Lights {
    static final int[] COLORS = {0xFFFF3B3B, 0xFFFFC93C, 0xFF3BE06B, 0xFF3BA8FF, 0xFFFF5CD6};
    private static final int SWAGS = 6, PER_SWAG = 4;

    private final Glow glow = new Glow();
    private final Paint wire = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    Lights() {
        wire.setStyle(Paint.Style.STROKE);
        wire.setColor(0xFF2D5A34);
        wire.setStrokeCap(Paint.Cap.ROUND);
    }

    /** Яркость лампочки idx в момент t (0..1): режимы меняются каждые ~9 секунд. */
    static float intensity(int idx, float t) {
        switch ((int) (t / 9f) % 4) {
            case 1: return (((idx + (int) (t * 2f)) & 1) == 0) ? 1f : 0.18f;
            case 2: return 0.2f + 0.8f * Math.max(0f, (float) Math.sin(t * 3f - idx * 0.6f));
            case 3: return 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(t * (2f + idx % 3) + idx * 1.7f));
            default: return 1f;
        }
    }

    void draw(Canvas c, int w, int h, float d, float t, boolean garland, boolean lamp) {
        if (garland) drawGarland(c, w, d, t);
        if (lamp) drawLamp(c, w, d, t);
    }

    private void drawGarland(Canvas c, int w, float d, float t) {
        float y0 = 3f * d, sag = 24f * d, sw = w / (float) SWAGS;
        wire.setStrokeWidth(1.3f * d);
        path.rewind();
        for (int k = 0; k < SWAGS; k++) {
            float x0 = k * sw, x1 = x0 + sw;
            path.moveTo(x0, y0);
            path.quadTo((x0 + x1) / 2f, y0 + sag * 2f, x1, y0);
        }
        c.drawPath(path, wire);
        int idx = 0;
        for (int k = 0; k < SWAGS; k++) {
            float x0 = k * sw;
            for (int j = 0; j < PER_SWAG; j++, idx++) {
                float u = (j + 0.5f) / PER_SWAG;
                // точка на квадратичной кривой (контрольная точка на 2*sag ниже концов)
                float x = x0 + sw * u, y = y0 + 4f * sag * u * (1f - u); // точка квадратичной кривой
                float it = intensity(idx, t);
                int col = COLORS[idx % COLORS.length];
                glow.draw(c, x, y + 6f * d, 15f * d, col, 0.85f * it);
                fill.setColor(0xFF4A4F55);
                rf.set(x - 1.6f * d, y - 0.5f * d, x + 1.6f * d, y + 2.5f * d);
                c.drawRect(rf.left, rf.top, rf.right, rf.bottom, fill);
                fill.setColor(col);
                fill.setAlpha((int) (255 * (0.35f + 0.65f * it)));
                rf.set(x - 2.6f * d, y + 2f * d, x + 2.6f * d, y + 9f * d);
                c.drawOval(rf, fill);
                fill.setAlpha(255);
            }
        }
    }

    private void drawLamp(Canvas c, int w, float d, float t) {
        float x = w * 0.82f, flick = 0.93f + 0.07f * (float) Math.sin(t * 13f) * (float) Math.sin(t * 2.3f);
        wire.setStrokeWidth(1.6f * d);
        wire.setColor(0xFF555A60);
        c.drawLine(x, 0f, x, 40f * d, wire);
        wire.setColor(0xFF2D5A34);
        fill.setColor(0xFF8A9099);
        rf.set(x - 5f * d, 38f * d, x + 5f * d, 47f * d);
        c.drawRoundRect(rf, 2f * d, 2f * d, fill);
        glow.draw(c, x, 58f * d, 120f * d, 0xFFFFC857, 0.16f * flick);
        glow.draw(c, x, 58f * d, 54f * d, 0xFFFFD27A, 0.55f * flick);
        fill.setColor(0xFFFFF3C4);
        c.drawCircle(x, 57f * d, 9.5f * d, fill);
        fill.setColor(0xFFFFFFFF);
        c.drawCircle(x - 2.5f * d, 54f * d, 3.2f * d, fill);
    }
}
