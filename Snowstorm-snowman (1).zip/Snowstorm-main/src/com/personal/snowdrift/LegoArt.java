package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

/** Рисование кубиков и постройки. */
final class LegoArt {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();

    /** Один кубик шириной w шипов: левый верхний угол (x, y), s — пикселей на единицу модели. */
    void brick(Canvas c, float x, float y, int w, int color, float s) {
        float bw = w * Lego.UNIT * s, bh = Lego.BRICK_H * s;
        fill.setColor(0x33000000);
        rf.set(x + 1f * s, y + 1f * s, x + bw + 1f * s, y + bh + 1f * s);
        c.drawRoundRect(rf, 1.5f * s, 1.5f * s, fill);
        fill.setColor(color);
        rf.set(x, y, x + bw, y + bh);
        c.drawRoundRect(rf, 1.5f * s, 1.5f * s, fill);
        fill.setColor(0x33FFFFFF);
        rf.set(x, y, x + bw, y + bh * 0.28f);
        c.drawRoundRect(rf, 1.5f * s, 1.5f * s, fill);
        for (int i = 0; i < w; i++) {
            float sx = x + (i + 0.5f) * Lego.UNIT * s;
            fill.setColor(color);
            rf.set(sx - 3.3f * s, y - 2.4f * s, sx + 3.3f * s, y + 0.6f * s);
            c.drawRoundRect(rf, 1f * s, 1f * s, fill);
            fill.setColor(0x44FFFFFF);
            rf.set(sx - 2.3f * s, y - 2.1f * s, sx + 0.3f * s, y - 0.9f * s);
            c.drawRoundRect(rf, 0.6f * s, 0.6f * s, fill);
        }
    }

    /** Пластина и постройка: (left, ground) — левый нижний угол пластины. */
    void draw(Canvas c, Lego l, float left, float ground, float s) {
        float pw = Lego.COLS * Lego.UNIT * s, ph = Lego.PLATE_H * s;
        fill.setColor(0x33000000);
        rf.set(left, ground - ph * 0.1f, left + pw + 2f * s, ground + 2f * s);
        c.drawRoundRect(rf, 2f * s, 2f * s, fill);
        fill.setColor(0xFF2E9E4F);
        rf.set(left, ground - ph, left + pw, ground);
        c.drawRoundRect(rf, 1.5f * s, 1.5f * s, fill);
        fill.setColor(0xFF45B968);
        for (int i = 0; i < Lego.COLS; i++) {
            float sx = left + (i + 0.5f) * Lego.UNIT * s;
            rf.set(sx - 3.3f * s, ground - ph - 1.6f * s, sx + 3.3f * s, ground - ph + 0.4f * s);
            c.drawRoundRect(rf, 1f * s, 1f * s, fill);
        }
        float top = ground - ph;
        for (Lego.Brick b : l.bricks) {
            brick(c, left + b.col * Lego.UNIT * s, top - (b.row + 1) * Lego.BRICK_H * s, b.w, b.color, s);
        }
    }
}
