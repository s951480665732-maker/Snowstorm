package com.personal.snowdrift;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Постройка из кубиков LEGO (вид сбоку) для праздника 19 ноября: кубики падают «по гравитации»
 * на пластину или на другие кубики. Единицы модели — dp: ширина одного шипа UNIT, высота кубика BRICK_H.
 */
final class Lego {
    static final int COLS = 12;
    static final float UNIT = 12f, BRICK_H = 9f, PLATE_H = 4f;
    static final int[] COLORS = {0xFFD01012, 0xFF0D69AB, 0xFFF5CD2F, 0xFF237841, 0xFFFE8A18, 0xFFF2F3F2, 0xFF1B2A34};
    /** Лоток: ширина кубика в шипах; цвет подбирается по номеру. */
    static final int[] TRAY_WIDTHS = {1, 2, 2, 3, 4, 4, 6, 8, 2, 3, 4, 2, 6, 1};
    static final int TRAY_COUNT = TRAY_WIDTHS.length;

    private static final String FILE = "lego.bin";
    private static final int VERSION = 1;

    static final class Brick {
        int col, row, w, color;

        Brick(int col, int row, int w, int color) {
            this.col = col;
            this.row = row;
            this.w = w;
            this.color = color;
        }
    }

    final ArrayList<Brick> bricks = new ArrayList<>();

    static int trayColor(int item) {
        return COLORS[item % COLORS.length];
    }

    boolean isEmpty() {
        return bricks.isEmpty();
    }

    /** Нижний свободный ряд для кубика шириной w в колонке col (не учитывая except). */
    int rowFor(int col, int w, Brick except) {
        int row = 0;
        for (Brick b : bricks) {
            if (b == except) continue;
            if (b.col < col + w && col < b.col + b.w) row = Math.max(row, b.row + 1);
        }
        return row;
    }

    /** Ставит кубик (колонка зажимается в пластину) и возвращает его. */
    Brick place(int col, int w, int color) {
        col = Math.max(0, Math.min(COLS - w, col));
        Brick b = new Brick(col, rowFor(col, w, null), w, color);
        bricks.add(b);
        return b;
    }

    /** После снятия кубика всё, что на нём лежало, опускается. */
    void settle() {
        ArrayList<Brick> order = new ArrayList<>(bricks);
        order.sort((a, b) -> a.row - b.row);
        bricks.clear();
        for (Brick b : order) {
            b.row = rowFor(b.col, b.w, null);
            bricks.add(b);
        }
    }

    Brick brickAt(float x, float y) { // x в единицах от левого края пластины, y вверх от верха пластины
        for (int i = bricks.size() - 1; i >= 0; i--) {
            Brick b = bricks.get(i);
            float bx = b.col * UNIT, by = b.row * BRICK_H;
            if (x >= bx && x <= bx + b.w * UNIT && y >= by && y <= by + BRICK_H) return b;
        }
        return null;
    }

    int height() {
        int h = 0;
        for (Brick b : bricks) h = Math.max(h, b.row + 1);
        return h;
    }

    static Lego load(Context c) {
        Lego l = new Lego();
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return l;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f)))) {
            if (in.readInt() != VERSION) return l;
            int n = in.readInt();
            if (n < 0 || n > 300) return l;
            for (int i = 0; i < n; i++) {
                int col = in.readInt(), row = in.readInt(), w = in.readInt(), color = in.readInt();
                if (w >= 1 && w <= COLS && col >= 0 && col + w <= COLS && row >= 0) l.bricks.add(new Brick(col, row, w, color));
            }
        } catch (Exception e) {
            return new Lego();
        }
        return l;
    }

    static void save(Context c, Lego l) {
        File f = new File(c.getFilesDir(), FILE);
        if (l.isEmpty()) {
            f.delete();
            return;
        }
        File tmp = new File(f.getPath() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
            out.writeInt(VERSION);
            out.writeInt(l.bricks.size());
            for (Brick b : l.bricks) {
                out.writeInt(b.col);
                out.writeInt(b.row);
                out.writeInt(b.w);
                out.writeInt(b.color);
            }
        } catch (Exception e) {
            return;
        }
        tmp.renameTo(f);
    }
}
