package com.personal.snowdrift;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.graphics.RectF;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.Looper;
import android.os.PowerManager;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/**
 * Служба спец. возможностей. Держит слой со снегом поверх всех окон, следит, какое
 * приложение сверху (у каждого свой сугроб), ловит встряхивание и держит уведомление.
 */
public class SnowService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener, SensorEventListener {

    static final String CHANNEL = "snow";
    static final int NOTIF_ID = 1;
    static SnowService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable resolveRunnable = this::resolveForeground;
    private final Runnable saveTick = new Runnable() {
        @Override
        public void run() {
            saveIfChanged();
            refreshSeason();
            checkNewYear(false);
            handler.postDelayed(this, 20_000);
        }
    };

    private SharedPreferences prefs;
    private DriftStore store;
    private WindowManager wm;
    private SnowView view;
    private SensorManager sensors;
    private Sensor accel;
    private boolean sensorOn, screenOn = true;
    private final HashSet<String> launchers = new HashSet<>();

    private String fgPkg;       // верхнее окно приложения (может быть лаунчер)
    private String currentPkg;  // приложение, чей сугроб сейчас растёт
    private String lastEventPkg;

    // наклон: сглаженные показания акселерометра
    private float gax, gay;
    private boolean haveGravity;
    private final float[] gScreen = new float[2];
    private int sensorRate = -1;

    // встряхивание (если включено в настройках)
    private int shakeHits;
    private long firstHit, lastHit, lastShake;

    // сезон и то, что сейчас лежит на слое (версии файлов из мастерской)
    private Season season;
    private int snowmanRev = -1, treeRev = -1, legoRev = -1;
    private Tree tree;
    private Lego lego;
    private int lastTreeRaise, lastPlowCall, lastNyTest;

    // окошки с касаниями: кнопка на упавшей ёлке и новогоднее поздравление
    private android.view.View treeBtn, nyView;
    private boolean treeBtnShown;
    private Vibrator vibrator;

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                screenOn = false;
                saveIfChanged();
            } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                screenOn = true;
            }
            applyRunState();
            scheduleResolve(300);
        }
    };

    // ---------------------------------------------------------------- жизненный цикл

    @Override
    protected void onServiceConnected() {
        instance = this;
        prefs = Prefs.get(this);
        store = new DriftStore(this);
        store.load();
        wm = getSystemService(WindowManager.class);
        sensors = getSystemService(SensorManager.class);
        accel = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        PowerManager pm = getSystemService(PowerManager.class);
        screenOn = pm == null || pm.isInteractive();
        findLaunchers();

        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
        try {
            // Foreground-статус нужен, чтобы акселерометр работал, пока мы «в фоне».
            startForeground(NOTIF_ID, buildNotification());
        } catch (Exception e) {
            nm.notify(NOTIF_ID, buildNotification());
        }

        view = new SnowView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            lp.setFitInsetsTypes(0);
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        lp.setTitle("Snow");
        wm.addView(view, lp);

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, f);

        lastTreeRaise = prefs.getInt(Prefs.TREE_RAISE, 0);
        lastPlowCall = prefs.getInt(Prefs.PLOW_CALL, 0);
        lastNyTest = prefs.getInt(Prefs.NY_TEST, 0);
        view.setTreeTouchListener(this::onTreeTouch);
        prefs.registerOnSharedPreferenceChangeListener(this);
        applyPrefs();
        handler.postDelayed(saveTick, 20_000);
        scheduleResolve(0);
        checkNewYear(false);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }

    private void shutdown() {
        if (instance != this) return;
        instance = null;
        handler.removeCallbacksAndMessages(null);
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        setSensor(false);
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
        dismissNewYear(false);
        hideTreeButton();
        if (view != null) {
            view.setRunning(false);
            try { wm.removeView(view); } catch (Exception ignored) {}
            view = null;
        }
        store.saveAsync();
        stopForeground(STOP_FOREGROUND_REMOVE);
        getSystemService(NotificationManager.class).cancel(NOTIF_ID);
    }

    /**
     * Полный выход: убираем снег и уведомление, отключаем службу в настройках спец. возможностей
     * (иначе система сразу поднимет её снова) и завершаем процесс.
     */
    void exitApp() {
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE);
        DriftStore s = store;
        shutdown();
        s.flush();
        // В следующий раз, когда службу включат, снег пойдёт сразу.
        prefs.edit().putBoolean(Prefs.ENABLED, true).commit();
        disableSelf();
        killApp(this);
    }

    /** Закрыть окна приложения (и карточку в «Недавних»), убрать уведомление, завершить процесс. */
    static void killApp(Context c) {
        android.app.ActivityManager am = c.getSystemService(android.app.ActivityManager.class);
        if (am != null) for (android.app.ActivityManager.AppTask t : am.getAppTasks()) t.finishAndRemoveTask();
        c.getSystemService(NotificationManager.class).cancelAll();
        new Handler(Looper.getMainLooper()).postDelayed(
                () -> android.os.Process.killProcess(android.os.Process.myPid()), 300);
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        // Сменили язык приложения/системы — переписываем уведомление и имя канала.
        if (instance != this) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW));
        postNotification();
    }

    // ---------------------------------------------------------------- настройки

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        applyPrefs();
    }

    private void applyPrefs() {
        if (view == null) return;
        view.setEco(Prefs.eco(prefs));
        view.setTilt(Prefs.tilt(prefs));
        view.setShowSnowman(Prefs.showSnowman(prefs));
        refreshSeason();
        view.setPets(Prefs.cat(prefs), Prefs.catSkin(prefs), Prefs.dog(prefs), Prefs.dogSkin(prefs));
        view.setLights(Prefs.garland(prefs), Prefs.lamp(prefs));
        view.setPlow(Prefs.plow(prefs));

        // мастерская сохранила снеговиков / ёлку / LEGO (или это первый запуск) — перечитываем
        int rev = Prefs.snowmanRev(prefs);
        if (rev != snowmanRev) {
            snowmanRev = rev;
            view.setSnowmen(Snowman.loadAll(this));
        }
        int tr = Prefs.treeRev(prefs);
        if (tr != treeRev || tree == null) {
            treeRev = tr;
            tree = Tree.load(this);
        }
        view.setTree(tree, Prefs.tree(prefs));
        int lr = Prefs.legoRev(prefs);
        if (lr != legoRev || lego == null) {
            legoRev = lr;
            lego = Lego.load(this);
        }
        view.setLego(lego, season.particle == Season.P_LEGO);

        view.setParams(Prefs.speedFactor(Prefs.speed(prefs)), Prefs.flakeCount(Prefs.intensity(prefs)),
                Prefs.storm(prefs), Prefs.driftMaxDp(Prefs.drift(prefs)));

        // кнопки-счётчики из приложения
        int raise = prefs.getInt(Prefs.TREE_RAISE, 0);
        if (raise != lastTreeRaise) {
            lastTreeRaise = raise;
            view.raiseTree();
        }
        int plow = prefs.getInt(Prefs.PLOW_CALL, 0);
        if (plow != lastPlowCall) {
            lastPlowCall = plow;
            view.callPlow();
        }
        int ny = prefs.getInt(Prefs.NY_TEST, 0);
        if (ny != lastNyTest) {
            lastNyTest = ny;
            checkNewYear(true);
        }
        applyRunState();
        postNotification();
    }

    /** Сезон и праздник по дате (или скрытая подмена); меняется на лету, например в полночь 1 декабря. */
    private void refreshSeason() {
        Season now = Season.now(Prefs.debugSeason(prefs), Prefs.debugParticle(prefs));
        boolean changed = season == null || now.season != season.season || now.particle != season.particle;
        season = now;
        if (changed && view != null) {
            view.setSeason(now);
            applyActiveDrift();
        }
    }

    /** У каждого сезона одна общая кучка (снег, листья, лепестки) на все приложения. */
    private void applyActiveDrift() {
        String key = season.driftKey();
        view.setActive(fgPkg == null ? null : store.get(key), key);
    }

    private void applyRunState() {
        if (view == null) return;
        boolean on = Prefs.enabled(prefs);
        view.setVisibility(on ? android.view.View.VISIBLE : android.view.View.GONE);
        view.setRunning(on && screenOn);
        setSensor(on && screenOn);
    }

    void clearAllDrifts() {
        if (view != null) view.crumbleActive();
        store.clearAll();
    }

    /** Мастерская берёт снег из сугроба для снеговика; без запущенной службы ограничений нет. */
    static float takeSnow(float cols) {
        SnowService s = instance;
        return s == null ? cols : s.takeSnowImpl(cols);
    }

    private float takeSnowImpl(float cols) {
        if (store == null || season == null) return cols;
        float got = store.take(season.driftKey(), cols);
        if (got > 0f && view != null) view.markChanged();
        return got;
    }

    // ---------------------------------------------------------------- уведомление

    void postNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    private Notification buildNotification() {
        boolean on = Prefs.enabled(prefs);
        int imm = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent toggle = PendingIntent.getBroadcast(this, 1,
                new Intent(this, ToggleReceiver.class).setAction(ToggleReceiver.ACTION_TOGGLE), imm);
        PendingIntent repost = PendingIntent.getBroadcast(this, 2,
                new Intent(this, ToggleReceiver.class).setAction(ToggleReceiver.ACTION_REPOST), imm);
        PendingIntent exit = PendingIntent.getBroadcast(this, 4,
                new Intent(this, ToggleReceiver.class).setAction(ToggleReceiver.ACTION_EXIT), imm);
        PendingIntent open = PendingIntent.getActivity(this, 3,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), imm);
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat_snow);

        int text;
        if (!on) text = R.string.notif_text_off;
        else if (Prefs.storm(prefs)) text = R.string.notif_text_storm;
        else text = R.string.notif_text_on;

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_snow)
                .setContentTitle(getString(on ? R.string.notif_title_on : R.string.notif_title_off))
                .setContentText(getString(text))
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(open)
                .setDeleteIntent(repost)
                .addAction(new Notification.Action.Builder(icon, getString(on ? R.string.notif_stop : R.string.notif_start), toggle).build())
                .addAction(new Notification.Action.Builder(icon, getString(R.string.notif_settings), open).build())
                .addAction(new Notification.Action.Builder(icon, getString(R.string.notif_exit), exit).build());
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    // ---------------------------------------------------------------- какое приложение сверху

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        int type = e.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName() != null
                && e.getClassName() != null && isActivity(e.getPackageName().toString(), e.getClassName().toString())) {
            lastEventPkg = e.getPackageName().toString();
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName() != null
                && launchers.contains(e.getPackageName().toString())) {
            // Лаунчер становится видимым в самом начале свайпа вверх, а список окон
            // обновится только после отпускания пальца — реагируем сразу.
            handler.removeCallbacks(resolveRunnable);
            setForeground(e.getPackageName().toString());
            return;
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            scheduleResolve(120);
        }
    }

    private boolean isActivity(String pkg, String cls) {
        try {
            getPackageManager().getActivityInfo(new android.content.ComponentName(pkg, cls), 0);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    private void scheduleResolve(long delay) {
        handler.removeCallbacks(resolveRunnable);
        handler.postDelayed(resolveRunnable, delay);
    }

    /** Верхнее (по слою) обычное окно приложения, не картинка-в-картинке. */
    private void resolveForeground() {
        if (view == null || !screenOn) return;
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km != null && km.isKeyguardLocked()) {
            setForeground(null);
            return;
        }
        String pkg = null;
        boolean shade = false;
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            AccessibilityWindowInfo best = null;
            android.graphics.Rect r = new android.graphics.Rect();
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_SYSTEM) {
                    // Открытая шторка уведомлений — системное окно почти во весь экран.
                    w.getBoundsInScreen(r);
                    if (r.height() > view.getHeight() * 0.6f && isShadeWindow(w.getTitle())) shade = true;
                }
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION || w.isInPictureInPictureMode()) continue;
                if (best == null || w.getLayer() > best.getLayer()) best = w;
            }
            if (best != null) {
                AccessibilityNodeInfo root = best.getRoot();
                if (root != null && root.getPackageName() != null) pkg = root.getPackageName().toString();
            }
        } catch (Exception ignored) {}
        view.setSuppressed(shade);
        if (pkg == null) pkg = lastEventPkg;
        if (pkg != null) setForeground(pkg);
    }

    /** Окно шторки уведомлений, а не панель навигации или оверлей скруглённых углов (они тоже большие). */
    private static boolean isShadeWindow(CharSequence title) {
        if (title == null) return true; // название неизвестно — считаем шторкой, как раньше
        String t = title.toString().toLowerCase(java.util.Locale.ROOT);
        return t.contains("notification") || t.contains("shade") || t.contains("statusbar")
                || t.contains("status bar") || t.contains("quick") || t.contains("панел") || t.contains("шторк");
    }

    private void setForeground(String pkg) {
        // Сугроб один на весь экран и не зависит от приложения: смена приложения его не трогает,
        // убрать его можно только кнопкой в приложении (или тряской, если включено).
        if (Objects.equals(pkg, fgPkg)) return;
        fgPkg = pkg;
        currentPkg = pkg;
        applyActiveDrift();
        saveIfChanged();
    }

    private void findLaunchers() {
        launchers.clear();
        PackageManager pm = getPackageManager();
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo def = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        if (def != null && def.activityInfo != null && !"android".equals(def.activityInfo.packageName)) {
            launchers.add(def.activityInfo.packageName);
            return;
        }
        for (ResolveInfo ri : pm.queryIntentActivities(home, 0)) {
            String p = ri.activityInfo.packageName;
            if (!"com.android.settings".equals(p)) launchers.add(p);
        }
    }

    private void saveIfChanged() {
        if (view == null) return;
        if (view.consumeChanged()) store.saveAsync();
        Tree t = view.takeTreeIfChanged(); // кот уронил ёлку или её подняли — запоминаем
        if (t != null) Tree.save(this, t);
    }

    // ---------------------------------------------------------------- наклон телефона

    private void setSensor(boolean on) {
        if (accel == null) return;
        // Для тряски нужны частые показания; для одного наклона хватает редких.
        int rate = on ? (Prefs.shake(prefs) ? SensorManager.SENSOR_DELAY_GAME : SensorManager.SENSOR_DELAY_UI) : -1;
        if (rate == sensorRate) return;
        if (sensorOn) sensors.unregisterListener(this);
        sensorRate = rate;
        sensorOn = rate >= 0;
        if (sensorOn) {
            haveGravity = false;
            sensors.registerListener(this, accel, rate);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        // Фильтр низких частот оставляет только «куда тянет вниз», тряска сглаживается.
        float k = sensorRate == SensorManager.SENSOR_DELAY_GAME ? 0.12f : 0.2f;
        if (!haveGravity) {
            gax = x;
            gay = y;
            haveGravity = true;
        } else {
            gax += (x - gax) * k;
            gay += (y - gay) * k;
        }
        if (view != null) {
            android.view.Display disp = view.getDisplay();
            Tilt.toScreen(gax, gay, disp == null ? 0 : disp.getRotation(), gScreen);
            view.setGravity(gScreen[0], gScreen[1]);
        }
        if (!Prefs.shake(prefs)) return;
        double a = Math.abs(Math.sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH);
        if (a < 11) return;
        long now = android.os.SystemClock.uptimeMillis();
        if (now - firstHit > 1200) {
            firstHit = now;
            shakeHits = 0;
        }
        if (now - lastHit > 90) {
            shakeHits++;
            lastHit = now;
        }
        if (shakeHits >= 4 && now - lastShake > 1500) {
            lastShake = now;
            shakeHits = 0;
            if (view != null) {
                view.crumbleActive();
                saveIfChanged();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int acc) {}

    // ---------------------------------------------------------------- упавшая ёлка: нажатие поднимает её

    /** Слой со снегом сообщает, где лежит упавшая ёлка (null — стоит): под ней держим прозрачную кнопку. */
    private void onTreeTouch(RectF r) {
        if (r == null || wm == null) {
            hideTreeButton();
            return;
        }
        if (treeBtn == null) {
            treeBtn = new android.view.View(this);
            treeBtn.setOnTouchListener((v, ev) -> {
                if (ev.getActionMasked() == android.view.MotionEvent.ACTION_UP && view != null) view.raiseTree();
                return true;
            });
        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                Math.max(1, (int) r.width()), Math.max(1, (int) r.height()),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
        lp.x = (int) r.left;
        lp.y = (int) r.top;
        lp.setTitle("SnowTree");
        try {
            if (treeBtnShown) wm.updateViewLayout(treeBtn, lp);
            else wm.addView(treeBtn, lp);
            treeBtnShown = true;
        } catch (Exception ignored) {}
    }

    private void hideTreeButton() {
        if (treeBtn != null && treeBtnShown && wm != null) {
            try { wm.removeView(treeBtn); } catch (Exception ignored) {}
        }
        treeBtnShown = false;
    }

    // ---------------------------------------------------------------- Новый год

    /** 1 января (пока не нажали «Спасибо») или проверка из приложения: показать поздравление с вибрацией. */
    private void checkNewYear(boolean force) {
        if (view == null || nyView != null) return;
        Season s = Season.now(Prefs.debugSeason(prefs), Prefs.debugParticle(prefs));
        if (!force && !(s.newYear && prefs.getInt(Prefs.NY_ACK_YEAR, 0) != s.year)) return;
        if (!screenOn && !force) return;
        showNewYear(s.year);
    }

    private void showNewYear(int year) {
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        float dp = getResources().getDisplayMetrics().density;
        int pad = Math.round(24 * dp);
        box.setPadding(pad, pad, pad, pad);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xEE0B1A33);
        bg.setCornerRadius(24 * dp);
        box.setBackground(bg);

        android.widget.TextView title = new android.widget.TextView(this);
        title.setText(getString(R.string.ny_title, year));
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(26);
        title.setGravity(android.view.Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(title);

        android.widget.TextView text = new android.widget.TextView(this);
        text.setText(R.string.ny_text);
        text.setTextColor(0xCCFFFFFF);
        text.setTextSize(16);
        text.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams tlp = new android.widget.LinearLayout.LayoutParams(-2, -2);
        tlp.topMargin = Math.round(10 * dp);
        box.addView(text, tlp);

        android.widget.Button thanks = new android.widget.Button(this);
        thanks.setText(R.string.ny_thanks);
        thanks.setAllCaps(false);
        thanks.setTextColor(0xFF0B1A2E);
        android.graphics.drawable.GradientDrawable bb = new android.graphics.drawable.GradientDrawable();
        bb.setColor(0xFF7CC4FF);
        bb.setCornerRadius(16 * dp);
        thanks.setBackground(bb);
        thanks.setOnClickListener(v -> dismissNewYear(true));
        android.widget.LinearLayout.LayoutParams blp = new android.widget.LinearLayout.LayoutParams(-2, -2);
        blp.topMargin = Math.round(18 * dp);
        box.addView(thanks, blp);
        box.setTag(year);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = android.view.Gravity.CENTER;
        lp.setTitle("SnowNewYear");
        try {
            wm.addView(box, lp);
            nyView = box;
        } catch (Exception e) {
            return;
        }
        vibrator = getSystemService(Vibrator.class);
        if (vibrator != null && vibrator.hasVibrator()) {
            // повторяется, пока не нажмут «Спасибо»
            vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 500, 250, 500, 250, 900, 2500}, 0),
                    new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build());
        }
    }

    private void dismissNewYear(boolean acknowledged) {
        if (vibrator != null) vibrator.cancel();
        if (nyView != null) {
            Object y = nyView.getTag();
            try { wm.removeView(nyView); } catch (Exception ignored) {}
            nyView = null;
            if (acknowledged && y instanceof Integer) prefs.edit().putInt(Prefs.NY_ACK_YEAR, (Integer) y).apply();
        }
    }
}
