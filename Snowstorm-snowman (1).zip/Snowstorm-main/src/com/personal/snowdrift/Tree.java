package com.personal.snowdrift;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Ёлка: украшения и звезда. Единицы модели — dp, начало координат — низ ствола, y вверх отрицательный.
 * fall — лежит ли ёлка (0 стоит, +1 упала вправо, −1 влево); её роняет кот, поднимают нажатием или из приложения.
 */
final class Tree {
    // украшения
    static final int BALL_RED = 0, BALL_BLUE = 1, BALL_GOLD = 2, BALL_PURPLE = 3, CANDY = 4, BELL = 5, FLAKE = 6,
            HEART = 7, STAR_SMALL = 8, ICICLE = 9, GIFT = 10, BULB = 11;
    static final int ORN_COUNT = 12;
    // верхушка
    static final int STAR_NONE = 0, STAR_PLAIN = 1, STAR_GLOW = 2;
    /** Номера предметов в ящике: украшения, потом две звезды и гирлянда. */
    static final int ITEM_STAR_PLAIN = ORN_COUNT, ITEM_STAR_GLOW = ORN_COUNT + 1, ITEM_GARLAND = ORN_COUNT + 2;
    static final int ITEM_COUNT = ORN_COUNT + 3;

    static final float HEIGHT = 150f, BASE_HALF = 50f;

    private static final String FILE = "tree.bin";
    private static final int VERSION = 1;

    static final class Orn {
        int type;
        float x, y, scale;

        Orn(int type, float x, float y, float scale) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.scale = scale;
        }
    }

    final ArrayList<Orn> orns = new ArrayList<>();
    int star = STAR_NONE;
    boolean garland;
    int fall;

    /** Половина ширины ёлки на высоте y (y от −150 до −10) — для проверки «попал в ёлку». */
    static float halfWidth(float y) {
        float t = (y + HEIGHT) / (HEIGHT - 12f);
        return BASE_HALF * Math.max(0f, Math.min(1f, t));
    }

    static boolean contains(float x, float y) {
        return y >= -HEIGHT - 6f && y <= -8f && Math.abs(x) <= halfWidth(y) + 5f;
    }

    boolean isEmpty() {
        return orns.isEmpty() && star == STAR_NONE && !garland;
    }

    static Tree load(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        Tree t = new Tree();
        if (!f.exists()) return t;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f)))) {
            if (in.readInt() != VERSION) return t;
            t.star = in.readInt();
            t.garland = in.readBoolean();
            t.fall = in.readInt();
            int n = in.readInt();
            if (n < 0 || n > 120) return new Tree();
            for (int i = 0; i < n; i++) {
                int type = in.readInt();
                float x = in.readFloat(), y = in.readFloat(), s = in.readFloat();
                if (type >= 0 && type < ORN_COUNT) t.orns.add(new Orn(type, x, y, s));
            }
        } catch (Exception e) {
            return new Tree();
        }
        return t;
    }

    static void save(Context c, Tree t) {
        File f = new File(c.getFilesDir(), FILE);
        File tmp = new File(f.getPath() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
            out.writeInt(VERSION);
            out.writeInt(t.star);
            out.writeBoolean(t.garland);
            out.writeInt(t.fall);
            out.writeInt(t.orns.size());
            for (Orn o : t.orns) {
                out.writeInt(o.type);
                out.writeFloat(o.x);
                out.writeFloat(o.y);
                out.writeFloat(o.scale);
            }
        } catch (Exception e) {
            return;
        }
        tmp.renameTo(f);
    }
}
