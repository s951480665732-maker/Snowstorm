package com.personal.snowdrift;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Полноэкранный прозрачный слой: падающий снег, сугроб активного приложения,
 * «поднятый» сугроб на экране недавних и снежные комья при встряхивании.
 * Сугробы — профили высот в dp из DriftStore, слой меняет их напрямую.
 */
public class SnowView extends View {
    private static final int MAX = 900;
    private static final int MAXP = 1600;
    private static final int COLS = DriftStore.COLS;
    private static final float[] SPREAD = {0.12f, 0.22f, 0.32f, 0.22f, 0.12f};
    /** Сугроб «утоплен» под нижний край на столько dp: первая линия выползает снизу, а не рисуется сразу. */
    private static final float SINK = 3f;
    /** За сколько dp видимой высоты сугроб проявляется из прозрачного. */
    private static final float FADE_IN = 8f;

    /** Сколько видов снежинок в ходу, сколько меняем за раз и как часто. */
    private static final long FRAME_60 = 16_666_667L, FRAME_30 = 33_333_333L;
    private static final int KINDS_LIVE = 10, KINDS_SWAP = 5;
    private static final float KINDS_EVERY_SEC = 20f;
    /**
     * Все картинки снежинок лежат в одном атласе (одна текстура на GPU — снежинки рисуются
     * одной пачкой). Ячейка 0 — круглая снежинка, остальные — сгенерированные виды.
     */
    private static final int ATLAS_COLS = 6, ATLAS_ROWS = 4, CELLS = ATLAS_COLS * ATLAS_ROWS;
    private static final int CELL = FlakeGen.SIZE + 4; // +2px прозрачного поля с каждой стороны


    /** Один отрисовываемый сугроб. */
    private static final class Slot {
        final float[] h;
        final float[] shape;
        float alpha, targetAlpha = 1f;

        Slot(float[] h, float[] shape) { this.h = h; this.shape = shape; }
    }

    private final float d;
    private final Random rnd = new Random();

    // снежинки (структура массивов, чтобы не плодить объекты)
    private final float[] fx = new float[MAX], fy = new float[MAX], fz = new float[MAX], fr = new float[MAX];
    private final float[] fv = new float[MAX], fph = new float[MAX], fps = new float[MAX];
    private final float[] frot = new float[MAX], frs = new float[MAX];
    private final byte[] fcell = new byte[MAX]; // ячейка атласа; 0 — простая круглая
    private int n, target = 120;

    // комья стряхнутого снега
    private final float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP];
    private final float[] pr = new float[MAXP], plife = new float[MAXP], pmax = new float[MAXP];
    private int np;

    private float speed = 1f, wind, windDir = 1f, t;
    // наклон телефона: куда падает снег (единичный вектор, сглаженный и целевой)
    private float dirx = 0f, diry = 1f, tdx = 0f, tdy = 1f, flowx = 0f, flowy = 1f;
    private boolean tiltOn = true;
    private final float[] tiltTmp = new float[2];
    // снеговик из мастерской: готовая картинка, стоит на снегу у нижнего края
    private final SnowmanArt art = new SnowmanArt();
    private final Paint snowmanPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Bitmap[] snowBmps = new Bitmap[2];
    private boolean showSnowman = true;
    private float snowmanAlpha;
    private boolean storm, suppressed;
    private int w, hgt;
    private float baseY, navPx;

    // «Пол»: к какому краю экрана стекает снег (0 снизу, 1 справа, 2 сверху, 3 слева) — по наклону телефона.
    // Сугроб считается и рисуется в «локальной» системе, где пол всегда внизу; холст поворачивается.
    private int floorEdge, targetEdge, relaxTick;
    private float edgeAlpha = 1f, tiltPhi;
    private float lw, lh, lBase, colW; // длина пола, глубина, линия пола, ширина колонки (px)

    private Slot active, fading, sand;
    private boolean changed;

    // сезон, праздник и всё, что живёт на «полу»
    private Season seasonInfo = Season.now(-1);
    private Season.Palette pal = seasonInfo.palette();
    private int particle = Season.P_SNOW;
    private final Decor decor;
    private final Lights lights = new Lights();
    private boolean garlandOn, lampOn;
    private int rawCount = 120;
    private float driftMaxDp = Float.POSITIVE_INFINITY;
    private float[] lastH;
    private String lastPkg;
    private final float[] emptyH = new float[COLS];
    private final Paint waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint foamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path water = new Path(), waterLine = new Path();

    /** Нажатие на упавшую ёлку: прямоугольник в экранных координатах (null — прячем). */
    interface TreeTouchListener {
        void onTreeTouch(RectF screenRect);
    }

    private TreeTouchListener treeListener;
    private final RectF treeLocal = new RectF(), treeScreen = new RectF();
    private boolean treeTouchSent;
    private float treeSentL, treeSentT, treeSentR, treeSentB;

    private boolean running;
    private long lastNanos, nextDue, frameInterval = FRAME_60;

    private final Bitmap atlas = Bitmap.createBitmap(ATLAS_COLS * CELL, ATLAS_ROWS * CELL, Bitmap.Config.ARGB_8888);
    private final Canvas atlasCanvas = new Canvas(atlas);
    private final android.graphics.Rect[] cellSrc = new android.graphics.Rect[CELLS];
    private final int[] cellRefs = new int[CELLS];          // сколько летящих снежинок носят этот вид
    private final ArrayList<Integer> live = new ArrayList<>(); // ячейки, которые выдаются новым снежинкам
    private final Paint clearPaint = new Paint();
    private final ExecutorService gen = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private float nextKindsAt = KINDS_EVERY_SEC;
    private boolean kindsPending;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint driftPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sparkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint partPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path fill = new Path(), edge = new Path();
    private final RectF rect = new RectF();
    private final int[] spCol = new int[16];
    private final float[] spOff = new float[16], spPh = new float[16];

    private final Choreographer.FrameCallback frame = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long now) {
            if (!running) return;
            Choreographer ch = Choreographer.getInstance();
            // Дисплей S24 сам меняет частоту (до 120 Гц), поэтому кадры идут по своему графику:
            // ровно 60 (или 30) в секунду, а между ними поток спит, а не просыпается на каждый vsync.
            if (lastNanos != 0 && now < nextDue - 4_000_000L) {
                ch.postFrameCallback(this);
                return;
            }
            float dt = lastNanos == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNanos) / 1e9f);
            lastNanos = now;
            nextDue = Math.max(nextDue + frameInterval, now + frameInterval / 2);
            step(dt);
            invalidate();
            long waitMs = (nextDue - now) / 1_000_000L - 6;
            if (waitMs > 0) ch.postFrameCallbackDelayed(this, waitMs);
            else ch.postFrameCallback(this);
        }
    };

    public SnowView(Context c) {
        super(c);
        d = getResources().getDisplayMetrics().density;
        for (int i = 0; i < CELLS; i++) {
            int x = (i % ATLAS_COLS) * CELL + 2, y = (i / ATLAS_COLS) * CELL + 2;
            cellSrc[i] = new android.graphics.Rect(x, y, x + FlakeGen.SIZE, y + FlakeGen.SIZE);
        }
        clearPaint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
        decor = new Decor(d);
        rebuildAtlas();

        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(1.6f * d);
        edgePaint.setColor(0xFFFFFFFF);
        shadePaint.setStyle(Paint.Style.STROKE);
        shadePaint.setStrokeWidth(7f * d);
        shadePaint.setColor(0xFF9DBCE0);
        sparkPaint.setColor(0xFFFFFFFF);
        sparkPaint.setStrokeWidth(1.1f * d);
        sparkPaint.setStrokeCap(Paint.Cap.ROUND);
        partPaint.setColor(0xFFF7FAFF);

        for (int i = 0; i < spCol.length; i++) {
            spCol[i] = 2 + rnd.nextInt(COLS - 4);
            spOff[i] = 1.5f + rnd.nextFloat() * 9f;
            spPh[i] = rnd.nextFloat() * 6.283f;
        }
    }

    // ---------------------------------------------------------------- управление

    void setParams(float speedFactor, int count, boolean storm, float driftMaxDp) {
        if (storm && !this.storm) windDir = rnd.nextBoolean() ? 1f : -1f;
        this.storm = storm;
        this.speed = speedFactor;
        this.rawCount = count;
        this.driftMaxDp = driftMaxDp;
        recomputeTarget();
    }

    /** Сколько частиц держим в небе: по ползунку и режиму «Шторм»; летом с неба ничего не падает. */
    private void recomputeTarget() {
        int t = storm ? Math.min(MAX, Math.max(350, Math.round(rawCount * 2.5f))) : Math.min(MAX, rawCount);
        if (particle == Season.P_NONE) t = 0;
        target = t;
        if (w > 0) {
            for (int i = n; i < target; i++) {
                spawn(i, false);
                pushBack(i, rnd.nextFloat() * hgt * 0.6f); // заходят постепенно, а не стеной
            }
            if (target > n) n = target;
            while (target == 0 && n > 0) removeFlake(n - 1);
            makeShader();
        }
    }

    /** Сезон и праздник: цвета «пола», что падает с неба, сезонные мелочи. */
    void setSeason(Season s) {
        boolean kindChanged = s.particle != particle;
        seasonInfo = s;
        pal = s.palette();
        decor.setSeason(s.season);
        edgePaint.setColor(pal.floorEdge);
        shadePaint.setColor(pal.floorShade);
        partPaint.setColor(pal.spray);
        if (kindChanged) {
            particle = s.particle;
            rebuildAtlas();
        }
        makeShader();
        recomputeTarget();
        applyActive();
    }

    void setPets(boolean cat, int catSkin, boolean dog, int dogSkin) {
        decor.setPets(cat, catSkin, dog, dogSkin);
    }

    void setTree(Tree t, boolean on) {
        decor.setTree(t, on);
    }

    void setPlow(boolean on) {
        decor.setPlow(on);
    }

    void setLego(Lego l, boolean show) {
        decor.setLego(l, show);
    }

    void setLights(boolean garland, boolean lamp) {
        garlandOn = garland;
        lampOn = lamp;
    }

    void setTreeTouchListener(TreeTouchListener l) {
        treeListener = l;
    }

    void raiseTree() {
        decor.raiseTree();
    }

    void callPlow() {
        decor.callPlow();
    }

    /** Модель ёлки, если она изменилась (упала/поднялась) — её надо сохранить. */
    Tree takeTreeIfChanged() {
        return decor.consumeTreeDirty() ? decor.tree() : null;
    }

    /** Экономный режим: 30 к/с вместо 60. */
    void setEco(boolean eco) {
        frameInterval = eco ? FRAME_30 : FRAME_60;
    }

    /** Снег падает по наклону телефона (иначе всегда вниз). */
    void setTilt(boolean on) {
        tiltOn = on;
    }

    /** Куда тянет вниз в координатах экрана (м/с²), из акселерометра. */
    void setGravity(float gx, float gy) {
        Tilt.direction(gx, gy, tiltTmp);
        tdx = tiltTmp[0];
        tdy = tiltTmp[1];
    }

    /** Снеговики из мастерской (до двух). Каждый рисуется один раз в картинку. */
    void setSnowmen(java.util.List<Snowman> list) {
        for (int i = 0; i < snowBmps.length; i++) {
            snowBmps[i] = null;
            Snowman m = list != null && i < list.size() ? list.get(i) : null;
            if (m == null || m.n == 0) continue;
            float[] b = m.bounds();
            float s = Math.min(0.5f * d, 200f * d / (b[3] - b[1]));
            snowBmps[i] = art.render(m, s);
        }
    }

    void setShowSnowman(boolean show) {
        showSnowman = show;
    }

    void setRunning(boolean r) {
        if (r == running) return;
        running = r;
        Choreographer ch = Choreographer.getInstance();
        if (r) {
            lastNanos = 0;
            nextDue = 0;
            ch.postFrameCallback(frame);
        } else {
            ch.removeFrameCallback(frame);
        }
    }

    /** Новое активное приложение (h == null — сугроба нет: лаунчер, экран блокировки). */
    void setActive(float[] h, String pkg) {
        lastH = h;
        lastPkg = pkg;
        applyActive();
    }

    /** Летом вместо накопленного сугроба — постоянный песок; в остальные сезоны — кучка из хранилища. */
    private void applyActive() {
        if (seasonInfo.season == Season.SUMMER) {
            if (sand == null) sand = new Slot(sandProfile(), DriftStore.shapeFor("sand"));
            if (active != sand) {
                fadeOut(active);
                active = sand;
            }
            return;
        }
        if (lastH == null) {
            if (active != null) fadeOut(active);
            active = null;
            return;
        }
        if (active != null && active.h == lastH) return;
        fadeOut(active);
        active = new Slot(lastH, DriftStore.shapeFor(lastPkg));
    }

    private static float[] sandProfile() {
        float[] h = new float[COLS];
        for (int i = 0; i < COLS; i++) h[i] = 20f + 5f * (float) Math.sin(i * 0.17f) + 2.5f * (float) Math.sin(i * 0.55f + 1f);
        return h;
    }

    boolean crumbleActive() {
        return active != null && active != sand && crumble(active); // песок летом не «тает»
    }

    /** Снег забрали для снеговика (или иначе поменяли высоты) — пора сохранить. */
    void markChanged() {
        changed = true;
    }

    /** Шторка уведомлений открыта: сугроб приложения прячется и не растёт. */
    void setSuppressed(boolean s) {
        suppressed = s;
    }

    boolean consumeChanged() {
        boolean c = changed;
        changed = false;
        return c;
    }

    private void fadeOut(Slot s) {
        if (s == null) return;
        s.targetAlpha = 0f;
        fading = s;
    }

    // ---------------------------------------------------------------- размеры

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        if (ow > 0) {
            for (int i = 0; i < n; i++) { fx[i] *= nw / (float) ow; fy[i] *= nh / (float) oh; }
        }
        w = nw;
        hgt = nh;
        updateBase();
        if (n == 0) {
            n = target;
            for (int i = 0; i < n; i++) spawn(i, true);
        }
        makeShader();
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets in) {
        updateBase();
        return super.onApplyWindowInsets(in);
    }

    /** Низ сугроба — над панелью навигации, т.е. по нижнему краю окна приложения. */
    private void updateBase() {
        int nav = 0;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsets wi = getRootWindowInsets();
            if (wi != null) nav = wi.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom;
            if (nav == 0) {
                WindowManager wm = getContext().getSystemService(WindowManager.class);
                if (wm != null) {
                    nav = wm.getCurrentWindowMetrics().getWindowInsets()
                            .getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom;
                }
            }
        } else if (hgt > getWidth()) {
            int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
            if (id > 0) nav = getResources().getDimensionPixelSize(id);
        }
        navPx = nav;
        baseY = hgt - nav;
        updateFloor();
    }

    private void makeShader() {
        if (hgt == 0) return;
        driftPaint.setShader(new LinearGradient(0, lBase - 160f * d, 0, lBase,
                pal.floorTop, pal.floorBottom, Shader.TileMode.CLAMP));
        waterPaint.setShader(new LinearGradient(0, lBase - 70f * d, 0, lBase - 20f * d,
                0xCC4FC3F7, 0xDD0277BD, Shader.TileMode.CLAMP));
    }

    /** Размеры «пола» для текущего края; панель навигации учитываем только у нижнего края. */
    private void updateFloor() {
        switch (floorEdge) {
            case 1:
            case 3:
                lw = hgt;
                lh = w;
                lBase = w;
                break;
            case 2:
                lw = w;
                lh = hgt;
                lBase = hgt;
                break;
            default:
                lw = w;
                lh = hgt;
                lBase = baseY;
        }
        colW = lw / (float) (COLS - 1);
        makeShader();
    }

    // экран -> локальные координаты пола (x вдоль пола, y вниз к полу) и обратно
    private float localX(float x, float y) {
        switch (floorEdge) {
            case 1: return hgt - y;
            case 2: return w - x;
            case 3: return y;
            default: return x;
        }
    }

    private float localY(float x, float y) {
        switch (floorEdge) {
            case 1: return x;
            case 2: return hgt - y;
            case 3: return w - x;
            default: return y;
        }
    }

    /** Составляющая скорости, направленная к полу. */
    private float localVy(float vx, float vy) {
        switch (floorEdge) {
            case 1: return vx;
            case 2: return -vy;
            case 3: return -vx;
            default: return vy;
        }
    }

    private float screenX(float lx, float ly) {
        switch (floorEdge) {
            case 1: return ly;
            case 2: return w - lx;
            case 3: return w - ly;
            default: return lx;
        }
    }

    private float screenY(float lx, float ly) {
        switch (floorEdge) {
            case 1: return hgt - lx;
            case 2: return hgt - ly;
            case 3: return lx;
            default: return ly;
        }
    }

    private void applyFloorTransform(Canvas c) {
        switch (floorEdge) {
            case 1:
                c.translate(0, hgt);
                c.rotate(-90f);
                break;
            case 2:
                c.translate(w, hgt);
                c.rotate(180f);
                break;
            case 3:
                c.translate(w, 0);
                c.rotate(90f);
                break;
            default:
                break;
        }
    }

    private static float edgeAngle(int e) {
        float hp = (float) (Math.PI / 2);
        return e == 1 ? hp : e == 2 ? (float) Math.PI : e == 3 ? -hp : 0f;
    }

    private static float wrapPi(float a) {
        float pi = (float) Math.PI;
        while (a > pi) a -= 2f * pi;
        while (a < -pi) a += 2f * pi;
        return a;
    }

    // ---------------------------------------------------------------- физика

    private void spawn(int i, boolean anywhere) {
        float z = (float) Math.pow(rnd.nextFloat(), 1.4);
        fz[i] = z;
        boolean seasonal = particle != Season.P_SNOW;
        boolean star = seasonal || (z > 0.45f && rnd.nextFloat() < 0.28f);
        cellRefs[fcell[i]]--;
        int cell = star ? live.get(rnd.nextInt(live.size())) : 0;
        fcell[i] = (byte) cell;
        cellRefs[cell]++;
        float r = seasonal ? 4f + 5.5f * z : star ? 3.5f + 4.5f * z : 0.9f + 2.6f * (float) Math.pow(z, 1.3);
        if (storm) r *= 0.85f;
        fr[i] = r * d;
        fv[i] = 0.8f + rnd.nextFloat() * 0.4f;
        fph[i] = rnd.nextFloat() * 6.283f;
        fps[i] = 0.6f + rnd.nextFloat() * 1.6f;
        frot[i] = rnd.nextFloat() * 360f;
        frs[i] = (rnd.nextFloat() - 0.5f) * 90f;
        if (anywhere) {
            fx[i] = rnd.nextFloat() * w;
            fy[i] = rnd.nextFloat() * hgt;
        } else {
            spawnEdge(i);
        }
    }

    /**
     * Новая снежинка появляется у края экрана, откуда идёт снег: берём случайную точку экрана
     * и отступаем от неё против потока, пока не выйдем за край. Когда телефон наклонён, снег
     * приходит сбоку (или снизу, если телефон перевёрнут), а не только сверху.
     */
    private void spawnEdge(int i) {
        float l = (float) Math.hypot(flowx, flowy);
        float ux = l < 1e-3f ? 0f : flowx / l, uy = l < 1e-3f ? 1f : flowy / l;
        float sx = rnd.nextFloat() * w, sy = rnd.nextFloat() * hgt;
        float mg = fr[i] + 6f * d;
        float tx = Float.MAX_VALUE, ty = Float.MAX_VALUE;
        if (ux > 1e-4f) tx = (sx + mg) / ux;
        else if (ux < -1e-4f) tx = (w + mg - sx) / -ux;
        if (uy > 1e-4f) ty = (sy + mg) / uy;
        else if (uy < -1e-4f) ty = (hgt + mg - sy) / -uy;
        float back = Math.min(tx, ty) + 1f;
        fx[i] = sx - ux * back;
        fy[i] = sy - uy * back;
    }

    /** Сдвигает снежинку назад против потока на dist пикселей. */
    private void pushBack(int i, float dist) {
        float l = (float) Math.hypot(flowx, flowy);
        if (l < 1e-3f) return;
        fx[i] -= flowx / l * dist;
        fy[i] -= flowy / l * dist;
    }

    private void removeFlake(int i) {
        cellRefs[fcell[i]]--;
        int last = --n;
        fx[i] = fx[last]; fy[i] = fy[last]; fz[i] = fz[last]; fr[i] = fr[last]; fv[i] = fv[last];
        fph[i] = fph[last]; fps[i] = fps[last]; frot[i] = frot[last]; frs[i] = frs[last]; fcell[i] = fcell[last];
    }

    private void step(float dt) {
        if (w == 0) return;
        t += dt;
        if (!kindsPending && t >= nextKindsAt) renewKinds();
        float fall = 62f * d * speed * (storm ? 1.9f : 1f);
        float wTarget = storm
                ? windDir * fall * (1.15f + 0.45f * (float) Math.sin(t * 0.6f) + 0.25f * (float) Math.sin(t * 1.7f + 1.3f))
                : fall * (0.16f * (float) Math.sin(t * 0.11f) + 0.07f * (float) Math.sin(t * 0.37f + 2f));
        wind += (wTarget - wind) * Math.min(1f, dt * 1.5f);

        // Куда падает снег: сглаженное направление «вниз» по наклону телефона.
        float tx = tiltOn ? tdx : 0f, ty = tiltOn ? tdy : 1f;
        float tk = Math.min(1f, dt * 4f);
        dirx += (tx - dirx) * tk;
        diry += (ty - diry) * tk;
        float dl = (float) Math.hypot(dirx, diry);
        if (dl < 0.2f) {
            dirx = 0f;
            diry = 1f;
        } else {
            dirx /= dl;
            diry /= dl;
        }
        flowx = dirx * fall + wind * 0.65f;
        flowy = diry * fall;
        snowmanAlpha += ((suppressed ? 0f : 1f) - snowmanAlpha) * Math.min(1f, dt * 5f);

        // Пол: к какому краю «стекает» снег — по наклону телефона (с гистерезисом, чтобы не дёргался).
        float theta = (float) Math.atan2(dirx, diry);
        if (tiltOn) {
            float dphi = wrapPi(theta - edgeAngle(targetEdge));
            if (Math.abs(dphi) > 0.96f) { // дальше ~55° от текущего края — переходим на ближайший
                targetEdge = ((int) Math.round(theta / (Math.PI / 2)) + 4) % 4;
                dphi = wrapPi(theta - edgeAngle(targetEdge));
            }
            tiltPhi = Math.max(-0.96f, Math.min(0.96f, dphi));
        } else {
            targetEdge = 0;
            tiltPhi = 0f;
        }
        if (targetEdge != floorEdge) { // сугроб гаснет у старого края и проявляется у нового
            edgeAlpha -= dt * 4f;
            if (edgeAlpha <= 0f) {
                edgeAlpha = 0f;
                floorEdge = targetEdge;
                updateFloor();
            }
        } else if (edgeAlpha < 1f) {
            edgeAlpha = Math.min(1f, edgeAlpha + dt * 4f);
        }

        if (active != null) active.targetAlpha = suppressed ? 0f : 1f;
        boolean land = active != null && !suppressed && active.alpha > 0.6f
                && edgeAlpha > 0.6f && floorEdge == targetEdge;
        float swayBase = (storm ? 6f : 14f) * d;

        for (int i = n - 1; i >= 0; i--) {
            float z = fz[i];
            fph[i] += fps[i] * dt;
            // скорость вдоль потока + покачивание поперёк него + ветер (в шторм)
            float sp = fall * (0.45f + 0.8f * z) * fv[i];
            float sw = (float) Math.cos(fph[i]) * swayBase * (0.4f + z);
            float vx = dirx * sp + wind * (0.35f + 0.65f * z) - diry * sw;
            float vy = diry * sp + dirx * sw;
            fx[i] += vx * dt;
            fy[i] += vy * dt;
            frot[i] += frs[i] * dt;
            float m = fr[i] + 4f * d;

            boolean gone = false;
            if (land) {
                float lx = localX(fx[i], fy[i]);
                if (localVy(vx, vy) > 0f && lx >= 0 && lx < lw) {
                    float fc = lx / colW;
                    if (localY(fx[i], fy[i]) >= lBase - Math.max(0f, heightAt(active.h, fc) - SINK) * d - fr[i] * 0.3f) {
                        deposit(fc, fr[i] / d);
                        gone = true;
                    }
                }
            }
            // снежинка ушла за край экрана в ту сторону, куда летит
            if (!gone && ((fx[i] < -m && vx <= 0f) || (fx[i] > w + m && vx >= 0f)
                    || (fy[i] < -m && vy <= 0f) || (fy[i] - fr[i] > hgt && vy >= 0f))) gone = true;
            if (gone) {
                if (i >= target) removeFlake(i);
                else spawn(i, false);
            }
        }
        if (land && active != sand) relax(active.h, colW / d, tiltPhi, (relaxTick++ & 1) == 0);

        animate(active, dt);
        if (fading != null) {
            animate(fading, dt);
            if (fading.alpha < 0.01f) fading = null;
        }

        decorStep(dt);

        float g = 1300f * d;
        for (int i = np - 1; i >= 0; i--) {
            pvy[i] += g * dt;
            pvx[i] *= 1f - 0.6f * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
            plife[i] -= dt;
            if (plife[i] <= 0 || py[i] > hgt + 20 * d) {
                int l = --np;
                px[i] = px[l]; py[i] = py[l]; pvx[i] = pvx[l]; pvy[i] = pvy[l];
                pr[i] = pr[l]; plife[i] = plife[l]; pmax[i] = pmax[l];
            }
        }
    }

    private static void animate(Slot s, float dt) {
        if (s == null) return;
        s.alpha += (s.targetAlpha - s.alpha) * Math.min(1f, dt * 5f);
    }

    /**
     * Смена видов: в фоне рисуем KINDS_SWAP новых, кладём их в свободные ячейки атласа,
     * а столько же самых старых перестают выдаваться новым снежинкам. Уже летящие доживают
     * до земли — виды меняются постепенно. Ячейка освобождается, когда упадёт последняя
     * снежинка её вида; если свободных ячеек пока нет (очень медленный снег) — пробуем позже.
     */
    private void renewKinds() {
        kindsPending = true;
        final long seed = rnd.nextLong();
        final int kind = particle;
        gen.execute(() -> {
            Random r = new Random(seed);
            final Bitmap[] fresh = new Bitmap[KINDS_SWAP];
            for (int i = 0; i < fresh.length; i++) fresh[i] = FlakeGen.make(r, kind);
            main.post(() -> {
                kindsPending = false;
                if (kind != particle) return; // сезон успел смениться — эти спрайты уже не нужны
                ArrayList<Integer> free = new ArrayList<>();
                for (int c = 1; c < CELLS && free.size() < KINDS_SWAP; c++) {
                    if (cellRefs[c] <= 0 && !live.contains(c)) free.add(c);
                }
                if (free.size() < KINDS_SWAP) {
                    nextKindsAt = t + 5f;
                    return;
                }
                for (int i = 0; i < KINDS_SWAP; i++) live.remove(0);
                for (int i = 0; i < KINDS_SWAP; i++) {
                    putCell(free.get(i), fresh[i]);
                    live.add(free.get(i));
                }
                nextKindsAt = t + KINDS_EVERY_SEC;
            });
        });
    }

    private static float heightAt(float[] h, float fc) {
        int i = (int) fc;
        if (i < 0) return h[0];
        if (i >= COLS - 1) return h[COLS - 1];
        float f = fc - i;
        return h[i] * (1 - f) + h[i + 1] * f;
    }

    /**
     * Снежинка легла: добавляем снег в несколько соседних колонок. Ограничения высоты нет —
     * сугроб растёт, пока его не растопят в приложении (потолок — чуть выше экрана, дальше не видно).
     */
    private void deposit(float fc, float rDp) {
        float[] h = active.h, shape = active.shape;
        int c = Math.round(fc);
        float amt = (0.45f + rDp * rDp * 0.09f) * 1.6f;
        float screenCap = lh / d * 1.2f;
        boolean limited = driftMaxDp < screenCap;
        for (int k = 0; k < SPREAD.length; k++) {
            int idx = c + k - 2;
            if (idx < 0 || idx >= COLS) continue;
            if (limited) { // ограничено ползунком: колонка растёт всё медленнее до своего «потолка»
                float cap = driftMaxDp * shape[idx];
                if (h[idx] >= cap) continue;
                float add = amt * SPREAD[k] * (0.4f + 0.6f * shape[idx]) * (0.3f + 0.7f * (1f - h[idx] / cap));
                h[idx] = Math.min(cap, h[idx] + add);
            } else {
                float add = amt * SPREAD[k] * (0.4f + 0.6f * shape[idx]) * 0.7f;
                h[idx] = Math.min(screenCap, h[idx] + add);
            }
        }
        changed = true;
    }

    /**
     * Осыпание: слишком крутые склоны расползаются. Угол естественного откоса ~31°, но отсчитывается
     * от настоящего горизонта: когда телефон наклонён (phi, радианы; плюс — вниз вправо вдоль пола),
     * допустимый уклон смещается, и снег стекает в нижний угол, как песок в лотке.
     */
    private static void relax(float[] h, float colWdp, float phi, boolean forward) {
        float hi = colWdp * (float) Math.tan(Math.min(1.45f, 0.55f + phi));  // макс. подъём вправо
        float lo = colWdp * (float) Math.tan(Math.max(-1.45f, phi - 0.55f)); // макс. спад вправо
        for (int k = 0; k < COLS - 1; k++) {
            int i = forward ? k : COLS - 2 - k;
            float rise = h[i + 1] - h[i];
            if (rise > hi) {
                float tr = Math.min((rise - hi) * 0.2f, h[i + 1]);
                h[i + 1] -= tr;
                h[i] += tr;
            } else if (rise < lo) {
                float tr = Math.min((lo - rise) * 0.2f, h[i]);
                h[i] -= tr;
                h[i + 1] += tr;
            }
        }
    }

    private boolean crumble(Slot s) {
        float[] h = s.h;
        float pivX = lw / 2f;
        boolean any = false;
        for (int c = 0; c < COLS; c++) {
            float vis = Math.min(h[c], lh / d) - SINK;
            if (vis < 0.8f) continue;
            any = true;
            int k = Math.min(5, 1 + (int) (vis / 7f));
            for (int j = 0; j < k && np < MAXP; j++) {
                float lx = c * colW + (rnd.nextFloat() - 0.5f) * colW;
                float ly = lBase - rnd.nextFloat() * vis * d;
                float vlx = (rnd.nextFloat() - 0.5f) * 320f * d + (lx - pivX) * 0.25f;
                float vly = -(120f + rnd.nextFloat() * 420f) * d * (0.6f + 0.4f * Math.min(1f, h[c] / 62f));
                int i = np++;
                px[i] = screenX(lx, ly);
                py[i] = screenY(lx, ly);
                switch (floorEdge) { // скорость из локальной системы пола в экранную
                    case 1: pvx[i] = vly; pvy[i] = -vlx; break;
                    case 2: pvx[i] = -vlx; pvy[i] = -vly; break;
                    case 3: pvx[i] = -vly; pvy[i] = vlx; break;
                    default: pvx[i] = vlx; pvy[i] = vly;
                }
                pr[i] = (1.2f + rnd.nextFloat() * 3.2f) * d;
                pmax[i] = plife[i] = 1.1f + rnd.nextFloat() * 0.9f;
            }
        }
        Arrays.fill(h, 0f);
        changed = true;
        return any;
    }

    // ---------------------------------------------------------------- отрисовка

    @Override
    protected void onDraw(Canvas c) {
        if (w == 0) return;
        c.save();
        applyFloorTransform(c);
        drawWater(c);
        drawSlot(c, fading, false);
        drawSlot(c, active, true);
        float decorA = snowmanAlpha * edgeAlpha;
        if (seasonInfo.season == Season.WINTER) drawSnowmen(c, decorA);
        if (decorA > 0.5f) decor.draw(c, decorA);
        c.restore();

        for (int i = 0; i < n; i++) {
            float r = fr[i], x = fx[i], y = fy[i];
            bmpPaint.setAlpha((int) (255 * (0.5f + 0.5f * fz[i])));
            rect.set(x - r, y - r, x + r, y + r);
            if (fcell[i] == 0 && particle == Season.P_SNOW) {
                c.drawBitmap(atlas, cellSrc[0], rect, bmpPaint);
            } else {
                c.save();
                c.rotate(frot[i], x, y);
                c.drawBitmap(atlas, cellSrc[fcell[i]], rect, bmpPaint);
                c.restore();
            }
        }

        for (int i = 0; i < np; i++) {
            partPaint.setAlpha((int) (255 * Math.min(1f, plife[i] / pmax[i] * 1.6f)));
            c.drawCircle(px[i], py[i], pr[i], partPaint);
        }
        lights.draw(c, w, hgt, d, t, garlandOn, lampOn);
    }

    /** Снеговики стоят на сугробе у пола (в локальной системе) и поднимаются вместе с ним. */
    private void drawSnowmen(Canvas c, float alpha) {
        if (!showSnowman || alpha < 0.01f) return;
        float[] pos = {0.82f, 0.62f};
        for (int i = 0; i < snowBmps.length; i++) {
            Bitmap bmp = snowBmps[i];
            if (bmp == null) continue;
            int bw = bmp.getWidth(), bh = bmp.getHeight();
            float x = Math.min(lw * pos[i] - bw / 2f, lw - bw - 4f * d);
            float drift = 0f;
            if (active != null) drift = Math.max(0f, heightAt(active.h, (x + bw / 2f) / colW) - SINK) * d;
            float y = Math.max(0f, lBase - drift - bh + 3f * d);
            snowmanPaint.setAlpha((int) (255 * alpha));
            c.drawBitmap(bmp, Math.max(0f, x), y, snowmanPaint);
        }
    }

    /** Летом над песком плещется вода. */
    private void drawWater(Canvas c) {
        if (seasonInfo.season != Season.SUMMER || lw <= 0f) return;
        float a = Math.min(1f, snowmanAlpha * edgeAlpha);
        if (a < 0.02f) return;
        float top = lBase - 56f * d;
        water.rewind();
        waterLine.rewind();
        for (int i = 0; i <= COLS - 1; i++) {
            float x = i * colW;
            float y = top + ((float) Math.sin(x * 0.018f / d * 1f + t * 1.6f) * 3.5f + (float) Math.sin(x * 0.007f / d - t) * 4f) * d;
            if (i == 0) {
                water.moveTo(x, lBase);
                water.lineTo(x, y);
                waterLine.moveTo(x, y);
            } else {
                water.lineTo(x, y);
                waterLine.lineTo(x, y);
            }
        }
        water.lineTo(lw, lBase);
        water.close();
        waterPaint.setAlpha((int) (255 * a));
        c.drawPath(water, waterPaint);
        foamPaint.setStyle(Paint.Style.STROKE);
        foamPaint.setStrokeWidth(1.6f * d);
        foamPaint.setColor(0xFFFFFFFF);
        foamPaint.setAlpha((int) (170 * a));
        c.drawPath(waterLine, foamPaint);
    }

    // ---------------------------------------------------------------- питомцы, ёлка, снегоход

    private void decorStep(float dt) {
        Slot s = active;
        decor.update(dt, lw, lBase, colW, s != null ? s.h : emptyH, suppressed);

        // снегоход счищает снег (песок и кучки листьев не трогает) и поднимает брызги
        float px0 = decor.plowX;
        if (!Float.isNaN(px0) && s != null && s != sand && seasonInfo.season == Season.WINTER) {
            int c0 = Math.max(0, (int) ((px0 - 26f * d) / colW)), c1 = Math.min(COLS - 1, (int) ((px0 + 26f * d) / colW) + 1);
            for (int i = c0; i <= c1; i++) {
                float hh = s.h[i] - SINK;
                if (hh <= 0.2f) continue;
                for (int k = 0; k < Math.min(3, 1 + (int) (hh / 10f)); k++) {
                    float ly = lBase - rnd.nextFloat() * hh * d;
                    addPart(i * colW, ly, (rnd.nextFloat() * 260f - 40f) * d * (px0 < lw / 2f ? 1f : -1f),
                            -(80f + rnd.nextFloat() * 360f) * d);
                }
                s.h[i] = 0f;
                changed = true;
            }
        }

        // упавшую ёлку можно поднять нажатием: отдаём службе прямоугольник для окошка-кнопки
        boolean has = decor.treeTouchRect(treeLocal);
        if (has) {
            float x0 = screenX(treeLocal.left, treeLocal.top), y0 = screenY(treeLocal.left, treeLocal.top);
            float x1 = screenX(treeLocal.right, treeLocal.bottom), y1 = screenY(treeLocal.right, treeLocal.bottom);
            treeScreen.set(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1));
        }
        if (treeListener != null) {
            if (has && (!treeTouchSent || treeScreen.left != treeSentL || treeScreen.top != treeSentT
                    || treeScreen.right != treeSentR || treeScreen.bottom != treeSentB)) {
                treeSentL = treeScreen.left;
                treeSentT = treeScreen.top;
                treeSentR = treeScreen.right;
                treeSentB = treeScreen.bottom;
                treeListener.onTreeTouch(treeScreen);
            } else if (!has && treeTouchSent) {
                treeListener.onTreeTouch(null);
            }
        }
        treeTouchSent = has;
    }

    /** Частица (брызги) в локальных координатах пола; скорость переводится в экранную систему. */
    private void addPart(float lx, float ly, float vlx, float vly) {
        if (np >= MAXP) return;
        int i = np++;
        px[i] = screenX(lx, ly);
        py[i] = screenY(lx, ly);
        switch (floorEdge) {
            case 1: pvx[i] = vly; pvy[i] = -vlx; break;
            case 2: pvx[i] = -vlx; pvy[i] = -vly; break;
            case 3: pvx[i] = -vly; pvy[i] = vlx; break;
            default: pvx[i] = vlx; pvy[i] = vly;
        }
        pr[i] = (1.2f + rnd.nextFloat() * 3.2f) * d;
        pmax[i] = plife[i] = 0.9f + rnd.nextFloat() * 0.8f;
    }

    // ---------------------------------------------------------------- картинки частиц: набор спрайтов нужного вида

    private void rebuildAtlas() {
        live.clear();
        putCell(0, particle == Season.P_SNOW ? makeDot() : FlakeGen.make(rnd, particle));
        for (int i = 1; i <= KINDS_LIVE; i++) {
            putCell(i, FlakeGen.make(rnd, particle));
            live.add(i);
        }
    }

    private void drawSlot(Canvas c, Slot s, boolean sparkle) {
        if (s == null || s.alpha < 0.01f) return;
        float[] h = s.h;
        float max = 0;
        for (float v : h) if (v > max) max = v;
        if (max <= SINK + 0.2f) return;
        float grow = Math.min(1f, (max - SINK) / FADE_IN);
        float alpha = s.alpha * grow * grow * edgeAlpha;

        edge.rewind();
        float px0 = 0, py0 = lBase - (h[0] - SINK) * d;
        edge.moveTo(px0, py0);
        for (int i = 1; i < COLS; i++) {
            float x = i * colW, y = lBase - (h[i] - SINK) * d;
            edge.quadTo(px0, py0, (px0 + x) / 2f, (py0 + y) / 2f);
            px0 = x;
            py0 = y;
        }
        edge.lineTo(px0, py0);
        fill.set(edge);
        fill.lineTo(lw, lBase + 1);
        fill.lineTo(0, lBase + 1);
        fill.close();

        c.save();
        c.clipRect(0, 0, lw, lBase); // утопленная часть не видна
        driftPaint.setAlpha((int) (250 * alpha));
        c.drawPath(fill, driftPaint);

        c.save();
        c.clipPath(fill);
        c.translate(0, 4.5f * d);
        shadePaint.setAlpha((int) (60 * alpha));
        c.drawPath(edge, shadePaint);
        c.restore();

        edgePaint.setAlpha((int) (235 * alpha));
        c.drawPath(edge, edgePaint);

        if (sparkle && pal.sparkle) {
            float r = 2.6f * d;
            for (int i = 0; i < spCol.length; i++) {
                float hc = h[spCol[i]] - SINK;
                if (hc < 6f) continue;
                float a = (float) Math.sin(t * 1.7f + spPh[i]);
                if (a <= 0) continue;
                a = a * a * a * a * a * a;
                float x = spCol[i] * colW;
                float y = lBase - (hc - Math.min(spOff[i], hc - 2f)) * d;
                sparkPaint.setAlpha((int) (255 * a * alpha));
                c.drawLine(x - r, y, x + r, y, sparkPaint);
                c.drawLine(x, y - r, x, y + r, sparkPaint);
            }
        }
        c.restore();
    }

    // ---------------------------------------------------------------- картинки снежинок

    private void putCell(int cell, Bitmap b) {
        android.graphics.Rect r = cellSrc[cell];
        atlasCanvas.drawRect(r.left - 2, r.top - 2, r.right + 2, r.bottom + 2, clearPaint);
        atlasCanvas.drawBitmap(b, null, r, null);
        b.recycle();
    }

    private static Bitmap makeDot() {
        int s = FlakeGen.SIZE;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(s / 2f, s / 2f, s / 2f,
                new int[]{0xFFFFFFFF, 0xF0FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        new Canvas(b).drawCircle(s / 2f, s / 2f, s / 2f, p);
        return b;
    }
}
