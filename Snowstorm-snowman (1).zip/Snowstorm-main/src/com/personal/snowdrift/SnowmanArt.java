package com.personal.snowdrift;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/** Рисование снежных шаров, игрушек и целого снеговика. Один экземпляр — один поток (UI). */
final class SnowmanArt {
    private static final float[][] MARKS = {
            {-0.35f, 0.20f, 0.12f}, {0.30f, -0.35f, 0.10f}, {0.10f, 0.50f, 0.14f},
            {-0.10f, -0.55f, 0.08f}, {0.55f, 0.10f, 0.09f}, {-0.55f, -0.25f, 0.07f}};

    private final Paint ball = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    SnowmanArt() {
        // Единичный шар: холст масштабируется на радиус, поэтому градиент один на все размеры.
        ball.setShader(new RadialGradient(-0.32f, -0.38f, 1.45f,
                new int[]{0xFFFFFFFF, 0xFFEEF5FC, 0xFFC4D6EA}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    // ---------------------------------------------------------------- снежный ком

    /** Шар радиуса r пикселей с центром (x, y); rot — поворот «комочков» на поверхности (градусы). */
    void drawBall(Canvas c, float x, float y, float r, float rot) {
        c.save();
        c.translate(x, y);
        c.scale(r, r);
        fill.setColor(0x2A6A8CB5);
        c.drawCircle(0f, 0.10f, 1.04f, fill);
        c.drawCircle(0f, 0f, 1f, ball);
        c.rotate(rot);
        for (int i = 0; i < MARKS.length; i++) {
            fill.setColor((i & 1) == 0 ? 0x30789CC8 : 0x55FFFFFF);
            c.drawCircle(MARKS[i][0], MARKS[i][1], MARKS[i][2], fill);
        }
        c.restore();
    }

    // ---------------------------------------------------------------- снеговик

    /** Рисует снеговика; (ox, oy) — точка на земле под центром нижнего шара, s — пикселей в единице модели. */
    void drawSnowman(Canvas c, Snowman m, float ox, float oy, float s) {
        if (m.n > 0) {
            float r0 = m.r[0] * s;
            fill.setColor(0x33102040);
            rf.set(ox - r0 * 1.25f, oy - r0 * 0.14f, ox + r0 * 1.25f, oy + r0 * 0.22f);
            c.drawOval(rf, fill);
        }
        drawLayer(c, m, ox, oy, s, -1);
        for (int i = 0; i < m.n; i++) drawBall(c, ox, oy + m.cy(i) * s, m.r[i] * s, i * 60f + 15f);
        for (int l = 1; l <= 3; l++) drawLayer(c, m, ox, oy, s, l);
    }

    private void drawLayer(Canvas c, Snowman m, float ox, float oy, float s, int layer) {
        for (Snowman.Toy t : m.toys) {
            if (Snowman.layer(t.type) == layer) drawToy(c, t.type, ox + t.x * s, oy + t.y * s, s * t.scale, t.flip);
        }
    }

    /** Снеговик целиком в картинку: s пикселей на единицу модели. */
    Bitmap render(Snowman m, float s) {
        float[] b = m.bounds();
        int w = Math.max(1, Math.round((b[2] - b[0]) * s));
        int h = Math.max(1, Math.round((b[3] - b[1]) * s));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        drawSnowman(new Canvas(bmp), m, -b[0] * s, -b[1] * s, s);
        return bmp;
    }

    // ---------------------------------------------------------------- игрушки

    private void rect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        fill.setColor(color);
        rf.set(l, t, r, b);
        c.drawRoundRect(rf, rad, rad, fill);
    }

    private void oval(Canvas c, float l, float t, float r, float b, int color) {
        fill.setColor(color);
        rf.set(l, t, r, b);
        c.drawOval(rf, fill);
    }

    private void tri(Canvas c, float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        path.rewind();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    private void dot(Canvas c, float x, float y, float r, int color) {
        fill.setColor(color);
        c.drawCircle(x, y, r, fill);
    }

    private void stroke(Canvas c, float x1, float y1, float x2, float y2, float w, int color) {
        line.setStrokeWidth(w);
        line.setColor(color);
        c.drawLine(x1, y1, x2, y2, line);
    }

    /** Игрушка с центром (x, y); s — пикселей на единицу игрушки, flip — зеркально по горизонтали. */
    void drawToy(Canvas c, int type, float x, float y, float s, boolean flip) {
        c.save();
        c.translate(x, y);
        c.scale(flip ? -s : s, s);
        switch (type) {
            case Snowman.CARROT:
                path.rewind();
                path.moveTo(-9f, -5.5f);
                path.lineTo(-9f, 5.5f);
                path.lineTo(19f, 0.8f);
                path.close();
                fill.setColor(0xFFFF8F1F);
                c.drawPath(path, fill);
                stroke(c, -3f, -3.2f, 0f, -0.8f, 1.2f, 0x66B34700);
                stroke(c, 4f, 0.2f, 7f, 2.6f, 1.2f, 0x66B34700);
                stroke(c, -9f, 0f, -14f, -4f, 2f, 0xFF43A047);
                stroke(c, -9f, 0f, -14f, 3.5f, 2f, 0xFF43A047);
                break;
            case Snowman.COAL:
                dot(c, 0f, 0f, 4.6f, 0xFF263238);
                dot(c, -1.4f, -1.5f, 1.3f, 0x88FFFFFF);
                break;
            case Snowman.BUTTON:
                dot(c, 0f, 0f, 5.8f, 0xFFE53935);
                dot(c, 0f, 0f, 3.6f, 0xFFC62828);
                dot(c, -1.2f, -0.9f, 0.8f, 0xFFFFCDD2);
                dot(c, 1.2f, 0.9f, 0.8f, 0xFFFFCDD2);
                break;
            case Snowman.SCARF:
                rect(c, 15f, 2f, 28f, 30f, 3f, 0xFFC62828);
                rect(c, 15f, 10f, 28f, 14f, 0f, 0xFFFFFFFF);
                rect(c, 15f, 20f, 28f, 24f, 0f, 0xFFFFFFFF);
                for (int i = 0; i < 4; i++) stroke(c, 17f + i * 3.4f, 30f, 17f + i * 3.4f, 34f, 1.2f, 0xFFFFFFFF);
                rect(c, -31f, -7f, 31f, 7f, 5f, 0xFFD32F2F);
                for (int i = 0; i < 5; i++) rect(c, -21f + i * 12f, -7f, -17f + i * 12f, 7f, 0f, 0xFFFFFFFF);
                break;
            case Snowman.TOP_HAT:
                oval(c, -28f, 10f, 28f, 22f, 0xFF1E1E24);
                rect(c, -17f, -24f, 17f, 16f, 0f, 0xFF2B2B33);
                rect(c, -17f, 3f, 17f, 11f, 0f, 0xFFC62828);
                oval(c, -17f, -29f, 17f, -19f, 0xFF3A3A44);
                break;
            case Snowman.BUCKET:
                path.rewind();
                path.moveTo(-20f, -14f);
                path.lineTo(20f, -14f);
                path.lineTo(14f, 18f);
                path.lineTo(-14f, 18f);
                path.close();
                fill.setColor(0xFF90A4AE);
                c.drawPath(path, fill);
                stroke(c, -17f, -4f, 17f, -4f, 1.4f, 0x55455A64);
                stroke(c, -15.5f, 6f, 15.5f, 6f, 1.4f, 0x55455A64);
                oval(c, -20f, -19f, 20f, -9f, 0xFF78909C);
                oval(c, -16f, -17f, 16f, -11f, 0xFF455A64);
                break;
            case Snowman.SANTA_HAT:
                path.rewind();
                path.moveTo(-24f, 16f);
                path.quadTo(-24f, -16f, 12f, -22f);
                path.quadTo(18f, -20f, 24f, 16f);
                path.close();
                fill.setColor(0xFFD32F2F);
                c.drawPath(path, fill);
                rect(c, -28f, 8f, 28f, 22f, 7f, 0xFFFFFFFF);
                dot(c, 14f, -23f, 6.5f, 0xFFFFFFFF);
                break;
            case Snowman.STICK:
                stroke(c, -24f, 12f, 24f, -12f, 4.5f, 0xFF6D4C41);
                stroke(c, 6f, -3f, 12f, -15f, 3f, 0xFF6D4C41);
                stroke(c, 14f, -7f, 25f, -19f, 3f, 0xFF6D4C41);
                break;
            case Snowman.BROOM:
                c.rotate(14f);
                stroke(c, 0f, -32f, 0f, 12f, 4f, 0xFF8D6E63);
                path.rewind();
                path.moveTo(-5f, 10f);
                path.lineTo(5f, 10f);
                path.lineTo(13f, 33f);
                path.lineTo(-13f, 33f);
                path.close();
                fill.setColor(0xFFF2C14E);
                c.drawPath(path, fill);
                for (int i = -2; i <= 2; i++) stroke(c, i * 1.6f, 14f, i * 4.6f, 33f, 1f, 0x66A8741A);
                rect(c, -6.5f, 9f, 6.5f, 14f, 1.5f, 0xFF6D4C41);
                break;
            case Snowman.ORNAMENT:
                rect(c, -3.5f, -15f, 3.5f, -9f, 1.5f, 0xFFF9A825);
                line.setStrokeWidth(1.4f);
                line.setColor(0xFFF9A825);
                c.drawCircle(0f, -17.5f, 2.6f, line);
                dot(c, 0f, 0f, 10.5f, 0xFFD81B60);
                dot(c, -3.5f, -3.5f, 3.2f, 0x66FFFFFF);
                stroke(c, -9f, 2f, 9f, 2f, 2f, 0x55FFFFFF);
                break;
            case Snowman.EARMUFFS:
                stroke(c, -18f, 3f, -14f, -9f, 3f, 0xFF455A64);
                stroke(c, -14f, -9f, 14f, -9f, 3f, 0xFF455A64);
                stroke(c, 14f, -9f, 18f, 3f, 3f, 0xFF455A64);
                dot(c, -18f, 4f, 7f, 0xFFE53935);
                dot(c, 18f, 4f, 7f, 0xFFE53935);
                dot(c, -18f, 4f, 4.2f, 0xFFFF8A80);
                dot(c, 18f, 4f, 4.2f, 0xFFFF8A80);
                break;
            case Snowman.PIPE:
                stroke(c, -14f, 5f, 6f, -2f, 2.6f, 0xFF3E2723);
                dot(c, 9f, -3f, 5.6f, 0xFF6D4C41);
                dot(c, 9f, -4.5f, 3.2f, 0xFF3E2723);
                dot(c, 11f, -13f, 2.4f, 0x66FFFFFF);
                dot(c, 14f, -18f, 3.2f, 0x44FFFFFF);
                break;
            case Snowman.HEART:
                path.rewind();
                path.moveTo(0f, 9f);
                path.cubicTo(-16f, -2f, -8f, -12f, 0f, -4f);
                path.cubicTo(8f, -12f, 16f, -2f, 0f, 9f);
                path.close();
                fill.setColor(0xFFE53956);
                c.drawPath(path, fill);
                dot(c, -4f, -3f, 2.2f, 0x66FFFFFF);
                break;
            case Snowman.BOW_TIE:
                tri(c, -13f, -7f, -2f, 0f, -13f, 7f, 0xFFD32F2F);
                tri(c, 13f, -7f, 2f, 0f, 13f, 7f, 0xFFD32F2F);
                rect(c, -3.5f, -4f, 3.5f, 4f, 2f, 0xFFB71C1C);
                break;
            case Snowman.SUNGLASSES:
                stroke(c, -17f, -2f, -21f, -4f, 1.6f, 0xFF1B1B1F);
                stroke(c, 17f, -2f, 21f, -4f, 1.6f, 0xFF1B1B1F);
                rect(c, -16f, -5f, -2f, 5f, 3.5f, 0xFF1B1B1F);
                rect(c, 2f, -5f, 16f, 5f, 3.5f, 0xFF1B1B1F);
                stroke(c, -2f, -2f, 2f, -2f, 1.6f, 0xFF1B1B1F);
                dot(c, -11f, -2f, 1.4f, 0x88FFFFFF);
                dot(c, 7f, -2f, 1.4f, 0x88FFFFFF);
                break;
            case Snowman.MITTEN:
                oval(c, -11f, -2f, -3f, 7f, 0xFF1E88E5);
                rect(c, -6f, -10f, 7f, 6f, 5.5f, 0xFF1E88E5);
                rect(c, -6.5f, 5f, 7.5f, 11f, 2f, 0xFFFFFFFF);
                break;
            case Snowman.CANDY:
                stroke(c, 0f, 12f, 0f, -6f, 5f, 0xFFFFFFFF);
                stroke(c, 0f, -6f, -3f, -12f, 5f, 0xFFFFFFFF);
                stroke(c, -3f, -12f, -9f, -12f, 5f, 0xFFFFFFFF);
                stroke(c, -9f, -12f, -12f, -7f, 5f, 0xFFFFFFFF);
                for (int i = 0; i < 4; i++) stroke(c, -2.5f, 9f - i * 4.5f, 2.5f, 6.5f - i * 4.5f, 1.8f, 0xFFE53935);
                break;
            case Snowman.BELL:
                path.rewind();
                path.moveTo(-9f, 8f);
                path.quadTo(-9f, -11f, 0f, -11f);
                path.quadTo(9f, -11f, 9f, 8f);
                path.close();
                fill.setColor(0xFFFFB300);
                c.drawPath(path, fill);
                rect(c, -11f, 6f, 11f, 10f, 2f, 0xFFFFA000);
                dot(c, 0f, 12f, 2.8f, 0xFF8D5A00);
                dot(c, -3f, -4f, 2.4f, 0x66FFFFFF);
                break;
            case Snowman.STAR:
                path.rewind();
                for (int i = 0; i < 10; i++) {
                    double a = Math.toRadians(-90 + 36 * i);
                    float r = (i & 1) == 0 ? 12f : 5.2f;
                    float px = (float) Math.cos(a) * r, py = (float) Math.sin(a) * r;
                    if (i == 0) path.moveTo(px, py);
                    else path.lineTo(px, py);
                }
                path.close();
                fill.setColor(0xFFFFC107);
                c.drawPath(path, fill);
                dot(c, -2f, -2f, 2f, 0x77FFFFFF);
                break;
            case Snowman.SMILE:
                dot(c, -12f, -3f, 2.1f, 0xFF263238);
                dot(c, -7f, 2f, 2.1f, 0xFF263238);
                dot(c, 0f, 4.5f, 2.1f, 0xFF263238);
                dot(c, 7f, 2f, 2.1f, 0xFF263238);
                dot(c, 12f, -3f, 2.1f, 0xFF263238);
                break;
            default:
                break;
        }
        c.restore();
    }
}
