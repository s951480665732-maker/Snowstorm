package com.personal.snowdrift;

/** Перевод показаний акселерометра в направление, куда должен падать снег. */
final class Tilt {
    private Tilt() {}

    /**
     * Показания акселерометра (м/с², ось x — вправо, y — вверх по корпусу) -> «куда тянет вниз»
     * в координатах экрана (x вправо, y вниз) с учётом поворота экрана (0..3 = Surface.ROTATION_*).
     */
    static void toScreen(float ax, float ay, int rotation, float[] out) {
        switch (rotation) {
            case 1:  out[0] = -ay; out[1] = ax;  break;
            case 2:  out[0] = ax;  out[1] = -ay; break;
            case 3:  out[0] = ay;  out[1] = -ax; break;
            default: out[0] = -ax; out[1] = ay;
        }
    }

    /**
     * Единичный вектор падения снега. Телефон лежит плашмя (вдоль экрана почти нет силы тяжести) —
     * снег просто идёт вниз; чем круче наклон, тем сильнее он поворачивает к нижнему краю.
     */
    static void direction(float gx, float gy, float[] out) {
        float len = (float) Math.hypot(gx, gy);
        float s = Math.max(0f, Math.min(1f, (len / 9.81f - 0.18f) / 0.30f));
        float dx = 0f, dy = 1f - s;
        if (len > 0.01f) {
            dx = s * gx / len;
            dy = (1f - s) + s * gy / len;
        }
        float n = (float) Math.hypot(dx, dy);
        if (n < 0.05f) {
            out[0] = 0f;
            out[1] = 1f;
        } else {
            out[0] = dx / n;
            out[1] = dy / n;
        }
    }
}
