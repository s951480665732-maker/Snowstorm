package com.personal.snowdrift;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.Random;

/**
 * Генератор уникальных снежинок. Как у настоящих кристаллов: шесть одинаковых лучей,
 * каждый зеркально симметричен; веточки отходят под ~60°. Случайно выбираются толщина,
 * число и длина веточек, «под-веточки», пластинки-сектора, центр и кончики лучей.
 */
final class FlakeGen {
    static final int SIZE = 72;

    private FlakeGen() {}

    /** Спрайт частицы нужного вида: снежинка, лист, лепесток, сердечко, кубик LEGO, тюльпан, тыква. */
    static Bitmap make(Random r, int kind) {
        switch (kind) {
            case Season.P_LEAF: return leaf(r);
            case Season.P_PETAL: return petal(r);
            case Season.P_HEART: return heart(r);
            case Season.P_LEGO: return lego(r);
            case Season.P_TULIP: return tulip(r);
            case Season.P_PUMPKIN: return pumpkin(r);
            case Season.P_STAR: return star(r);
            case Season.P_EGG: return egg(r);
            case Season.P_CONFETTI: return confetti(r);
            default: return make(r);
        }
    }

    private static Bitmap blank() {
        return Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
    }

    private static Paint fillPaint(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        return p;
    }

    private static Paint linePaint(int color, float w) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setStrokeCap(Paint.Cap.ROUND);
        return p;
    }

    private static Bitmap leaf(Random r) {
        int[] cols = {0xFFE8B923, 0xFFD9442B, 0xFFF08A24, 0xFFB5651D, 0xFFC9301F, 0xFFE0A81C};
        int color = cols[r.nextInt(cols.length)];
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        c.save();
        c.rotate(r.nextFloat() * 360f, m, m);
        Path p = new Path();
        float len = SIZE * 0.42f, wd = SIZE * (0.17f + r.nextFloat() * 0.1f);
        if (r.nextBoolean()) { // кленовый: пять острых «пальцев»
            for (int i = 0; i < 5; i++) {
                double a = Math.toRadians(-90 + (i - 2) * 38);
                float tipx = m + (float) Math.cos(a) * len * (i == 2 ? 1f : 0.82f), tipy = m + (float) Math.sin(a) * len * (i == 2 ? 1f : 0.82f);
                double a1 = a - Math.toRadians(14), a2 = a + Math.toRadians(14);
                p.moveTo(m, m);
                p.lineTo(m + (float) Math.cos(a1) * len * 0.45f, m + (float) Math.sin(a1) * len * 0.45f);
                p.lineTo(tipx, tipy);
                p.lineTo(m + (float) Math.cos(a2) * len * 0.45f, m + (float) Math.sin(a2) * len * 0.45f);
                p.close();
            }
            c.drawPath(p, fillPaint(color));
        } else { // овальный
            p.moveTo(m, m - len);
            p.quadTo(m + wd * 1.8f, m - len * 0.2f, m, m + len * 0.8f);
            p.quadTo(m - wd * 1.8f, m - len * 0.2f, m, m - len);
            p.close();
            c.drawPath(p, fillPaint(color));
        }
        c.drawLine(m, m - len * 0.7f, m, m + len * 0.95f, linePaint(0x88502010, 1.8f));
        c.restore();
        return b;
    }

    private static Bitmap petal(Random r) {
        int[] cols = {0xFFFFC2D6, 0xFFFFE0EA, 0xFFFFA8C5, 0xFFFFFFFF, 0xFFF9B4CE};
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        c.rotate(r.nextFloat() * 360f, m, m);
        Path p = new Path();
        float len = SIZE * 0.36f, wd = SIZE * (0.16f + r.nextFloat() * 0.08f);
        p.moveTo(m, m - len);
        p.cubicTo(m + wd * 2f, m - len * 0.5f, m + wd, m + len * 0.7f, m, m + len);
        p.cubicTo(m - wd, m + len * 0.7f, m - wd * 2f, m - len * 0.5f, m, m - len);
        p.close();
        c.drawPath(p, fillPaint(cols[r.nextInt(cols.length)]));
        c.drawLine(m, m - len * 0.4f, m, m + len * 0.8f, linePaint(0x40FFFFFF, 1.4f));
        return b;
    }

    private static Bitmap heart(Random r) {
        int[] cols = {0xFFE53956, 0xFFFF5C8A, 0xFFFF8FB1, 0xFFD81B60, 0xFFFF3B3B};
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f, s = SIZE * 0.34f;
        c.rotate((r.nextFloat() - 0.5f) * 50f, m, m);
        Path p = new Path();
        p.moveTo(m, m + s);
        p.cubicTo(m - s * 1.9f, m - s * 0.2f, m - s * 0.9f, m - s * 1.5f, m, m - s * 0.45f);
        p.cubicTo(m + s * 0.9f, m - s * 1.5f, m + s * 1.9f, m - s * 0.2f, m, m + s);
        p.close();
        c.drawPath(p, fillPaint(cols[r.nextInt(cols.length)]));
        c.drawCircle(m - s * 0.5f, m - s * 0.45f, s * 0.22f, fillPaint(0x66FFFFFF));
        return b;
    }

    private static Bitmap lego(Random r) {
        int[] cols = {0xFFD01012, 0xFF0D69AB, 0xFFF5CD2F, 0xFF237841, 0xFFFE8A18, 0xFFF2F3F2, 0xFF1B2A34};
        int color = cols[r.nextInt(cols.length)];
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        int studsX = r.nextBoolean() ? 2 : 3, studsY = 2;
        float cell = SIZE * 0.2f, bw = cell * studsX, bh = cell * studsY;
        c.rotate(r.nextFloat() * 360f, m, m);
        RectF body = new RectF(m - bw / 2f - 3, m - bh / 2f - 3, m + bw / 2f + 3, m + bh / 2f + 3);
        c.drawRoundRect(new RectF(body.left + 2, body.top + 3, body.right + 2, body.bottom + 3), 4, 4, fillPaint(0x55000000));
        c.drawRoundRect(body, 4, 4, fillPaint(color));
        Paint hi = fillPaint(0x40FFFFFF), lo = fillPaint(0x33000000);
        for (int ix = 0; ix < studsX; ix++) {
            for (int iy = 0; iy < studsY; iy++) {
                float cx = m - bw / 2f + cell * (ix + 0.5f), cy = m - bh / 2f + cell * (iy + 0.5f);
                c.drawCircle(cx + 1, cy + 1.5f, cell * 0.33f, lo);
                c.drawCircle(cx, cy, cell * 0.33f, fillPaint(color));
                c.drawCircle(cx - cell * 0.1f, cy - cell * 0.1f, cell * 0.14f, hi);
            }
        }
        return b;
    }

    private static Bitmap tulip(Random r) {
        int[] cols = {0xFFE53956, 0xFFFF7BAC, 0xFFFFC93C, 0xFFB45CD9, 0xFFFF8A3D};
        int color = cols[r.nextInt(cols.length)];
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        c.rotate(r.nextFloat() * 360f, m, m);
        c.drawLine(m, m + SIZE * 0.05f, m, m + SIZE * 0.4f, linePaint(0xFF3E9B4F, 3f));
        c.drawPath(leafShape(m, m + SIZE * 0.3f, SIZE * 0.16f), fillPaint(0xFF3E9B4F));
        Path p = new Path();
        float s = SIZE * 0.2f;
        p.moveTo(m - s, m - s * 0.6f);
        p.lineTo(m - s * 0.45f, m - s * 1.5f);
        p.lineTo(m, m - s * 0.8f);
        p.lineTo(m + s * 0.45f, m - s * 1.5f);
        p.lineTo(m + s, m - s * 0.6f);
        p.cubicTo(m + s, m + s * 0.8f, m - s, m + s * 0.8f, m - s, m - s * 0.6f);
        p.close();
        c.drawPath(p, fillPaint(color));
        c.drawPath(p, linePaint(0x33000000, 1.2f));
        return b;
    }

    private static Path leafShape(float cx, float cy, float s) {
        Path p = new Path();
        p.moveTo(cx, cy);
        p.quadTo(cx + s * 2f, cy - s * 0.6f, cx + s * 2.2f, cy - s * 1.6f);
        p.quadTo(cx + s * 0.4f, cy - s * 1.2f, cx, cy);
        p.close();
        return p;
    }

    private static Bitmap pumpkin(Random r) {
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f, s = SIZE * 0.3f;
        c.rotate((r.nextFloat() - 0.5f) * 60f, m, m);
        Paint o = fillPaint(r.nextBoolean() ? 0xFFF38B1F : 0xFFE67300);
        c.drawOval(new RectF(m - s * 1.25f, m - s * 0.85f, m - s * 0.1f, m + s * 0.95f), o);
        c.drawOval(new RectF(m + s * 0.1f, m - s * 0.85f, m + s * 1.25f, m + s * 0.95f), o);
        c.drawOval(new RectF(m - s * 0.8f, m - s * 0.95f, m + s * 0.8f, m + s * 1.0f), fillPaint(0xFFFF9A2E));
        c.drawRoundRect(new RectF(m - s * 0.12f, m - s * 1.3f, m + s * 0.18f, m - s * 0.8f), 3, 3, fillPaint(0xFF4C8A2B));
        Paint face = fillPaint(0xFF3A1B00);
        Path eye = new Path();
        eye.moveTo(m - s * 0.5f, m - s * 0.1f); eye.lineTo(m - s * 0.2f, m - s * 0.1f); eye.lineTo(m - s * 0.35f, m - s * 0.4f); eye.close();
        c.drawPath(eye, face);
        Path eye2 = new Path();
        eye2.moveTo(m + s * 0.2f, m - s * 0.1f); eye2.lineTo(m + s * 0.5f, m - s * 0.1f); eye2.lineTo(m + s * 0.35f, m - s * 0.4f); eye2.close();
        c.drawPath(eye2, face);
        c.drawRect(m - s * 0.4f, m + s * 0.25f, m + s * 0.4f, m + s * 0.45f, face);
        return b;
    }

    private static Bitmap star(Random r) {
        int[] cols = {0xFFFFD54F, 0xFFFFF176, 0xFFFFC107, 0xFFFFFFFF};
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f, R = SIZE * 0.4f;
        c.rotate(r.nextFloat() * 72f, m, m);
        Path p = new Path();
        for (int i = 0; i < 10; i++) {
            double a = Math.toRadians(-90 + 36 * i);
            float rr = (i & 1) == 0 ? R : R * 0.42f;
            float px = m + (float) Math.cos(a) * rr, py = m + (float) Math.sin(a) * rr;
            if (i == 0) p.moveTo(px, py);
            else p.lineTo(px, py);
        }
        p.close();
        c.drawPath(p, fillPaint(cols[r.nextInt(cols.length)]));
        c.drawCircle(m - R * 0.2f, m - R * 0.2f, R * 0.14f, fillPaint(0x88FFFFFF));
        return b;
    }

    private static Bitmap egg(Random r) {
        int[] cols = {0xFFE53956, 0xFF1E88E5, 0xFFFFC107, 0xFF43A047, 0xFFAB47BC, 0xFFFF7043};
        int col = cols[r.nextInt(cols.length)];
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        c.rotate((r.nextFloat() - 0.5f) * 90f, m, m);
        RectF oval = new RectF(m - SIZE * 0.23f, m - SIZE * 0.32f, m + SIZE * 0.23f, m + SIZE * 0.34f);
        c.drawOval(oval, fillPaint(col));
        c.save();
        c.clipRect(oval.left, oval.top, oval.right, oval.bottom);
        c.drawRect(oval.left, m - SIZE * 0.06f, oval.right, m + SIZE * 0.02f, fillPaint(0xFFFFFFFF));
        c.drawRect(oval.left, m + SIZE * 0.14f, oval.right, m + SIZE * 0.2f, fillPaint(0x66FFFFFF));
        c.restore();
        c.drawCircle(m - SIZE * 0.08f, m - SIZE * 0.17f, SIZE * 0.05f, fillPaint(0x66FFFFFF));
        return b;
    }

    private static Bitmap confetti(Random r) {
        Bitmap b = blank();
        Canvas c = new Canvas(b);
        float m = SIZE / 2f;
        c.rotate(r.nextFloat() * 360f, m, m);
        boolean blue = r.nextBoolean();
        float wd = SIZE * 0.34f, ht = SIZE * (0.12f + r.nextFloat() * 0.1f);
        c.drawRoundRect(new RectF(m - wd, m - ht, m + wd, m + ht), 3, 3, fillPaint(blue ? 0xFF0057B7 : 0xFFFFD700));
        c.drawRoundRect(new RectF(m - wd, m - ht, m, m + ht), 3, 3, fillPaint(blue ? 0xFF0057B7 : 0xFFFFD700));
        c.drawRoundRect(new RectF(m, m - ht, m + wd, m + ht), 3, 3, fillPaint(blue ? 0xFFFFD700 : 0xFF0057B7));
        return b;
    }

    static Bitmap make(Random r) {
        float R = SIZE / 2f - 4f;
        Path lines = new Path();  // штрихи одного луча (уже с зеркальной половиной)
        Path fills = new Path();  // залитые части одного луча

        float arm = R * (0.82f + r.nextFloat() * 0.18f);
        float width = 1.5f + r.nextFloat() * 2.2f;
        lines.moveTo(0, 0);
        lines.lineTo(0, -arm);

        // веточки: ближе к кончику — короче
        int branches = r.nextInt(5);
        float angle = (float) Math.toRadians(52 + r.nextFloat() * 16);
        boolean subBranches = r.nextFloat() < 0.4f;
        float lenBase = R * (0.22f + r.nextFloat() * 0.3f);
        for (int b = 0; b < branches; b++) {
            float pos = arm * (0.25f + 0.6f * (b + r.nextFloat() * 0.6f) / Math.max(1, branches));
            float taper = 1f - 0.55f * pos / arm;
            float len = lenBase * taper * (0.7f + r.nextFloat() * 0.5f);
            float ex = (float) Math.sin(angle) * len, ey = -pos - (float) Math.cos(angle) * len;
            float k = fitInside(ex, ey, R);
            ex *= k;
            ey *= k;
            mirrored(lines, 0, -pos, ex, ey);
            if (subBranches && len > R * 0.18f) {
                // маленькие отростки на веточке, параллельно лучу
                float mx = ex * 0.55f, my = -pos + (ey + pos) * 0.55f, sl = len * 0.35f;
                mirrored(lines, mx, my, mx, my - sl);
            }
        }

        // сектор-пластинка вдоль луча
        if (r.nextFloat() < 0.3f) {
            float p1 = arm * (0.3f + r.nextFloat() * 0.25f), p2 = arm * (0.65f + r.nextFloat() * 0.25f);
            float sw = R * (0.08f + r.nextFloat() * 0.1f);
            fills.moveTo(0, 0);
            fills.lineTo(sw, -p1);
            fills.lineTo(0, -p2);
            fills.lineTo(-sw, -p1);
            fills.close();
        }

        // кончик луча
        switch (r.nextInt(4)) {
            case 1: { // вилка
                float fl = R * 0.14f;
                mirrored(lines, 0, -arm * 0.88f, fl * 0.6f, -arm * 0.88f - fl);
                break;
            }
            case 2: // кружок
                fills.addCircle(0, -arm, width * (0.9f + r.nextFloat() * 0.6f), Path.Direction.CW);
                break;
            case 3: // маленький шестиугольник
                hexagon(lines, 0, -arm + R * 0.07f, R * 0.08f);
                break;
            default:
                break;
        }

        Path all = new Path(), allFill = new Path();
        Matrix m = new Matrix();
        float c = SIZE / 2f;
        for (int i = 0; i < 6; i++) {
            m.setRotate(i * 60f);
            m.postTranslate(c, c);
            all.addPath(lines, m);
            allFill.addPath(fills, m);
        }

        // центр: шестиугольник-пластинка, кольцо или ничего
        int center = r.nextInt(3);
        float cr = R * (0.12f + r.nextFloat() * 0.18f);
        Path centerPath = new Path();
        hexagon(centerPath, c, c, cr);

        int color = r.nextFloat() < 0.5f ? 0xFFFFFFFF : (r.nextBoolean() ? 0xFFEAF4FF : 0xFFDDEBFF);
        Bitmap bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);

        // мягкое свечение под кристаллом
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setColor(color);
        glow.setAlpha(70);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(width * 2.4f);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setMaskFilter(new BlurMaskFilter(SIZE * 0.04f, BlurMaskFilter.Blur.NORMAL));
        cv.drawPath(all, glow);

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setColor(color);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(width);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        cv.drawPath(all, stroke);

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(color);
        fill.setAlpha(190);
        cv.drawPath(allFill, fill);

        if (center == 0) {
            fill.setAlpha(220);
            cv.drawPath(centerPath, fill);
        } else if (center == 1) {
            stroke.setStrokeWidth(Math.max(1.2f, width * 0.8f));
            cv.drawPath(centerPath, stroke);
        } else {
            fill.setAlpha(255);
            cv.drawCircle(c, c, width * 1.3f, fill);
        }
        return bmp;
    }

    /** Отрезок и его отражение относительно оси луча. */
    private static void mirrored(Path p, float x0, float y0, float x1, float y1) {
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.moveTo(-x0, y0);
        p.lineTo(-x1, y1);
    }

    private static void hexagon(Path p, float cx, float cy, float rad) {
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(30 + 60 * i);
            float x = cx + (float) Math.cos(a) * rad, y = cy + (float) Math.sin(a) * rad;
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
        }
        p.close();
    }

    private static float fitInside(float x, float y, float R) {
        float d = (float) Math.sqrt(x * x + y * y);
        return d > R ? R / d : 1f;
    }
}
