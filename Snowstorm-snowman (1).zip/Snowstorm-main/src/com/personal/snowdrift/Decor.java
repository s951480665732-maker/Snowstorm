package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.Random;

/**
 * Жизнь на «полу» (в локальной системе SnowView, где пол всегда внизу): питомцы со следами,
 * ёлка, которую роняет кот, снегоход, постройка LEGO и сезонные мелочи (тыквы, тюльпаны, зонтик).
 * Ничего не знает про экран: всё считается по профилю высот пола.
 */
final class Decor {
    private static final float SINK = 3f;
    private static final int PRINTS = 48;

    private static final class Pet {
        final boolean cat;
        float x, dir = 1f, phase, timer = 1f, anim, stride, speedBase;
        int pose = PetArt.POSE_WALK;
        boolean run, hit;
        int mission;        // 1 — идёт ронять ёлку
        float targetX;

        Pet(boolean cat) {
            this.cat = cat;
            speedBase = cat ? 26f : 36f;
        }
    }

    private final float d;
    private final Random rnd = new Random();
    private final PetArt petArt = new PetArt();
    private final TreeArt treeArt = new TreeArt();
    private final LegoArt legoArt = new LegoArt();
    private final Glow glow = new Glow();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    // настройки
    private boolean catOn, dogOn, treeOn, plowOn, legoOn;
    private int catSkin, dogSkin, season;
    private Tree tree;
    private Lego lego;

    // окружение кадра
    private float lw, lBase, colW, time;
    private float[] h = new float[DriftStore.COLS];

    private final Pet cat = new Pet(true), dog = new Pet(false);

    // следы
    private final float[] prX = new float[PRINTS], prT = new float[PRINTS], prDir = new float[PRINTS], prSide = new float[PRINTS];
    private int prN;

    // ёлка: угол в градусах (плюс — вправо), анимация падения/подъёма
    private float treeAngle, aFrom, aTo, aT, aDur;
    private int aKind;            // 0 нет, 1 падение, 2 подъём
    private float knockCooldown = 90f + (float) Math.random() * 150f;
    boolean treeDirty;

    // снегоход
    float plowX = Float.NaN;
    private float plowDir, plowTimer;
    private boolean plowCall;

    // бабочка весной
    private float butterflyPhase;

    Decor(float density) {
        d = density;
        cat.x = 0.4f;
        dog.x = 0.7f;
        plowTimer = 5400f + rnd.nextFloat() * 9000f; // первый раз через 1.5–4 часа работы
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    // ---------------------------------------------------------------- настройки

    void setSeason(int s) {
        season = s;
    }

    void setPets(boolean catOn, int catSkin, boolean dogOn, int dogSkin) {
        this.catOn = catOn;
        this.dogOn = dogOn;
        this.catSkin = catSkin;
        this.dogSkin = dogSkin;
    }

    /** Ёлка из хранилища; on — показывать (только зимой). Состояние «лежит» берётся из модели. */
    void setTree(Tree t, boolean on) {
        tree = t;
        treeOn = on;
        if (t != null && aKind == 0) treeAngle = t.fall * 84f;
    }

    void setPlow(boolean on) {
        plowOn = on;
    }

    void setLego(Lego l, boolean show) {
        lego = l;
        legoOn = show;
    }

    /** Снегоход проедет прямо сейчас (кнопка проверки). */
    void callPlow() {
        plowCall = true;
    }

    boolean consumeTreeDirty() {
        boolean r = treeDirty;
        treeDirty = false;
        return r;
    }

    Tree tree() {
        return tree;
    }

    // ---------------------------------------------------------------- ёлка: падение и подъём

    boolean treeFallen() {
        return tree != null && tree.fall != 0;
    }

    void raiseTree() {
        if (tree == null || tree.fall == 0 || aKind == 2) return;
        tree.fall = 0;
        start(treeAngle, 0f, 1.15f, 2);
        knockCooldown = 150f + rnd.nextFloat() * 240f;
        treeDirty = true;
    }

    private void fallTree(int dir) {
        if (tree == null || tree.fall != 0) return;
        tree.fall = dir;
        start(treeAngle, 84f * dir, 0.95f, 1);
        treeDirty = true;
    }

    private void start(float from, float to, float dur, int kind) {
        aFrom = from;
        aTo = to;
        aT = 0f;
        aDur = dur;
        aKind = kind;
    }

    private static float fallCurve(float u) {
        if (u < 0.6f) {
            float k = u / 0.6f;
            return k * k;
        }
        if (u < 0.8f) return 1f - 0.12f * (float) Math.sin(Math.PI * (u - 0.6f) / 0.2f);
        return 1f - 0.04f * (float) Math.sin(Math.PI * (u - 0.8f) / 0.2f);
    }

    private static float backOut(float u) {
        float c1 = 1.70158f, c3 = c1 + 1f, v = u - 1f;
        return 1f + c3 * v * v * v + c1 * v * v;
    }

    /** Прямоугольник для нажатия на упавшую ёлку (локальные координаты); false, если ёлка стоит или падает. */
    boolean treeTouchRect(RectF out) {
        if (!treeOn || tree == null || tree.fall == 0 || aKind != 0 || lw <= 0f) return false;
        float s = 0.72f * d, bx = treeX(), by = baseY(bx);
        double a = Math.toRadians(treeAngle);
        float co = (float) Math.cos(a), si = (float) Math.sin(a);
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        float[] cx = {-52f, 52f, 52f, -52f}, cy = {-156f, -156f, 0f, 0f};
        for (int i = 0; i < 4; i++) {
            float x = bx + (cx[i] * co - cy[i] * si) * s, y = by + (cx[i] * si + cy[i] * co) * s;
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        out.set(minX - 8f * d, minY - 8f * d, maxX + 8f * d, maxY + 8f * d);
        return true;
    }

    private float treeX() {
        return lw * 0.14f;
    }

    private float baseY(float x) {
        return surf(x) + 2f * d;
    }

    // ---------------------------------------------------------------- кадр

    private static float heightAt(float[] h, float fc) {
        int i = (int) fc;
        if (i < 0) return h[0];
        if (i >= h.length - 1) return h[h.length - 1];
        float f = fc - i;
        return h[i] * (1 - f) + h[i + 1] * f;
    }

    /** Высота поверхности пола под x (пиксели от низа экрана вверх — как положение y в локальной системе). */
    private float surf(float x) {
        return lBase - Math.max(0f, heightAt(h, x / colW) - SINK) * d;
    }

    private float snowDepthDp(float x) {
        return Math.max(0f, heightAt(h, x / colW) - SINK);
    }

    void update(float dt, float lw, float lBase, float colW, float[] heights, boolean suppressed) {
        this.lw = lw;
        this.lBase = lBase;
        this.colW = colW;
        this.h = heights;
        time += dt;
        if (lw <= 0f) return;
        if (cat.x < 2f) cat.x *= lw;   // стартовые доли -> пиксели
        if (dog.x < 2f) dog.x *= lw;

        // ёлка
        if (aKind != 0) {
            aT += dt;
            float u = Math.min(1f, aT / aDur);
            float f = aKind == 1 ? fallCurve(u) : backOut(u);
            treeAngle = aFrom + (aTo - aFrom) * f;
            if (u >= 1f) {
                aKind = 0;
                treeAngle = aTo;
            }
        }
        boolean standing = treeOn && tree != null && tree.fall == 0 && aKind == 0 && season == Season.WINTER;
        if (standing && catOn) knockCooldown -= dt;

        if (catOn) updatePet(cat, dt, standing);
        if (dogOn) updatePet(dog, dt, false);
        butterflyPhase += dt;

        // снегоход
        if (!Float.isNaN(plowX)) {
            plowX += plowDir * 330f * d * dt;
            if ((plowDir > 0f && plowX > lw + 90f * d) || (plowDir < 0f && plowX < -90f * d)) plowX = Float.NaN;
        } else if (season == Season.WINTER && plowOn && !suppressed) {
            plowTimer -= dt;
            if (plowTimer <= 0f || plowCall) {
                boolean snow = false;
                for (float v : h) if (v > 8f) { snow = true; break; }
                if (snow || plowCall) {
                    plowDir = rnd.nextBoolean() ? 1f : -1f;
                    plowX = plowDir > 0f ? -90f * d : lw + 90f * d;
                    plowTimer = 7200f + rnd.nextFloat() * 10800f; // следующий — через 2–5 часов
                } else {
                    plowTimer = 900f; // снега нет — проверим позже
                }
                plowCall = false;
            }
        } else {
            plowCall = false;
        }
    }

    private void updatePet(Pet p, float dt, boolean treeStanding) {
        p.timer -= dt;
        float lo = lw * 0.05f, hi = lw * 0.95f;
        switch (p.pose) {
            case PetArt.POSE_SIT:
            case PetArt.POSE_SLEEP:
                if (p.timer <= 0f) walk(p, rnd.nextBoolean() ? 1f : -1f);
                break;
            case PetArt.POSE_SWAT:
                p.anim = Math.min(1f, 1f - p.timer / 0.75f);
                if (!p.hit && p.anim > 0.45f) {
                    p.hit = true;
                    fallTree(p.dir > 0f ? 1 : -1);
                    knockCooldown = 200f + rnd.nextFloat() * 300f;
                }
                if (p.timer <= 0f) {
                    p.mission = 0;
                    walk(p, -p.dir);
                    p.run = true;
                    p.timer = 2.5f;
                }
                break;
            default: {
                float v = p.speedBase * (p.run ? 2.2f : 1f) * d;
                if (p.mission == 1) {
                    p.dir = p.targetX > p.x ? 1f : -1f;
                    if (!treeStanding) p.mission = 0;
                    else if (Math.abs(p.x - p.targetX) < 3f * d) {
                        p.pose = PetArt.POSE_SWAT;
                        p.dir = treeX() > p.x ? 1f : -1f;
                        p.timer = 0.75f;
                        p.anim = 0f;
                        p.hit = false;
                        break;
                    }
                }
                p.x += p.dir * v * dt;
                p.phase += v * dt / (p.cat ? 9f * d : 11f * d);
                p.stride += v * dt;
                if (p.stride >= 13f * d) {
                    p.stride = 0f;
                    addPrint(p.x - p.dir * 6f * d, p.dir);
                }
                if (p.mission == 0) {
                    if (p.x < lo) p.dir = 1f;
                    else if (p.x > hi) p.dir = -1f;
                }
                if (p.timer <= 0f && p.mission == 0) {
                    p.run = false;
                    float r = rnd.nextFloat();
                    if (r < 0.3f) {
                        p.pose = PetArt.POSE_SIT;
                        p.timer = 2f + rnd.nextFloat() * 4f;
                    } else if (r < 0.5f && p.cat) {
                        p.pose = PetArt.POSE_SLEEP;
                        p.timer = 6f + rnd.nextFloat() * 10f;
                    } else {
                        if (rnd.nextFloat() < 0.4f) p.dir = -p.dir;
                        p.run = !p.cat && rnd.nextFloat() < 0.3f;
                        p.timer = 3f + rnd.nextFloat() * 6f;
                    }
                }
                // кот решил уронить ёлку
                if (p.cat && treeStanding && p.mission == 0 && knockCooldown <= 0f && p.pose == PetArt.POSE_WALK) {
                    p.mission = 1;
                    p.run = false;
                    p.targetX = p.x < treeX() ? treeX() - 26f * d : treeX() + 26f * d;
                }
            }
        }
        p.x = Math.max(lo * 0.5f, Math.min(lw - lo * 0.5f, p.x));
    }

    private void walk(Pet p, float dir) {
        p.pose = PetArt.POSE_WALK;
        p.dir = dir;
        p.timer = 3f + rnd.nextFloat() * 6f;
    }

    private void addPrint(float x, float dir) {
        if (prN == PRINTS) {
            System.arraycopy(prX, 1, prX, 0, PRINTS - 1);
            System.arraycopy(prT, 1, prT, 0, PRINTS - 1);
            System.arraycopy(prDir, 1, prDir, 0, PRINTS - 1);
            System.arraycopy(prSide, 1, prSide, 0, PRINTS - 1);
            prN--;
        }
        prX[prN] = x;
        prT[prN] = time;
        prDir[prN] = dir;
        prSide[prN] = (prN & 1) == 0 ? 1f : -1f;
        prN++;
    }

    // ---------------------------------------------------------------- отрисовка

    /** Рисует всё в локальной системе пола; alpha — общая прозрачность (смена края, шторка). */
    void draw(Canvas c, float alpha) {
        if (lw <= 0f || alpha < 0.02f) return;
        switch (season) {
            case Season.WINTER:
                if (treeOn && tree != null) drawTree(c);
                break;
            case Season.AUTUMN:
                pumpkin(c, lw * 0.22f, 11f);
                pumpkin(c, lw * 0.28f, 7f);
                mushroom(c, lw * 0.7f);
                break;
            case Season.SPRING:
                tulips(c, lw * 0.2f);
                tulips(c, lw * 0.32f);
                tulips(c, lw * 0.74f);
                butterfly(c);
                break;
            default:
                umbrella(c, lw * 0.2f);
                sandcastle(c, lw * 0.7f);
        }
        if (legoOn && lego != null && !lego.isEmpty()) {
            float s = 0.8f * d, x = lw * 0.62f;
            legoArt.draw(c, lego, x - Lego.COLS * Lego.UNIT * s / 2f, surf(x) + 2f * d, s);
        }
        drawPrints(c);
        if (dogOn) drawPet(c, dog, dogSkin);
        if (catOn) drawPet(c, cat, catSkin);
        if (!Float.isNaN(plowX)) drawPlow(c);
    }

    private void drawTree(Canvas c) {
        float bx = treeX(), by = baseY(bx);
        c.save();
        c.translate(bx, by);
        c.rotate(treeAngle);
        treeArt.draw(c, tree, 0f, 0f, 0.72f * d, time, true);
        c.restore();
    }

    private void drawPet(Canvas c, Pet p, int skin) {
        float s = (p.cat ? 1.0f : 1.05f) * d;
        float y = surf(p.x) + 1.5f * d;
        petArt.draw(c, p.cat, skin, p.x, y, s, p.dir < 0f, p.phase, p.pose, p.anim, season);
    }

    /** Следы лап: на снегу и на песке; со временем исчезают. */
    private void drawPrints(Canvas c) {
        if (season != Season.WINTER && season != Season.SUMMER) return;
        int base = season == Season.WINTER ? 0x507AA8 : 0x806030;
        for (int i = 0; i < prN; i++) {
            float age = time - prT[i];
            if (age > 70f) continue;
            float x = prX[i];
            if (x < 0f || x > lw) continue;
            if (season == Season.WINTER && snowDepthDp(x) < 3f) continue;
            float a = Math.max(0f, 1f - age / 70f) * 0.55f;
            float y = surf(x) + 4f * d + prSide[i] * 1.2f * d;
            fill.setColor(((int) (255 * a) << 24) | base);
            c.save();
            c.translate(x, y);
            c.scale(prDir[i] * d, d);
            rf.set(-2.4f, -1.6f, 1.2f, 1.8f);
            c.drawOval(rf, fill);
            c.drawCircle(2.2f, -1.7f, 0.95f, fill);
            c.drawCircle(3.1f, 0.1f, 0.95f, fill);
            c.drawCircle(2.2f, 1.9f, 0.95f, fill);
            c.restore();
        }
    }

    // ---------------------------------------------------------------- снегоход

    private void drawPlow(Canvas c) {
        float x = plowX, y = lBase;
        c.save();
        c.translate(x, y);
        c.scale(plowDir * d, d);
        // гусеница
        rect(c, -32f, -9f, 10f, 0f, 4.5f, 0xFF2B2E33);
        for (int i = 0; i < 9; i++) rect(c, -30f + i * 4.7f, -2f, -28f + i * 4.7f, 1f, 0.5f, 0xFF52575E);
        // лыжа
        line.setColor(0xFF9AA3AD);
        line.setStrokeWidth(3.2f);
        path.rewind();
        path.moveTo(-2f, -2f);
        path.lineTo(30f, -2.5f);
        path.quadTo(37f, -3f, 36f, -9f);
        c.drawPath(path, line);
        // корпус
        path.rewind();
        path.moveTo(-28f, -9f);
        path.lineTo(-26f, -22f);
        path.lineTo(2f, -24f);
        path.quadTo(18f, -20f, 30f, -11f);
        path.lineTo(26f, -7f);
        path.close();
        fill.setColor(0xFFD32F2F);
        c.drawPath(path, fill);
        rect(c, -26f, -26f, -6f, -21f, 2.5f, 0xFF2B2B30); // сиденье
        path.rewind(); // стекло
        path.moveTo(7f, -24f);
        path.lineTo(14f, -35f);
        path.lineTo(19f, -22f);
        path.close();
        fill.setColor(0x88CFEFFF);
        c.drawPath(path, fill);
        // отвал
        path.rewind();
        path.moveTo(30f, -15f);
        path.lineTo(44f, -3f);
        path.lineTo(30f, -3f);
        path.close();
        fill.setColor(0xFFFFA000);
        c.drawPath(path, fill);
        glow.draw(c, 30f, -14f, 15f, 0xFFFFF1A8, 0.7f);
        fill.setColor(0xFFFFF8D0);
        c.drawCircle(28f, -14f, 2.6f, fill);
        // водитель
        rect(c, -20f, -38f, -9f, -26f, 3f, 0xFF1E88E5);
        fill.setColor(0xFFE53935);
        c.drawCircle(-12f, -42f, 5f, fill);
        rect(c, -11f, -45f, -6f, -41f, 1.5f, 0xFF263238);
        c.restore();
    }

    // ---------------------------------------------------------------- сезонные мелочи

    private void rect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        fill.setColor(color);
        rf.set(l, t, r, b);
        c.drawRoundRect(rf, rad, rad, fill);
    }

    private void pumpkin(Canvas c, float x, float r) {
        float y = surf(x) + 2f * d;
        c.save();
        c.translate(x, y);
        c.scale(d, d);
        fill.setColor(0xFFE67300);
        rf.set(-r, -r * 1.6f, -r * 0.1f, 0f);
        c.drawOval(rf, fill);
        rf.set(r * 0.1f, -r * 1.6f, r, 0f);
        c.drawOval(rf, fill);
        fill.setColor(0xFFFF9A2E);
        rf.set(-r * 0.7f, -r * 1.7f, r * 0.7f, 0f);
        c.drawOval(rf, fill);
        rect(c, -r * 0.12f, -r * 2.1f, r * 0.14f, -r * 1.5f, 1.2f, 0xFF4C8A2B);
        c.restore();
    }

    private void mushroom(Canvas c, float x) {
        float y = surf(x) + 2f * d;
        c.save();
        c.translate(x, y);
        c.scale(d, d);
        rect(c, -2.5f, -9f, 2.5f, 0f, 1.5f, 0xFFF3E9D2);
        fill.setColor(0xFFD32F2F);
        rf.set(-9f, -17f, 9f, -6f);
        c.drawOval(rf, fill);
        fill.setColor(0xFFFFFFFF);
        c.drawCircle(-3.5f, -12f, 1.6f, fill);
        c.drawCircle(2f, -14f, 1.4f, fill);
        c.drawCircle(5f, -10f, 1.2f, fill);
        c.restore();
    }

    private void tulips(Canvas c, float x) {
        int[] cols = {0xFFE53956, 0xFFFFC93C, 0xFFB45CD9};
        for (int i = 0; i < 3; i++) {
            float px = x + (i - 1) * 9f * d, y = surf(px) + 2f * d, hh = (22f + i * 4f - (i == 1 ? 3f : 0f)) * d;
            float sway = (float) Math.sin(time * 1.4f + i * 1.3f) * 1.2f * d;
            line.setColor(0xFF3E9B4F);
            line.setStrokeWidth(1.8f * d);
            c.drawLine(px, y, px + sway, y - hh, line);
            c.save();
            c.translate(px + sway, y - hh);
            c.scale(d, d);
            path.rewind();
            path.moveTo(-5f, -3f);
            path.lineTo(-2.5f, -8f);
            path.lineTo(0f, -4f);
            path.lineTo(2.5f, -8f);
            path.lineTo(5f, -3f);
            path.cubicTo(5f, 5f, -5f, 5f, -5f, -3f);
            path.close();
            fill.setColor(cols[i]);
            c.drawPath(path, fill);
            c.restore();
        }
    }

    private void butterfly(Canvas c) {
        float x = lw * 0.5f + (float) Math.sin(butterflyPhase * 0.4f) * lw * 0.3f;
        float y = surf(x) - (60f + (float) Math.sin(butterflyPhase * 1.3f) * 22f) * d;
        float flap = 0.35f + 0.65f * Math.abs((float) Math.sin(butterflyPhase * 11f));
        c.save();
        c.translate(x, y);
        c.scale(d, d);
        fill.setColor(0xFFFF8A3D);
        rf.set(-8f * flap, -6f, 0f, 2f);
        c.drawOval(rf, fill);
        rf.set(0f, -6f, 8f * flap, 2f);
        c.drawOval(rf, fill);
        fill.setColor(0xFFFFB86B);
        rf.set(-6f * flap, 0f, 0f, 6f);
        c.drawOval(rf, fill);
        rf.set(0f, 0f, 6f * flap, 6f);
        c.drawOval(rf, fill);
        rect(c, -0.8f, -5f, 0.8f, 5f, 0.8f, 0xFF3A2A1A);
        c.restore();
    }

    private void umbrella(Canvas c, float x) {
        float y = surf(x) + 2f * d;
        c.save();
        c.translate(x, y);
        c.scale(d, d);
        line.setColor(0xFF8D6E63);
        line.setStrokeWidth(2.2f);
        c.drawLine(0f, 0f, 3f, -44f, line);
        for (int i = 0; i < 6; i++) {
            float a0 = 180f + i * 30f;
            path.rewind();
            path.moveTo(3f, -44f);
            path.lineTo(3f + 26f * (float) Math.cos(Math.toRadians(a0)), -44f + 18f * (float) Math.sin(Math.toRadians(a0)));
            path.lineTo(3f + 26f * (float) Math.cos(Math.toRadians(a0 + 30f)), -44f + 18f * (float) Math.sin(Math.toRadians(a0 + 30f)));
            path.close();
            fill.setColor((i & 1) == 0 ? 0xFFE53935 : 0xFFFFFFFF);
            c.drawPath(path, fill);
        }
        c.restore();
    }

    private void sandcastle(Canvas c, float x) {
        float y = surf(x) + 2f * d;
        c.save();
        c.translate(x, y);
        c.scale(d, d);
        int sand = 0xFFE6C47A, dark = 0xFFC9A55C;
        rect(c, -18f, -14f, 18f, 0f, 1.5f, sand);
        rect(c, -22f, -24f, -10f, 0f, 1.5f, sand);
        rect(c, 10f, -24f, 22f, 0f, 1.5f, sand);
        for (int i = 0; i < 3; i++) {
            rect(c, -22f + i * 4.5f, -28f, -19f + i * 4.5f, -24f, 0.5f, sand);
            rect(c, 10f + i * 4.5f, -28f, 13f + i * 4.5f, -24f, 0.5f, sand);
        }
        rect(c, -4f, -9f, 4f, 0f, 3f, dark);
        line.setColor(0xFF6D4C41);
        line.setStrokeWidth(1.2f);
        c.drawLine(0f, -14f, 0f, -30f, line);
        path.rewind();
        path.moveTo(0f, -30f);
        path.lineTo(9f, -27f);
        path.lineTo(0f, -24f);
        path.close();
        fill.setColor(0xFFE53935);
        c.drawPath(path, fill);
        c.restore();
    }
}
