package com.personal.snowdrift;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Мастерская снеговика: катать комья, ставить шары друг на друга, украшать игрушками. */
public class WorkshopActivity extends Activity implements SensorEventListener {
    private WorkshopView view;
    private SensorManager sensors;
    private Sensor accel;
    private float gax, gay;
    private boolean haveG;
    private final float[] g2 = new float[2];
    private float dp;
    private Button modeBtn;
    private static final int[] MODE_LABELS = {R.string.ws_mode_snow1, R.string.ws_mode_snow2, R.string.ws_mode_tree, R.string.ws_mode_lego};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;
        getWindow().setStatusBarColor(0xFF10233D);
        getWindow().setNavigationBarColor(0xFF0A1424);

        sensors = getSystemService(SensorManager.class);
        accel = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        view = new WorkshopView(this);
        android.content.SharedPreferences prefs = Prefs.get(this);
        Season season = Season.now(Prefs.debugSeason(prefs), Prefs.debugParticle(prefs));
        view.setLegoAllowed(season.particle == Season.P_LEGO); // строить из LEGO можно в праздник
        view.setTakeSnow(Prefs.takeSnow(prefs));
        view.setHints(new String[]{getString(R.string.ws_hint_roll), getString(R.string.ws_hint_stack),
                getString(R.string.ws_hint_toys), getString(R.string.ws_hint_done), getString(R.string.ws_hint_tree_empty),
                getString(R.string.ws_hint_tree), getString(R.string.ws_hint_lego), getString(R.string.ws_no_snow)});

        FrameLayout root = new FrameLayout(this);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(px(6), px(6), px(6), px(6));
        bar.addView(button(R.string.ws_back, v -> finish()), barLp());
        modeBtn = button(MODE_LABELS[0], v -> modeBtn.setText(MODE_LABELS[view.nextMode()]));
        bar.addView(modeBtn, barLp());
        bar.addView(button(R.string.ws_toys, v -> view.toggleTray()), barLp());
        bar.addView(button(R.string.ws_undo, v -> view.undo()), barLp());
        bar.addView(button(R.string.ws_reset, v -> new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.ws_reset_title)
                .setMessage(R.string.ws_reset_text)
                .setPositiveButton(R.string.ws_reset, (dlg, which) -> view.reset())
                .setNegativeButton(android.R.string.cancel, null)
                .show()), barLp());
        root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        view.setRunning(true);
        haveG = false;
        if (accel != null) sensors.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        if (accel != null) sensors.unregisterListener(this);
        view.setRunning(false);
        view.save();
        super.onPause();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1];
        if (!haveG) {
            gax = x;
            gay = y;
            haveG = true;
        } else {
            gax += (x - gax) * 0.12f;
            gay += (y - gay) * 0.12f;
        }
        Tilt.toScreen(gax, gay, getWindowManager().getDefaultDisplay().getRotation(), g2);
        view.setGravity(g2[0], g2[1]);
    }

    @Override
    public void onAccuracyChanged(Sensor s, int acc) {}

    private Button button(int label, android.view.View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(12);
        b.setStateListAnimator(null);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xCC1B3556);
        bg.setCornerRadius(px(14));
        b.setBackground(bg);
        b.setPadding(px(6), px(8), px(6), px(8));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams barLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(px(3), 0, px(3), 0);
        return lp;
    }

    private int px(float v) {
        return Math.round(v * dp);
    }
}
