package com.personal.snowdrift;

import java.util.Calendar;

/**
 * Время года и праздник по дате телефона (северное полушарие). Пользователь сезон не выбирает:
 * зима — снег, осень — листья, весна — лепестки, лето — песок и вода. В праздники вместо
 * снежинок падает что-то своё. Разработчику есть скрытая подмена сезона (Prefs.DEBUG_SEASON).
 */
final class Season {
    static final int WINTER = 0, SPRING = 1, SUMMER = 2, AUTUMN = 3;

    /** Что падает с неба. */
    static final int P_SNOW = 0, P_LEAF = 1, P_PETAL = 2, P_NONE = 3, P_HEART = 4, P_LEGO = 5, P_TULIP = 6, P_PUMPKIN = 7,
            P_STAR = 8, P_EGG = 9, P_CONFETTI = 10;

    final int season;
    final int particle;
    final boolean newYear;     // 1 января — показываем поздравление
    final int year;

    private Season(int season, int particle, boolean newYear, int year) {
        this.season = season;
        this.particle = particle;
        this.newYear = newYear;
        this.year = year;
    }

    /** debugSeason / debugParticle: −1 — по дате; иначе подмена (скрытый режим разработчика). */
    static Season now(int debugSeason, int debugParticle) {
        Calendar c = Calendar.getInstance();
        int month = c.get(Calendar.MONTH) + 1, day = c.get(Calendar.DAY_OF_MONTH);
        Season s = of(month, day, c.get(Calendar.YEAR));
        if (debugSeason < 0 && debugParticle < 0) return s;
        int season = debugSeason >= 0 ? debugSeason : s.season;
        int p = debugParticle >= 0 ? debugParticle : debugSeason >= 0 ? base(debugSeason) : s.particle;
        return new Season(season, p, debugSeason < 0 && s.newYear, s.year);
    }

    static Season now(int debugSeason) {
        return now(debugSeason, -1);
    }

    static Season of(int month, int day, int year) {
        int season = month == 12 || month <= 2 ? WINTER : month <= 5 ? SPRING : month <= 8 ? SUMMER : AUTUMN;
        int p = base(season);
        if (month == 2 && day == 14) p = P_HEART;       // День святого Валентина
        else if (month == 3 && day == 8) p = P_TULIP;   // 8 марта
        else if (month == 10 && day == 31) p = P_PUMPKIN; // Хэллоуин
        else if (month == 11 && day == 19) p = P_LEGO;  // 19 ноября — вместо листьев кубики LEGO
        else if (month == 8 && day == 24) p = P_CONFETTI; // День Независимости Украины: сине-жёлтое конфетти
        else if ((month == 12 && (day == 24 || day == 25)) || (month == 1 && (day == 6 || day == 7))) p = P_STAR; // Рождество
        else if (isEaster(year, month, day)) p = P_EGG; // Пасха (православная) и суббота перед ней
        return new Season(season, p, month == 1 && day == 1, year);
    }

    /** Православная Пасха по юлианскому календарю (формула Мееса) +13 дней = григорианская дата, 1900–2099. */
    private static boolean isEaster(int year, int month, int day) {
        int a = year % 4, b = year % 7, c = year % 19;
        int d = (19 * c + 15) % 30;
        int e = (2 * a + 4 * b - d + 34) % 7;
        int m = (d + e + 114) / 31, dd = (d + e + 114) % 31 + 1;
        Calendar easter = Calendar.getInstance();
        easter.clear();
        easter.set(year, m - 1, dd);
        easter.add(Calendar.DAY_OF_MONTH, 13);
        int em = easter.get(Calendar.MONTH) + 1, ed = easter.get(Calendar.DAY_OF_MONTH);
        if (em == month && ed == day) return true;
        easter.add(Calendar.DAY_OF_MONTH, -1); // суббота
        return easter.get(Calendar.MONTH) + 1 == month && easter.get(Calendar.DAY_OF_MONTH) == day;
    }

    private static int base(int season) {
        return season == WINTER ? P_SNOW : season == SPRING ? P_PETAL : season == SUMMER ? P_NONE : P_LEAF;
    }

    /** Ключ сугроба в хранилище: у каждого сезона своя «куча» (листья, лепестки, снег). */
    String driftKey() {
        return "*" + season;
    }

    // ---------------------------------------------------------------- оформление

    /** Цвета оформления (приложение и «пол» на экране). Индексы палитры — см. P_*. */
    static final class Palette {
        int bgTop, bgBottom, card, accent, onAccent, textDim, status, nav;
        // «пол»: верх и низ заливки, линия кромки, тень под кромкой, цвет брызг
        int floorTop, floorBottom, floorEdge, floorShade, spray;
        // небо и земля в мастерской
        int skyTop, skyBottom, ground1, ground2;
        boolean sparkle;
    }

    Palette palette() {
        Palette p = new Palette();
        switch (season) {
            case AUTUMN:
                p.bgTop = 0xFF3A1F0E; p.bgBottom = 0xFF1C0F06; p.card = 0x22FFFFFF; p.accent = 0xFFFFA24D; p.onAccent = 0xFF2A1305;
                p.textDim = 0xB3FFE3C4; p.status = 0xFF3A1F0E; p.nav = 0xFF1C0F06;
                p.floorTop = 0xFFEBA83C; p.floorBottom = 0xFF9E4F1A; p.floorEdge = 0xFFF6C255; p.floorShade = 0xFF7A3B12; p.spray = 0xFFE59A35;
                p.skyTop = 0xFF4A2A14; p.skyBottom = 0xFF9A5B2C; p.ground1 = 0xFFC98A3B; p.ground2 = 0xFF8A4A1B;
                break;
            case SPRING:
                p.bgTop = 0xFF16351F; p.bgBottom = 0xFF0A2012; p.card = 0x22FFFFFF; p.accent = 0xFFFF9EC4; p.onAccent = 0xFF3A0F22;
                p.textDim = 0xB3E6FFE0; p.status = 0xFF16351F; p.nav = 0xFF0A2012;
                p.floorTop = 0xFFFFE6F0; p.floorBottom = 0xFFF0A6C2; p.floorEdge = 0xFFFFF7FA; p.floorShade = 0xFFD98BAA; p.spray = 0xFFFFC2D6;
                p.skyTop = 0xFF2B6A8C; p.skyBottom = 0xFF9ED8E8; p.ground1 = 0xFF8FD18A; p.ground2 = 0xFF4D9B55;
                break;
            case SUMMER:
                p.bgTop = 0xFF0E4A63; p.bgBottom = 0xFF08293A; p.card = 0x22FFFFFF; p.accent = 0xFFFFD66B; p.onAccent = 0xFF3A2A00;
                p.textDim = 0xB3E6F9FF; p.status = 0xFF0E4A63; p.nav = 0xFF08293A;
                p.floorTop = 0xFFF6E2A8; p.floorBottom = 0xFFD8B26A; p.floorEdge = 0xFFFFF0C8; p.floorShade = 0xFFB98F4A; p.spray = 0xFFEBCB8A;
                p.skyTop = 0xFF2E9BD6; p.skyBottom = 0xFFBDE7F7; p.ground1 = 0xFFF6E2A8; p.ground2 = 0xFFD8B26A;
                break;
            default:
                p.bgTop = 0xFF10233D; p.bgBottom = 0xFF0A1424; p.card = 0x1FFFFFFF; p.accent = 0xFF7CC4FF; p.onAccent = 0xFF0B1A2E;
                p.textDim = 0xB3E6F0FF; p.status = 0xFF10233D; p.nav = 0xFF0A1424;
                p.floorTop = 0xFFFFFFFF; p.floorBottom = 0xFFD3E2F3; p.floorEdge = 0xFFFFFFFF; p.floorShade = 0xFF9DBCE0; p.spray = 0xFFF7FAFF;
                p.skyTop = 0xFF10233D; p.skyBottom = 0xFF35618F; p.ground1 = 0xFFFFFFFF; p.ground2 = 0xFFD3E2F3;
                p.sparkle = true;
        }
        return p;
    }
}
