package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.HashMap;

/** Мягкое свечение: круг с радиальным градиентом, один шейдер на цвет. */
final class Glow {
    private final HashMap<Integer, Paint> cache = new HashMap<>();

    /** Свечение цвета rgb радиуса r (пиксели) с центром (x, y); alpha 0..1. */
    void draw(Canvas c, float x, float y, float r, int rgb, float alpha) {
        if (alpha <= 0.01f || r <= 0.5f) return;
        rgb &= 0xFFFFFF;
        Paint p = cache.get(rgb);
        if (p == null) {
            p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new RadialGradient(0f, 0f, 1f,
                    new int[]{rgb | 0xF2000000, rgb | 0x66000000, rgb},
                    new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            cache.put(rgb, p);
        }
        p.setAlpha((int) (255 * Math.min(1f, alpha)));
        c.save();
        c.translate(x, y);
        c.scale(r, r);
        c.drawCircle(0f, 0f, 1f, p);
        c.restore();
    }
}
