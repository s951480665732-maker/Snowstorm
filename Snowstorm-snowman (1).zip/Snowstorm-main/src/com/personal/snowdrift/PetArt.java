package com.personal.snowdrift;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/**
 * Кот и собака (вид сбоку, смотрят вправо) со скинами и сезонной одеждой.
 * Единицы — «клетки» тела: начало в точке опоры под центром животного, вверх — минус.
 */
final class PetArt {
    static final int SKINS = 5;
    static final int POSE_WALK = 0, POSE_SIT = 1, POSE_SLEEP = 2, POSE_SWAT = 3;

    // ---- скины кота: тело, брюшко, полоски/метки, глаза; узор: 0 полоски, 1 однотонный, 2 сиамские метки
    private static final int[][] CAT = {
            {0xFFE08A3C, 0xFFF7D9AB, 0xFFB5601F, 0xFF3FA34D},
            {0xFF8E98A3, 0xFFC9D0D8, 0xFF69737E, 0xFFE5C100},
            {0xFF2A2A30, 0xFF3A3A42, 0xFF2A2A30, 0xFFFFD83A},
            {0xFFF5F5F5, 0xFFFFFFFF, 0xFFDADADA, 0xFF3B9BE0},
            {0xFFEFE0C8, 0xFFF7EEDD, 0xFF5B3F32, 0xFF4FA3E8}};
    private static final int[] CAT_PATTERN = {0, 0, 1, 1, 2};
    // ---- скины собаки: тело, брюшко/лапы, ухо, пятна; узор: 0 однотонный, 1 хаски, 2 далматин, 3 подпалины
    private static final int[][] DOG = {
            {0xFF9A6B3E, 0xFFC9A074, 0xFF6E4624, 0xFF9A6B3E},
            {0xFFF2F2F2, 0xFFFFFFFF, 0xFF4F5560, 0xFF6F7782},
            {0xFFE3B05A, 0xFFF1CF8F, 0xFFB9852F, 0xFFE3B05A},
            {0xFFF7F7F7, 0xFFFFFFFF, 0xFF2B2B2B, 0xFF222222},
            {0xFF2E2E33, 0xFFB5651D, 0xFF1E1E22, 0xFFB5651D}};
    private static final int[] DOG_PATTERN = {0, 1, 0, 2, 3};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    PetArt() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
    }

    private void oval(Canvas c, float l, float t, float r, float b, int color) {
        fill.setColor(color);
        rf.set(l, t, r, b);
        c.drawOval(rf, fill);
    }

    private void dot(Canvas c, float x, float y, float r, int color) {
        fill.setColor(color);
        c.drawCircle(x, y, r, fill);
    }

    private void seg(Canvas c, float x1, float y1, float x2, float y2, float w, int color) {
        line.setStrokeWidth(w);
        line.setColor(color);
        c.drawLine(x1, y1, x2, y2, line);
    }

    private void tri(Canvas c, float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        path.rewind();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    /**
     * Рисует животное: (x, y) — опора на землю, s — пикселей на клетку, flip — смотрит влево,
     * phase — фаза шага, pose — поза, anim — 0..1 (взмах лапой у кота), season — для одежды.
     */
    void draw(Canvas c, boolean cat, int skin, float x, float y, float s, boolean flip,
              float phase, int pose, float anim, int season) {
        skin = Math.max(0, Math.min(SKINS - 1, skin));
        c.save();
        c.translate(x, y);
        c.scale(flip ? -s : s, s);
        if (cat) drawCat(c, skin, phase, pose, anim, season);
        else drawDog(c, skin, phase, pose, anim, season);
        c.restore();
    }

    // ---------------------------------------------------------------- кот

    private void leg(Canvas c, float hx, float hy, float len, float ang, float w, int color, int paw) {
        float ex = hx + (float) Math.sin(ang) * len, ey = hy + (float) Math.cos(ang) * len;
        seg(c, hx, hy, ex, ey, w, color);
        dot(c, ex, ey, w * 0.55f, paw);
    }

    private void drawCat(Canvas c, int skin, float phase, int pose, float anim, int season) {
        int[] k = CAT[skin];
        int body = k[0], belly = k[1], mark = k[2], eye = k[3], pat = CAT_PATTERN[skin];
        int paw = pat == 2 ? mark : body;
        float sw = (float) Math.sin(phase), cw = (float) Math.cos(phase);
        if (pose == POSE_SLEEP) {
            seg(c, -13f, -5f, -4f, -2f, 3.6f, pat == 2 ? mark : body); // хвост вокруг
            oval(c, -14f, -13f, 14f, 0f, body);
            oval(c, -9f, -7f, 8f, -0.5f, belly);
            oval(c, 6f, -12f, 17f, -2f, body);
            tri(c, 8f, -11.5f, 9.5f, -15f, 12f, -11.8f, pat == 2 ? mark : body);
            seg(c, 11.5f, -7f, 14.5f, -7f, 1f, 0xFF222222); // закрытый глаз
            dot(c, 15.5f, -5.5f, 1f, 0xFFE88B8B);
            clothes(c, true, season, 12f, -7f, true);
            return;
        }
        boolean sit = pose == POSE_SIT;
        float lift = pose == POSE_WALK ? Math.abs(sw) * 0.8f : 0f;
        // хвост
        path.rewind();
        if (sit) {
            path.moveTo(-9f, -3f);
            path.quadTo(-15f, -2f, -14f, -9f);
        } else {
            path.moveTo(-14f, -14f - lift);
            path.quadTo(-23f, -14f + sw * 3f, -21f, -24f + sw * 2f);
        }
        line.setStrokeWidth(3.4f);
        line.setColor(body);
        c.drawPath(path, line);
        if (pat == 2) { // кончик хвоста тёмный
            line.setStrokeWidth(3.4f);
            line.setColor(mark);
            seg(c, sit ? -14.2f : -21.4f, sit ? -7f : -22f, sit ? -14f : -21f, sit ? -9f : -24f, 3.6f, mark);
        }
        if (sit) {
            oval(c, -9f, -20f, 8f, -1f, body);
            oval(c, -3f, -15f, 6f, -2f, belly);
            leg(c, 4f, -9f, 9f, 0.05f, 3.2f, body, paw);
            leg(c, 1f, -9f, 9f, -0.05f, 3.2f, body, paw);
            oval(c, -8f, -5f, 2f, 0f, body);
            headCat(c, 4f, -25f, body, belly, mark, eye, pat, season);
            return;
        }
        // задние лапы, тело, передние лапы
        float hipY = -11f - lift;
        leg(c, -10f, hipY, 11f + lift, sw * 0.55f, 3.2f, pat == 2 ? mark : body, paw);
        leg(c, -7f, hipY, 11f + lift, -sw * 0.55f, 3.2f, body, paw);
        oval(c, -15f, -20f - lift, 12f, -6f - lift, body);
        oval(c, -8f, -11f - lift, 8f, -6f - lift, belly);
        if (pat == 0) { // полоски по спине
            for (int i = 0; i < 4; i++) seg(c, -9f + i * 5f, -20f - lift, -8f + i * 5f, -15f - lift, 1.6f, mark);
        }
        float frontAng = pose == POSE_SWAT ? -(0.4f + 1.1f * anim) : cw * 0.55f;
        leg(c, 8f, hipY, 11f + lift, frontAng, 3.2f, body, paw);
        leg(c, 11f, hipY, 11f + lift, pose == POSE_SWAT ? 0.1f : -cw * 0.55f, 3.2f, pat == 2 ? mark : body, paw);
        headCat(c, 14f, -19f - lift, body, belly, mark, eye, pat, season);
    }

    private void headCat(Canvas c, float hx, float hy, int body, int belly, int mark, int eye, int pat, int season) {
        int ear = pat == 2 ? mark : body;
        tri(c, hx - 6f, hy - 3f, hx - 5f, hy - 11f, hx - 0.5f, hy - 6f, ear);
        tri(c, hx + 0.5f, hy - 6f, hx + 5f, hy - 11f, hx + 6f, hy - 3f, ear);
        dot(c, hx, hy, 7.2f, body);
        if (pat == 2) oval(c, hx - 1f, hy - 2f, hx + 7.5f, hy + 6f, mark); // сиамская маска
        oval(c, hx + 1f, hy + 1f, hx + 8f, hy + 6.5f, pat == 2 ? mark : belly);
        dot(c, hx + 2.6f, hy - 1.4f, 1.7f, eye);
        dot(c, hx + 2.9f, hy - 1.4f, 0.8f, 0xFF111111);
        dot(c, hx + 7.4f, hy + 1.3f, 1f, 0xFFE88B8B);
        seg(c, hx + 5f, hy + 2.6f, hx + 11.5f, hy + 1f, 0.7f, 0x88FFFFFF);
        seg(c, hx + 5f, hy + 3.4f, hx + 11.5f, hy + 4.6f, 0.7f, 0x88FFFFFF);
        clothes(c, true, season, hx, hy, false);
    }

    // ---------------------------------------------------------------- собака

    private void drawDog(Canvas c, int skin, float phase, int pose, float anim, int season) {
        int[] k = DOG[skin];
        int body = k[0], belly = k[1], ear = k[2], spot = k[3], pat = DOG_PATTERN[skin];
        float sw = (float) Math.sin(phase), cw = (float) Math.cos(phase);
        if (pose == POSE_SLEEP) {
            oval(c, -18f, -15f, 17f, 0f, body);
            oval(c, -12f, -8f, 12f, -0.5f, belly);
            seg(c, -18f, -6f, -24f, -10f, 3.6f, body);
            oval(c, 10f, -13f, 24f, -1f, body);
            oval(c, 6f, -13f, 13f, -5f, ear);
            dot(c, 21f, -6f, 1.3f, 0xFF111111);
            seg(c, 17f, -8f, 20f, -8f, 1f, 0xFF222222);
            clothes(c, false, season, 18f, -7f, true);
            return;
        }
        boolean sit = pose == POSE_SIT;
        float lift = pose == POSE_WALK ? Math.abs(sw) : 0f;
        float wag = (float) Math.sin(phase * 2.2f + 1f);
        // хвост виляет
        seg(c, sit ? -10f : -19f, sit ? -4f : -17f - lift, sit ? -17f : -26f + wag * 3f, sit ? -9f + wag * 2f : -24f, 3.6f, body);
        if (sit) {
            oval(c, -11f, -24f, 9f, -1f, body);
            oval(c, -4f, -17f, 7f, -2f, belly);
            leg(c, 5f, -10f, 10f, 0.04f, 4f, belly, belly);
            leg(c, 1.5f, -10f, 10f, -0.04f, 4f, belly, belly);
            oval(c, -10f, -6f, 2f, 0f, body);
            headDog(c, 5f, -29f, body, belly, ear, spot, pat, season);
            return;
        }
        float hipY = -14f - lift;
        int pawc = pat == 3 || pat == 1 ? belly : body;
        leg(c, -13f, hipY, 14f + lift, sw * 0.6f, 4f, body, pawc);
        leg(c, -9f, hipY, 14f + lift, -sw * 0.6f, 4f, body, pawc);
        oval(c, -19f, -26f - lift, 16f, -8f - lift, body);
        if (pat == 1) oval(c, -19f, -26f - lift, 16f, -17f - lift, spot);          // спина хаски серая
        oval(c, -11f, -14f - lift, 11f, -8f - lift, belly);
        if (pat == 2) {
            dot(c, -9f, -20f - lift, 2.2f, spot);
            dot(c, -1f, -22f - lift, 2.6f, spot);
            dot(c, 6f, -19f - lift, 2f, spot);
            dot(c, -4f, -14f - lift, 1.8f, spot);
        }
        leg(c, 9f, hipY, 14f + lift, cw * 0.6f, 4f, body, pawc);
        leg(c, 13f, hipY, 14f + lift, -cw * 0.6f, 4f, body, pawc);
        headDog(c, 19f, -26f - lift, body, belly, ear, spot, pat, season);
    }

    private void headDog(Canvas c, float hx, float hy, int body, int belly, int ear, int spot, int pat, int season) {
        dot(c, hx, hy, 8.4f, body);
        if (pat == 1) oval(c, hx - 8f, hy - 9f, hx + 8f, hy - 1f, spot);                  // маска хаски
        oval(c, hx + 2f, hy - 1f, hx + 13.5f, hy + 6.5f, pat == 1 || pat == 3 ? belly : body); // морда
        if (pat == 2) dot(c, hx - 2f, hy - 4f, 2.2f, spot);
        dot(c, hx + 13f, hy + 1.2f, 1.9f, 0xFF111111);                                    // нос
        oval(c, hx - 7f, hy - 6f, hx - 0.5f, hy + 6f, ear);                               // висячее ухо
        dot(c, hx + 3.2f, hy - 2.2f, 1.6f, 0xFF3A2A1A);
        dot(c, hx + 3.5f, hy - 2.5f, 0.6f, 0xFFFFFFFF);
        seg(c, hx + 7f, hy + 5f, hx + 12f, hy + 5f, 0.9f, 0x66000000);                    // рот
        clothes(c, false, season, hx, hy, false);
    }

    // ---------------------------------------------------------------- одежда по сезону

    /** Зима — шарф и шапка, осень — дождевик, весна — цветочный ошейник, лето — очки. */
    private void clothes(Canvas c, boolean cat, int season, float hx, float hy, boolean sleeping) {
        float neckX = hx - (sleeping ? 4f : 4.5f), neckY = hy + (sleeping ? 3f : 6f);
        switch (season) {
            case Season.WINTER:
                rf.set(neckX - 6f, neckY - 1.6f, neckX + 5f, neckY + 3.2f);
                fill.setColor(0xFFD32F2F);
                c.drawRoundRect(rf, 2f, 2f, fill);
                rf.set(neckX - 7.5f, neckY, neckX - 4f, neckY + 8f);
                c.drawRoundRect(rf, 1.5f, 1.5f, fill);
                seg(c, neckX - 6f, neckY + 2f, neckX - 6f, neckY + 7f, 1.1f, 0xFFFFFFFF);
                if (!cat) { // шапка собаки
                    path.rewind();
                    path.moveTo(hx - 6.5f, hy - 5f);
                    path.quadTo(hx - 1f, hy - 15f, hx + 6.5f, hy - 5f);
                    path.close();
                    fill.setColor(0xFF1E88E5);
                    c.drawPath(path, fill);
                    dot(c, hx, hy - 12f, 2.2f, 0xFFFFFFFF);
                }
                break;
            case Season.AUTUMN:
                rf.set(neckX - 15f, neckY + 1f, neckX + 4f, neckY + (cat ? 11f : 14f));
                fill.setColor(0xFFFFD23F);
                c.drawRoundRect(rf, 4f, 4f, fill);
                seg(c, neckX - 14f, neckY + 3f, neckX + 3f, neckY + 3f, 1f, 0xFFE0A800);
                dot(c, neckX - 4f, neckY + 5f, 0.9f, 0xFF8A6A00);
                dot(c, neckX - 8f, neckY + 7f, 0.9f, 0xFF8A6A00);
                break;
            case Season.SPRING:
                for (int i = 0; i < 5; i++) {
                    double a = Math.toRadians(i * 72);
                    dot(c, hx + 5f + (float) Math.cos(a) * 2.6f, hy - 7f + (float) Math.sin(a) * 2.6f, 1.7f, 0xFFFF8FB1);
                }
                dot(c, hx + 5f, hy - 7f, 1.2f, 0xFFFFE066);
                seg(c, neckX - 5f, neckY + 1.5f, neckX + 4f, neckY + 1.5f, 1.6f, 0xFFFF8FB1);
                for (int i = 0; i < 3; i++) dot(c, neckX - 3f + i * 3.5f, neckY + 1.5f, 1.2f, 0xFFFFE066);
                break;
            case Season.SUMMER:
                rf.set(hx + 0.5f, hy - 3.4f, hx + 5.6f, hy + 0.6f);
                fill.setColor(0xFF1B1B1F);
                c.drawRoundRect(rf, 1.6f, 1.6f, fill);
                seg(c, hx + 0.5f, hy - 2.2f, hx - 5.5f, hy - 3.5f, 0.9f, 0xFF1B1B1F);
                dot(c, hx + 2f, hy - 2.4f, 0.8f, 0x88FFFFFF);
                break;
            default:
                break;
        }
    }
}
